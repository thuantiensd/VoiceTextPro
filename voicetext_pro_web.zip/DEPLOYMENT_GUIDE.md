# 🚀 Deployment Guide - VoiceText Pro Web

## Deploy lên Vercel + Supabase (Miễn phí)

### Bước 1: Tải toàn bộ project
1. Click tên project ở góc trên trái Replit
2. Chọn "Download as ZIP"
3. Giải nén ra folder trên máy

### Bước 2: Setup Database (Supabase)
1. Truy cập https://supabase.com
2. Đăng ký tài khoản miễn phí
3. Tạo new project
4. Copy database URL từ Settings > Database > Connection string
5. Thay thế `[YOUR-PASSWORD]` bằng password bạn đặt

### Bước 3: Setup Hosting (Vercel)
1. Truy cập https://vercel.com
2. Đăng ký bằng GitHub account
3. Tạo GitHub repository cho project
4. Push code lên GitHub
5. Import project từ GitHub vào Vercel

### Bước 4: Cấu hình Environment Variables
Trong Vercel dashboard, thêm các biến môi trường:

```
DATABASE_URL=postgresql://postgres:[password]@[host]/postgres
OPENAI_API_KEY=your_openai_key
FPT_API_KEY=your_fpt_key
SESSION_SECRET=your_random_secret_string
NODE_ENV=production
```

### Bước 5: Migration Database
Chạy lệnh migration để tạo tables:
```bash
npm run db:push
```

### Bước 6: Deploy
1. Vercel sẽ tự động deploy khi push code
2. Website sẽ có domain: https://yourapp.vercel.app
3. Có thể custom domain miễn phí

## Chi phí
- **Vercel**: Miễn phí (100GB bandwidth/tháng)
- **Supabase**: Miễn phí (500MB database)
- **Domain tùy chỉnh**: Miễn phí
- **Tổng**: $0/tháng

## So sánh với Replit
| Tính năng | Replit Pro | Vercel + Supabase |
|-----------|------------|-------------------|
| Chi phí | $20/tháng | Miễn phí |
| Bandwidth | Có hạn | 100GB/tháng |
| Database | 1GB | 500MB |
| Uptime | 99.9% | 99.99% |
| Custom domain | ✅ | ✅ |
| SSL | ✅ | ✅ |

## Backup dữ liệu từ Replit
Trước khi chuyển, backup data:
```bash
# Export database
pg_dump $DATABASE_URL > backup.sql

# Import vào Supabase
psql $SUPABASE_URL < backup.sql
```

## Tính năng sau migration
- ✅ Giữ nguyên 100% tính năng
- ✅ Admin panel hoạt động bình thường
- ✅ User authentication
- ✅ File upload/download
- ✅ Real-time notifications
- ✅ Faster loading (CDN global)
- ✅ Better SEO
- ✅ Auto SSL certificates

## Domain tùy chỉnh
Sau khi deploy, có thể setup domain riêng:
1. Mua domain từ Namecheap/GoDaddy (~$10/năm)
2. Point DNS records về Vercel
3. Website sẽ có domain: https://yourdomain.com

Cần hỗ trợ setup chi tiết, liên hệ để được hướng dẫn từng bước.