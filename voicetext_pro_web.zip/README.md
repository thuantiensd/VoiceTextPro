# VoiceText Pro Web - Deployment Package

## Quick Deploy to Vercel + Supabase

### 1. Setup Database (Supabase)
1. Go to https://supabase.com
2. Create new project
3. Run `supabase_schema.sql` in SQL Editor
4. Copy connection string from Settings > Database

### 2. Deploy to Vercel
1. Go to https://vercel.com
2. Drag this folder to dashboard
3. Add environment variables:
   - DATABASE_URL=your_supabase_url
   - OPENAI_API_KEY=your_key
   - SESSION_SECRET=random_string
   - NODE_ENV=production

### 3. Done!
Your web app will be live at https://yourapp.vercel.app

## Files included:
- client/ - React frontend
- server/ - Express backend  
- shared/ - Common schemas
- vercel.json - Deployment config
- supabase_schema.sql - Database schema
