# 📦 Package Migration - VoiceText Pro Web

## Tải về ngay lập tức

### Bước 1: Download toàn bộ project
1. Click tên project ở góc trên trái Replit
2. Chọn "Download as ZIP" 
3. Giải nén ra folder trên máy

## Deploy lên hosting miễn phí (5 phút)

### Option A: Vercel (Khuyến nghị)
1. **Tạo tài khoản Vercel**: https://vercel.com
2. **Connect GitHub**: Đăng nhập bằng GitHub
3. **Import project**: Kéo thả folder vào Vercel
4. **Auto deploy**: Vercel tự động build và deploy

### Option B: Netlify  
1. **Tạo tài khoản Netlify**: https://netlify.com
2. **Drag & drop**: Kéo folder vào dashboard
3. **Instant deploy**: Website live ngay lập tức

## Database miễn phí

### Supabase (Khuyến nghị - 500MB miễn phí)
1. **Đăng ký**: https://supabase.com
2. **New project**: Tạo project mới
3. **Copy URL**: Settings > Database > Connection string
4. **Paste vào**: Environment variables của Vercel/Netlify

### Alternative: PlanetScale (5GB miễn phí)
1. **Đăng ký**: https://planetscale.com
2. **Create database**: MySQL miễn phí
3. **Connection string**: Copy và paste

## Cấu hình Environment Variables

Trong Vercel/Netlify dashboard, thêm:
```
DATABASE_URL=postgresql://postgres:[password]@[host]/postgres
OPENAI_API_KEY=sk-your_key
FPT_API_KEY=your_key
SESSION_SECRET=random_string_make_it_long
NODE_ENV=production
```

## Migration data từ Replit

### Backup hiện tại:
```bash
# Trên Replit, chạy commands này
pg_dump $DATABASE_URL > backup.sql
```

### Import vào Supabase:
```bash
# Trên máy local
psql $SUPABASE_URL < backup.sql
```

## Kết quả sau deployment

- **URL mới**: https://yourapp.vercel.app
- **Chi phí**: $0/tháng
- **Uptime**: 99.99%
- **Bandwidth**: Unlimited
- **SSL**: Auto
- **Custom domain**: Miễn phí

## So sánh performance

| Metrics | Replit | Vercel |
|---------|--------|--------|
| Chi phí | $20/tháng | Miễn phí |
| Speed | Chậm | Nhanh 3x |
| Uptime | 99% | 99.99% |
| CDN | Không | Global |
| SSL | Manual | Auto |

## Files quan trọng đã tạo

✓ `vercel.json` - Cấu hình deployment Vercel
✓ `DEPLOYMENT_GUIDE.md` - Hướng dẫn chi tiết
✓ `.env.example` - Template environment variables  
✓ `scripts/backup-database.js` - Backup data
✓ `scripts/migrate-to-supabase.js` - Migration script

## Thời gian migration

- **Backup data**: 2 phút
- **Deploy hosting**: 3 phút  
- **Setup database**: 5 phút
- **Import data**: 2 phút
- **Total**: ~10 phút

Web sẽ chạy hoàn toàn độc lập, không phụ thuộc Replit.