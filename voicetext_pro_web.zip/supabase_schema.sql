-- VoiceText Pro Database Schema for Supabase
-- Run this script in Supabase SQL Editor

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Sessions table (for authentication)
CREATE TABLE IF NOT EXISTS sessions (
  sid VARCHAR PRIMARY KEY,
  sess JSON NOT NULL,
  expire TIMESTAMP NOT NULL
);

CREATE INDEX IF NOT EXISTS "IDX_session_expire" ON sessions (expire);

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id VARCHAR PRIMARY KEY,
  username VARCHAR UNIQUE,
  email VARCHAR UNIQUE,
  password_hash VARCHAR,
  first_name VARCHAR,
  last_name VARCHAR,
  profile_image_url VARCHAR,
  role VARCHAR DEFAULT 'user',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Audio files table
CREATE TABLE IF NOT EXISTS audio_files (
  id SERIAL PRIMARY KEY,
  user_id VARCHAR REFERENCES users(id),
  title VARCHAR NOT NULL,
  text_content TEXT NOT NULL,
  voice_id VARCHAR NOT NULL,
  file_path VARCHAR,
  file_size INTEGER,
  duration DECIMAL,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Templates table
CREATE TABLE IF NOT EXISTS templates (
  id SERIAL PRIMARY KEY,
  title VARCHAR NOT NULL,
  content TEXT NOT NULL,
  category VARCHAR DEFAULT 'general',
  created_at TIMESTAMP DEFAULT NOW()
);

-- App settings table
CREATE TABLE IF NOT EXISTS app_settings (
  id SERIAL PRIMARY KEY,
  free_max_files INTEGER DEFAULT 5,
  free_max_characters INTEGER DEFAULT 10000,
  premium_max_files INTEGER DEFAULT 100,
  premium_max_characters INTEGER DEFAULT 100000,
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id SERIAL PRIMARY KEY,
  title VARCHAR NOT NULL,
  message TEXT NOT NULL,
  type VARCHAR DEFAULT 'info',
  is_read BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Activity logs table
CREATE TABLE IF NOT EXISTS activity_logs (
  id SERIAL PRIMARY KEY,
  action TEXT NOT NULL,
  user_id VARCHAR,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Support tickets table
CREATE TABLE IF NOT EXISTS support_tickets (
  id SERIAL PRIMARY KEY,
  title VARCHAR NOT NULL,
  description TEXT NOT NULL,
  status VARCHAR DEFAULT 'open',
  priority VARCHAR DEFAULT 'medium',
  created_at TIMESTAMP DEFAULT NOW()
);

-- Payments table
CREATE TABLE IF NOT EXISTS payments (
  id SERIAL PRIMARY KEY,
  user_id VARCHAR REFERENCES users(id),
  amount DECIMAL NOT NULL,
  currency VARCHAR DEFAULT 'USD',
  status VARCHAR DEFAULT 'pending',
  stripe_payment_id VARCHAR,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Insert default data
INSERT INTO app_settings (free_max_files, free_max_characters, premium_max_files, premium_max_characters) 
VALUES (5, 10000, 100, 100000) 
ON CONFLICT DO NOTHING;

INSERT INTO templates (title, content, category) VALUES 
('Giới thiệu sản phẩm', 'Xin chào! Tôi muốn giới thiệu về sản phẩm mới của chúng tôi...', 'business'),
('Thông báo sự kiện', 'Chúng tôi vui mừng thông báo về sự kiện đặc biệt sắp tới...', 'announcement'),
('Hướng dẫn sử dụng', 'Để sử dụng tính năng này, bạn cần làm theo các bước sau...', 'tutorial')
ON CONFLICT DO NOTHING;

INSERT INTO notifications (title, message, type) VALUES 
('Chào mừng!', 'Chào mừng bạn đến với VoiceText Pro', 'info'),
('Tính năng mới', 'Chúng tôi đã thêm giọng nói mới', 'update')
ON CONFLICT DO NOTHING;