import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import Stripe from "stripe";
import OpenAI from "openai";
import { insertAudioFileSchema, updateAudioFileSchema, insertUserSchema, loginSchema } from "@shared/schema";
import { fptAI, FPT_VOICES } from "./fpt-ai";
import { z } from "zod";
import multer from "multer";
import fs from "fs/promises";
import path from "path";
import { createRequire } from "module";
const require = createRequire(import.meta.url);
const pdfParse = require("pdf-parse");
import mammoth from "mammoth";
import session from "express-session";

// Configure multer for file uploads
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/plain'
    ];
    
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only PDF, Word, and TXT files are allowed.'));
    }
  }
});

// Configure multer for QR code image uploads
const qrUpload = multer({
  dest: 'uploads/qr/',
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      'image/jpeg',
      'image/png',
      'image/jpg',
      'image/webp'
    ];
    
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only JPG, PNG, and WebP images are allowed.'));
    }
  }
});

// Configure multer for receipt image uploads
const receiptUpload = multer({
  dest: 'uploads/receipts/',
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      'image/jpeg',
      'image/png',
      'image/jpg',
      'image/webp'
    ];
    
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only JPG, PNG, and WebP images are allowed.'));
    }
  }
});

// Session configuration
declare module 'express-session' {
  interface SessionData {
    userId?: number;
  }
}

// Initialize Stripe with demo key (user can provide real key later)
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "sk_test_51234567890", {
  apiVersion: "2024-11-20.acacia",
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve static files from uploads directory
  app.use('/uploads', require('express').static('uploads'));

  // Configure session middleware
  app.use(session({
    secret: process.env.SESSION_SECRET || 'voicetext-pro-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false, // Set to true in production with HTTPS
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  }));

  // Helper function to create automatic notifications
  const createAutoNotification = async (userId: number, type: string, title: string, content: string) => {
    try {
      await storage.createUserNotification(userId, {
        type,
        title,
        content,
        isRead: false
      });
    } catch (error) {
      console.error("Failed to create auto notification:", error);
    }
  };

  // Helper function to check subscription expiry and send notifications
  const checkSubscriptionExpiry = async () => {
    try {
      const allUsers = await storage.getAllUsers();
      const now = new Date();
      
      for (const user of allUsers) {
        if (user.subscriptionType !== 'free' && user.subscriptionExpiry) {
          const expiryDate = new Date(user.subscriptionExpiry);
          const daysUntilExpiry = Math.ceil((expiryDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
          
          // Send notification 7 days before expiry
          if (daysUntilExpiry === 7) {
            await createAutoNotification(
              user.id,
              "expiry_warning",
              "Gói dịch vụ sắp hết hạn",
              `Gói ${user.subscriptionType.toUpperCase()} của bạn sẽ hết hạn vào ${expiryDate.toLocaleDateString('vi-VN')} (còn 7 ngày). Vui lòng gia hạn để tiếp tục sử dụng đầy đủ tính năng.`
            );
          }
          
          // Send notification 1 day before expiry
          if (daysUntilExpiry === 1) {
            await createAutoNotification(
              user.id,
              "expiry_urgent",
              "Gói dịch vụ hết hạn trong 1 ngày",
              `CẢNH BÁO: Gói ${user.subscriptionType.toUpperCase()} của bạn sẽ hết hạn vào ngày mai (${expiryDate.toLocaleDateString('vi-VN')}). Gia hạn ngay để tránh gián đoạn dịch vụ.`
            );
          }

          // Send notification when expired
          if (daysUntilExpiry === 0) {
            await createAutoNotification(
              user.id,
              "expired",
              "Gói dịch vụ đã hết hạn",
              `Gói ${user.subscriptionType.toUpperCase()} của bạn đã hết hạn hôm nay. Tài khoản đã được chuyển về gói Free với giới hạn 500 ký tự. Vui lòng gia hạn để tiếp tục sử dụng tính năng cao cấp.`
            );
            
            // Downgrade user to free plan
            await storage.updateUserSubscription(user.id, 'free', null);
          }
        }
      }
    } catch (error) {
      console.error("Failed to check subscription expiry:", error);
    }
  };

  // Run subscription expiry check every hour
  setInterval(checkSubscriptionExpiry, 60 * 60 * 1000);

  // Authentication middleware
  const requireAuth = async (req: any, res: any, next: any) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    // Kiểm tra user có tồn tại và có bị khóa không
    const user = await storage.getUser(req.session.userId);
    if (!user) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    // Kiểm tra tài khoản có bị khóa không
    if (!user.isActive) {
      // Xóa session nếu tài khoản bị khóa
      req.session.destroy();
      const lockMessage = user.lockReason 
        ? `Tài khoản đã bị khóa. Lý do: ${user.lockReason}`
        : "Tài khoản đã bị khóa";
      return res.status(403).json({ message: lockMessage });
    }
    
    req.user = user;
    next();
  };

  // Admin protection middleware
  const requireAdmin = async (req: any, res: any, next: any) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Unauthorized - No session" });
    }
    
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(401).json({ message: "Unauthorized - User not found" });
      }
      
      if (user.role !== "admin") {
        console.log(`Access denied for user ${user.username} with role ${user.role}`);
        return res.status(403).json({ message: "Admin access required" });
      }
      
      if (!user.isActive) {
        return res.status(403).json({ message: "Account is deactivated" });
      }
      
      // Store user info in request for use in handlers
      req.user = user;
      next();
    } catch (error) {
      console.error("Admin auth error:", error);
      return res.status(500).json({ message: "Authentication error" });
    }
  };



  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      
      // Create welcome notification for new user
      await createAutoNotification(
        user.id,
        "welcome",
        "Chào mừng bạn đến với VoiceText Pro!",
        `Xin chào ${user.fullName || user.username}, cảm ơn bạn đã đăng ký tài khoản. Hãy khám phá các tính năng tạo giọng đọc AI chất lượng cao của chúng tôi. Tài khoản Free của bạn có thể tạo audio từ 500 ký tự mỗi lần.`
      );

      // Create upgrade notification for free users
      if (user.subscriptionType === "free") {
        await createAutoNotification(
          user.id,
          "upgrade",
          "Nâng cấp để mở khóa tính năng Pro",
          "Nâng cấp lên gói Pro để tận hưởng 2000 ký tự mỗi lần, nhiều giọng đọc hơn và ưu tiên xử lý. Gói Premium cho phép 5000 ký tự và không giới hạn số file."
        );
      }
      
      // Don't send password in response
      const { password, ...userWithoutPassword } = user;
      
      res.status(201).json({
        message: "Đăng ký thành công",
        user: userWithoutPassword
      });
    } catch (error: any) {
      console.error("Registration error:", error);
      res.status(400).json({ 
        message: error.message || "Có lỗi xảy ra khi đăng ký"
      });
    }
  });

  app.post("/api/login", async (req, res) => {
    try {
      const loginData = loginSchema.parse(req.body);
      const user = await storage.authenticateUser(loginData);
      
      if (!user) {
        return res.status(401).json({ 
          message: "Tên đăng nhập hoặc mật khẩu không đúng" 
        });
      }

      // Kiểm tra tài khoản có bị khóa không
      if (!user.isActive) {
        const lockMessage = user.lockReason 
          ? `Tài khoản đã bị khóa. Lý do: ${user.lockReason}`
          : "Tài khoản đã bị khóa";
        return res.status(401).json({ 
          message: lockMessage,
          accountLocked: true
        });
      }

      // Set session
      req.session.userId = user.id;
      
      // Don't send password in response
      const { password, ...userWithoutPassword } = user;
      
      res.json({
        message: "Đăng nhập thành công",
        user: userWithoutPassword
      });
    } catch (error: any) {
      console.error("Login error:", error);
      res.status(400).json({ 
        message: "Có lỗi xảy ra khi đăng nhập"
      });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Có lỗi xảy ra khi đăng xuất" });
      }
      res.json({ message: "Đăng xuất thành công" });
    });
  });

  app.get("/api/auth/me", requireAuth, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Get user error:", error);
      res.status(500).json({ message: "Server error" });
    }
  });



  // Create admin user if none exists
  app.post("/api/create-admin", async (req, res) => {
    try {
      // Check if any admin exists
      const existingUsers = await storage.getAllUsers(100);
      const adminExists = existingUsers.some(user => user.role === "admin");
      
      if (adminExists) {
        return res.status(400).json({ message: "Admin already exists" });
      }
      
      const { username, email, password } = req.body;
      
      if (!username || !email || !password) {
        return res.status(400).json({ message: "Username, email and password are required" });
      }
      
      const adminUser = await storage.createUser({
        username,
        email,
        password,
        fullName: "Administrator",
        role: "admin",
        subscriptionType: "premium"
      });
      
      // Update role to admin
      const updatedAdmin = await storage.updateUserRole(adminUser.id, "admin");
      
      const { password: _, ...adminWithoutPassword } = updatedAdmin!;
      res.json({ message: "Admin created successfully", user: adminWithoutPassword });
    } catch (error) {
      console.error("Create admin error:", error);
      res.status(500).json({ message: "Failed to create admin" });
    }
  });

  // Admin routes
  app.get("/api/admin/users", requireAdmin, async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      
      const users = await storage.getAllUsers(limit, offset);
      const usersWithoutPasswords = users.map(({ password, ...user }) => user);
      
      res.json(usersWithoutPasswords);
    } catch (error) {
      console.error("Get users error:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  // Create new user (admin only)
  app.post("/api/admin/users", requireAdmin, async (req, res) => {
    try {
      console.log("Creating user with data:", req.body);
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username or email already exists
      const existingUserByUsername = await storage.getUserByUsername(userData.username);
      if (existingUserByUsername) {
        return res.status(400).json({ message: "Tên đăng nhập đã tồn tại" });
      }
      
      const existingUserByEmail = await storage.getUserByEmail(userData.email);
      if (existingUserByEmail) {
        return res.status(400).json({ message: "Email đã tồn tại" });
      }
      
      // Create user with all data from validated schema
      const newUser = await storage.createUser(userData);
      console.log("User created successfully:", newUser.id);
      
      const { password, ...userWithoutPassword } = newUser;
      res.status(201).json(userWithoutPassword);
    } catch (error: any) {
      console.error("Create user error:", error);
      if (error.issues) {
        // Zod validation error
        return res.status(400).json({ 
          message: "Dữ liệu không hợp lệ", 
          details: error.issues.map((issue: any) => issue.message).join(", ")
        });
      }
      if (error.code === '23505') {
        return res.status(400).json({ message: "Người dùng đã tồn tại" });
      }
      res.status(500).json({ message: "Có lỗi xảy ra khi tạo người dùng" });
    }
  });

  // Update user (admin only)
  app.put("/api/admin/users/:id", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const updateData = req.body.userData || req.body;
      
      // Bảo vệ tài khoản admin chính (ID = 1) khỏi bị chỉnh sửa
      if (userId === 1) {
        return res.status(403).json({ message: "Không thể chỉnh sửa tài khoản admin chính" });
      }
      
      // Check if user exists
      const existingUser = await storage.getUser(userId);
      if (!existingUser) {
        return res.status(404).json({ message: "Người dùng không tồn tại" });
      }
      
      // Check if username/email conflicts with other users
      if (updateData.username && updateData.username !== existingUser.username) {
        const conflictUser = await storage.getUserByUsername(updateData.username);
        if (conflictUser && conflictUser.id !== userId) {
          return res.status(400).json({ message: "Tên đăng nhập đã tồn tại" });
        }
      }
      
      if (updateData.email && updateData.email !== existingUser.email) {
        const conflictUser = await storage.getUserByEmail(updateData.email);
        if (conflictUser && conflictUser.id !== userId) {
          return res.status(400).json({ message: "Email đã tồn tại" });
        }
      }
      
      // Prepare update data
      const updateFields: any = {};
      
      if (updateData.username) updateFields.username = updateData.username;
      if (updateData.email) updateFields.email = updateData.email;
      if (updateData.fullName !== undefined) updateFields.fullName = updateData.fullName;
      if (updateData.role) updateFields.role = updateData.role;
      if (updateData.subscriptionType) updateFields.subscriptionType = updateData.subscriptionType;
      
      // Handle account locking/unlocking
      if (updateData.isActive !== undefined) {
        updateFields.isActive = updateData.isActive;
        
        if (!updateData.isActive && updateData.lockReason) {
          // Khóa tài khoản với lý do
          updateFields.lockReason = updateData.lockReason;
          updateFields.lockedAt = new Date();
          updateFields.lockedBy = req.session.userId; // ID của admin thực hiện khóa
        } else if (updateData.isActive) {
          // Mở khóa tài khoản
          updateFields.lockReason = null;
          updateFields.lockedAt = null;
          updateFields.lockedBy = null;
        }
      }
      
      // Update user in database
      const updatedUser = await storage.updateUser(userId, updateFields);
      
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Update user error:", error);
      res.status(500).json({ message: "Có lỗi xảy ra khi cập nhật người dùng" });
    }
  });

  app.get("/api/admin/stats", requireAdmin, async (req, res) => {
    try {
      const allUsers = await storage.getAllUsers(1000); // Get more users for stats
      const now = new Date();
      const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      
      const stats = {
        totalUsers: allUsers.length,
        proUsers: allUsers.filter(u => u.subscriptionType === "pro" || u.subscriptionType === "premium").length,
        activeToday: allUsers.filter(u => u.updatedAt > new Date(now.getTime() - 24 * 60 * 60 * 1000)).length,
        monthlyGrowth: Math.round((allUsers.filter(u => u.createdAt > monthAgo).length / Math.max(allUsers.length - allUsers.filter(u => u.createdAt > monthAgo).length, 1)) * 100)
      };
      
      res.json(stats);
    } catch (error) {
      console.error("Get stats error:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  app.patch("/api/admin/users/:id", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { role, subscriptionType, isActive, subscriptionExpiry } = req.body;
      
      let updatedUser;
      
      if (role !== undefined) {
        updatedUser = await storage.updateUserRole(userId, role);
      }
      
      if (subscriptionType !== undefined) {
        const expiryDate = subscriptionExpiry ? new Date(subscriptionExpiry) : undefined;
        updatedUser = await storage.updateUserSubscription(userId, subscriptionType, expiryDate);
      }
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Update user error:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  // Update user role
  app.put("/api/admin/users/:id/role", requireAdmin, async (req: any, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { role } = req.body;
      
      if (!role || !["admin", "user"].includes(role)) {
        return res.status(400).json({ message: "Invalid role" });
      }
      
      const updatedUser = await storage.updateUserRole(userId, role);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Update user role error:", error);
      res.status(500).json({ message: "Failed to update user role" });
    }
  });

  // Update user subscription
  app.put("/api/admin/users/:id/subscription", requireAdmin, async (req: any, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { subscriptionType, expiryDate } = req.body;
      
      if (!subscriptionType || !["free", "pro", "premium"].includes(subscriptionType)) {
        return res.status(400).json({ message: "Invalid subscription type" });
      }
      
      const expiry = expiryDate ? new Date(expiryDate) : undefined;
      const updatedUser = await storage.updateUserSubscription(userId, subscriptionType, expiry);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Update user subscription error:", error);
      res.status(500).json({ message: "Failed to update user subscription" });
    }
  });

  app.delete("/api/admin/users/:id", requireAdmin, async (req: any, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      // Prevent admin from deleting themselves  
      const currentUser = await storage.getUser(req.session.userId);
      if (userId === currentUser?.id) {
        return res.status(400).json({ message: "Cannot delete your own account" });
      }
      
      const deleted = await storage.deleteUser(userId);
      
      if (!deleted) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ message: "User deleted successfully" });
    } catch (error) {
      console.error("Delete user error:", error);
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  // Delete audio file (admin)
  app.delete("/api/admin/audio-files/:id", requireAdmin, async (req: any, res) => {
    try {
      const audioId = parseInt(req.params.id);
      const deleted = await storage.deleteAudioFile(audioId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Audio file not found" });
      }
      
      res.json({ message: "Audio file deleted successfully" });
    } catch (error) {
      console.error("Delete audio file error:", error);
      res.status(500).json({ message: "Failed to delete audio file" });
    }
  });

  // Update payment status (admin)
  app.put("/api/admin/payments/:id/status", requireAdmin, async (req: any, res) => {
    try {
      const paymentId = parseInt(req.params.id);
      const { status } = req.body;
      const adminUser = await storage.getUser(req.session.userId);
      
      if (!status || !["pending", "completed", "failed", "cancelled"].includes(status)) {
        return res.status(400).json({ message: "Invalid payment status" });
      }
      
      const updatedPayment = await storage.updatePaymentStatus(paymentId, status, adminUser?.id);
      
      if (!updatedPayment) {
        return res.status(404).json({ message: "Payment not found" });
      }
      
      res.json(updatedPayment);
    } catch (error) {
      console.error("Update payment status error:", error);
      res.status(500).json({ message: "Failed to update payment status" });
    }
  });

  // Confirm payment and upgrade user (admin)
  app.put("/api/admin/payments/:id/confirm", requireAdmin, async (req: any, res) => {
    try {
      const paymentId = parseInt(req.params.id);
      const adminUser = await storage.getUser(req.session.userId);
      
      // Get payment info
      const payment = await storage.getPayment(paymentId);
      if (!payment) {
        return res.status(404).json({ message: "Payment not found" });
      }
      
      if (payment.status !== 'pending') {
        return res.status(400).json({ message: "Payment is not pending" });
      }
      
      // Update payment status to completed
      const updatedPayment = await storage.updatePaymentStatus(paymentId, "completed", adminUser?.id);
      
      // Upgrade user subscription if payment has userId
      if (payment.userId) {
        const expiryDate = new Date();
        if (payment.billingCycle === 'monthly') {
          expiryDate.setMonth(expiryDate.getMonth() + 1);
        } else if (payment.billingCycle === 'yearly') {
          expiryDate.setFullYear(expiryDate.getFullYear() + 1);
        }
        
        // Cập nhật gói người dùng với ngày hết hạn
        const updatedUser = await storage.updateUserSubscription(payment.userId, payment.planType, expiryDate);
        
        // Tạo thông báo kích hoạt gói thành công cho admin
        await storage.createNotification({
          type: "payment",
          title: `Kích hoạt gói ${payment.planType.toUpperCase()} thành công`,
          message: `Tài khoản đã được nâng cấp lên gói ${payment.planType.toUpperCase()} (${payment.billingCycle === 'monthly' ? 'hàng tháng' : 'hàng năm'}). Hết hạn: ${expiryDate.toLocaleDateString('vi-VN')}`,
          isRead: false,
          createdAt: new Date(),
          actionUrl: `/admin?tab=users`,
          priority: "high"
        });

        // Tạo thông báo cho người dùng về việc nâng cấp thành công
        await createAutoNotification(
          payment.userId,
          "payment_success",
          `Thanh toán thành công - Gói ${payment.planType.toUpperCase()}`,
          `Chúc mừng! Thanh toán của bạn đã được xác nhận. Tài khoản đã được nâng cấp lên gói ${payment.planType.toUpperCase()} (${payment.billingCycle === 'monthly' ? 'hàng tháng' : 'hàng năm'}). Gói sẽ hết hạn vào ${expiryDate.toLocaleDateString('vi-VN')}. Bạn có thể sử dụng đầy đủ tính năng ngay bây giờ.`
        );

        console.log(`User ${payment.userId} upgraded to ${payment.planType} until ${expiryDate.toISOString()}`);
      }
      
      res.json({ 
        success: true, 
        message: "Payment confirmed and user upgraded successfully",
        payment: updatedPayment 
      });
    } catch (error) {
      console.error("Confirm payment error:", error);
      res.status(500).json({ message: "Failed to confirm payment" });
    }
  });

  // Toggle user account status (admin)
  app.put("/api/admin/users/:id/status", requireAdmin, async (req: any, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { isActive, lockReason } = req.body;
      const adminUser = await storage.getUser(req.session.userId);
      
      const updateData: any = {
        isActive,
        lockedBy: !isActive ? adminUser?.id : null,
        lockedAt: !isActive ? new Date() : null,
        lockReason: !isActive ? lockReason : null
      };
      
      const updatedUser = await storage.updateUser(userId, updateData);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({
        success: true,
        message: isActive ? "User account unlocked successfully" : "User account locked successfully",
        user: updatedUser
      });
    } catch (error) {
      console.error("Toggle user status error:", error);
      res.status(500).json({ message: "Failed to toggle user status" });
    }
  });

  // Delete user (admin only)
  app.delete("/api/admin/users/:id", requireAdmin, async (req: any, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      // Kiểm tra xem có phải admin đang cố xóa chính mình không
      const currentUser = await storage.getUser(req.session.userId);
      if (currentUser?.id === userId) {
        return res.status(400).json({ message: "Không thể xóa tài khoản admin hiện tại" });
      }
      
      // Kiểm tra xem user có tồn tại không
      const userToDelete = await storage.getUser(userId);
      if (!userToDelete) {
        return res.status(404).json({ message: "Không tìm thấy người dùng" });
      }
      
      // Không cho phép xóa admin khác
      if (userToDelete.role === "admin") {
        return res.status(400).json({ message: "Không thể xóa tài khoản admin" });
      }
      
      // Thực hiện xóa user
      const deleted = await storage.deleteUser(userId);
      
      if (!deleted) {
        return res.status(500).json({ message: "Không thể xóa người dùng" });
      }
      
      // Tạo thông báo về việc xóa user
      await storage.createNotification({
        type: "user",
        title: "Đã xóa người dùng",
        message: `Người dùng ${userToDelete.username} đã bị xóa khỏi hệ thống`,
        isRead: false,
        createdAt: new Date(),
        actionUrl: `/admin?tab=users`,
        priority: "medium"
      });
      
      res.json({
        success: true,
        message: "Đã xóa người dùng thành công"
      });
    } catch (error) {
      console.error("Delete user error:", error);
      res.status(500).json({ message: "Lỗi khi xóa người dùng" });
    }
  });

  // Reject payment (admin only)
  app.put("/api/admin/payments/:id/reject", requireAdmin, async (req: any, res) => {
    try {
      const paymentId = parseInt(req.params.id);
      
      // Kiểm tra payment có tồn tại không
      const payment = await storage.getPayment(paymentId);
      if (!payment) {
        return res.status(404).json({ message: "Không tìm thấy giao dịch" });
      }
      
      // Kiểm tra trạng thái payment
      if (payment.status !== "pending") {
        return res.status(400).json({ message: "Chỉ có thể từ chối giao dịch đang chờ xử lý" });
      }
      
      // Cập nhật trạng thái thành rejected
      const updatedPayment = await storage.updatePaymentStatus(paymentId, "rejected", req.session.userId);
      
      if (!updatedPayment) {
        return res.status(500).json({ message: "Không thể cập nhật trạng thái giao dịch" });
      }
      
      // Tạo thông báo về việc từ chối thanh toán
      await storage.createNotification({
        type: "payment",
        title: "Từ chối giao dịch thanh toán",
        message: `Giao dịch ${payment.orderId} đã bị từ chối. Khách hàng: ${payment.customerName}`,
        isRead: false,
        createdAt: new Date(),
        actionUrl: `/admin?tab=payments`,
        priority: "medium"
      });
      
      res.json({
        success: true,
        message: "Đã từ chối giao dịch thành công",
        payment: updatedPayment
      });
    } catch (error) {
      console.error("Reject payment error:", error);
      res.status(500).json({ message: "Lỗi khi từ chối giao dịch" });
    }
  });

  // Admin endpoint to generate voice samples
  app.post("/api/admin/generate-voice-sample", requireAdmin, async (req: any, res) => {
    try {
      const { voice, text } = req.body;

      if (!voice || !text) {
        return res.status(400).json({ message: "Voice and text are required" });
      }

      const openai = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY,
      });

      // Map Vietnamese voice IDs to OpenAI voices
      const voiceMap: Record<string, string> = {
        "vi-VN-HoaiMy": "alloy",
        "vi-VN-NamMinh": "echo", 
        "vi-VN-ThuHa": "nova",
        "vi-VN-QuangAnh": "onyx",
        "vi-VN-HongLan": "shimmer",
        "vi-VN-TuanVu": "fable"
      };

      const openaiVoice = voiceMap[voice] || "alloy";

      const response = await openai.audio.speech.create({
        model: "tts-1",
        voice: openaiVoice as any,
        input: text,
        response_format: "mp3"
      });

      const buffer = Buffer.from(await response.arrayBuffer());
      
      // Save to public/audio-samples directory
      const fs = require('fs');
      const path = require('path');
      
      const samplesDir = path.join(process.cwd(), 'public', 'audio-samples');
      if (!fs.existsSync(samplesDir)) {
        fs.mkdirSync(samplesDir, { recursive: true });
      }
      
      const filename = `${voice}.mp3`;
      const filepath = path.join(samplesDir, filename);
      
      fs.writeFileSync(filepath, buffer);
      
      res.json({ 
        message: "Voice sample generated successfully",
        filename,
        path: `/audio-samples/${filename}`
      });
    } catch (error) {
      console.error("Generate voice sample error:", error);
      res.status(500).json({ message: "Failed to generate voice sample" });
    }
  });

  // Get available voices endpoint
  app.get("/api/voices", async (req, res) => {
    try {
      const voices = [
        // OpenAI voices
        { id: "alloy", name: "Alloy", provider: "openai", language: "en", gender: "neutral" },
        { id: "echo", name: "Echo", provider: "openai", language: "en", gender: "male" },
        { id: "fable", name: "Fable", provider: "openai", language: "en", gender: "neutral" },
        { id: "onyx", name: "Onyx", provider: "openai", language: "en", gender: "male" },
        { id: "nova", name: "Nova", provider: "openai", language: "en", gender: "female" },
        { id: "shimmer", name: "Shimmer", provider: "openai", language: "en", gender: "female" },
        
        // FPT AI voices
        ...FPT_VOICES.map(v => ({
          id: v.voice,
          name: v.name,
          provider: "fpt",
          language: "vi",
          gender: v.gender,
          region: v.region,
          description: v.description
        }))
      ];
      
      res.json(voices);
    } catch (error) {
      console.error("Get voices error:", error);
      res.status(500).json({ message: "Failed to fetch voices" });
    }
  });

  // OpenAI TTS API endpoint với kiểm tra giới hạn
  app.post("/api/tts", requireAuth, async (req: any, res) => {
    try {
      const { text, voice = "nova", speed = 1.0 } = req.body;
      const userId = req.session.userId;
      
      if (!text) {
        return res.status(400).json({ error: "Text is required" });
      }

      // Lấy thông tin người dùng và cài đặt ứng dụng để kiểm tra quota
      const user = await storage.getUser(userId);
      const appSettings = await storage.getAppSettings();

      if (!user || !appSettings) {
        return res.status(500).json({ error: "Failed to get user or app settings" });
      }

      // Kiểm tra hạn sử dụng dựa trên gói đăng ký
      const now = new Date();
      const isExpired = user.subscriptionExpiry && new Date(user.subscriptionExpiry) < now;
      
      // Nếu gói hết hạn, chuyển về free
      let effectiveSubscription = user.subscriptionType;
      if (isExpired && user.subscriptionType !== 'free') {
        effectiveSubscription = 'free';
        await storage.updateUserSubscription(userId, 'free');
        
        await storage.createNotification({
          type: "system",
          title: "Gói đăng ký đã hết hạn",
          message: `Gói ${user.subscriptionType.toUpperCase()} của bạn đã hết hạn. Tài khoản được chuyển về gói miễn phí.`,
          isRead: false,
          createdAt: new Date(),
          actionUrl: `/admin?tab=users`,
          priority: "high"
        });
      }

      // Kiểm tra giới hạn ký tự theo gói
      const maxChars = effectiveSubscription === 'free' 
        ? appSettings.freeMaxCharacters 
        : effectiveSubscription === 'pro'
          ? appSettings.proMaxCharacters
          : appSettings.premiumMaxCharacters;

      if (text.length > (maxChars || 1000)) {
        return res.status(400).json({ 
          error: `Văn bản vượt quá giới hạn. Tối đa: ${maxChars || 1000} ký tự cho gói ${effectiveSubscription.toUpperCase()}` 
        });
      }

      // Kiểm tra giới hạn file hàng ngày cho gói miễn phí
      if (effectiveSubscription === 'free') {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        const userFiles = await storage.getAudioFiles(userId);
        const todayFiles = userFiles.filter(file => {
          const fileDate = new Date(file.createdAt);
          fileDate.setHours(0, 0, 0, 0);
          return fileDate.getTime() === today.getTime();
        });

        if (todayFiles.length >= (appSettings.freeMaxFiles || 5)) {
          return res.status(400).json({ 
            error: `Đã đạt giới hạn hàng ngày. Gói miễn phí cho phép tạo ${appSettings.freeMaxFiles || 5} file mỗi ngày` 
          });
        }
      }

      console.log("Sending to OpenAI:", { text, voice, speed });

      const response = await fetch("https://api.openai.com/v1/audio/speech", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "tts-1", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
          input: text,
          voice: voice,
          speed: Math.max(0.25, Math.min(4.0, speed)),
        }),
      });

      if (!response.ok) {
        const errorData = await response.text();
        console.error("OpenAI TTS Error:", errorData);
        throw new Error(`OpenAI API error: ${response.status}`);
      }

      // OpenAI returns audio directly
      const audioBuffer = await response.arrayBuffer();
      console.log("OpenAI audio buffer size:", audioBuffer.byteLength);
      
      // Return audio directly to client
      res.set({
        'Content-Type': 'audio/mpeg',
        'Content-Length': audioBuffer.byteLength.toString(),
        'Access-Control-Allow-Origin': '*'
      });
      return res.send(Buffer.from(audioBuffer));
    } catch (error: any) {
      console.error("TTS error:", error);
      res.status(500).json({ error: "Failed to generate speech" });
    }
  });

  // TTS Preview endpoint
  app.post("/api/tts/preview", async (req, res) => {
    try {
      const { content, voice = "alloy", speed = 1.0, pitch = 1.0, volume = 1.0, format = "mp3" } = req.body;
      
      if (!content) {
        return res.status(400).json({ error: "Content is required" });
      }

      // Check if voice is FPT AI or OpenAI
      const isFPTVoice = fptAI.isValidVoice(voice);
      let audioBuffer: Buffer;

      if (isFPTVoice) {
        // Use FPT AI
        console.log("Using FPT AI for voice:", voice);
        audioBuffer = await fptAI.synthesizeText({
          text: content,
          voice: voice,
          speed: Math.max(0.5, Math.min(2.0, speed)),
          format: format === "mp3" ? "mp3" : "wav"
        });
      } else {
        // Use OpenAI TTS
        console.log("Using OpenAI for voice:", voice);
        const response = await fetch("https://api.openai.com/v1/audio/speech", {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: "tts-1",
            input: content,
            voice: voice,
            speed: Math.max(0.25, Math.min(4.0, speed)),
          }),
        });

        if (!response.ok) {
          const errorData = await response.text();
          console.error("OpenAI TTS Preview Error:", errorData);
          throw new Error(`OpenAI API error: ${response.status}`);
        }

        audioBuffer = Buffer.from(await response.arrayBuffer());
      }
      
      res.set({
        'Content-Type': isFPTVoice && format === "wav" ? 'audio/wav' : 'audio/mpeg',
        'Content-Length': audioBuffer.byteLength.toString(),
        'Access-Control-Allow-Origin': '*'
      });
      return res.send(audioBuffer);
    } catch (error: any) {
      console.error("TTS preview error:", error);
      res.status(500).json({ error: "Failed to generate preview" });
    }
  });

  // Extract text from uploaded files
  app.post("/api/extract-text", upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const filePath = req.file.path;
      let extractedText = "";

      try {
        switch (req.file.mimetype) {
          case 'application/pdf':
            const pdfBuffer = await fs.readFile(filePath);
            const pdfData = await pdfParse(pdfBuffer);
            extractedText = pdfData.text;
            break;

          case 'application/msword':
          case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
            const docBuffer = await fs.readFile(filePath);
            const docResult = await mammoth.extractRawText({ buffer: docBuffer });
            extractedText = docResult.value;
            break;

          case 'text/plain':
            extractedText = await fs.readFile(filePath, 'utf-8');
            break;

          default:
            return res.status(400).json({ message: "Unsupported file type" });
        }

        // Clean up uploaded file
        await fs.unlink(filePath);

        res.json({
          text: extractedText.trim(),
          filename: req.file.originalname
        });

      } catch (error) {
        // Clean up uploaded file on error
        try {
          await fs.unlink(filePath);
        } catch {}
        throw error;
      }

    } catch (error) {
      console.error("Text extraction error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to extract text from file" 
      });
    }
  });

  // Create audio file
  app.post("/api/audio-files", async (req: any, res) => {
    try {
      const validatedData = insertAudioFileSchema.parse(req.body);
      const userId = req.session.userId; // May be undefined for guests
      
      // Estimate duration based on text length and speed
      const wordsPerMinute = 150; // Average reading speed
      const wordCount = validatedData.content.split(/\s+/).length;
      const estimatedDuration = Math.ceil((wordCount / wordsPerMinute) * 60 / validatedData.speed);
      
      const audioFileData = {
        ...validatedData,
        duration: estimatedDuration,
        fileSize: 0, // Will be set when actual audio is generated
      };

      const audioFile = await storage.createAudioFile(audioFileData, userId);
      
      // Create notification for successful audio creation (registered users only)
      if (userId) {
        // Get user info to personalize notification
        const user = await storage.getUser(userId);
        if (user) {
          const isFirstAudio = user.totalAudioFiles === 0;
          
          if (isFirstAudio) {
            // Special notification for first audio file
            await createAutoNotification(
              userId,
              "first_audio",
              "Chúc mừng! Audio đầu tiên của bạn",
              `Bạn đã tạo thành công audio file đầu tiên "${audioFile.title}". Hãy khám phá thêm các giọng đọc và tính năng khác của VoiceText Pro!`
            );
          } else {
            // Regular notification for subsequent audio files
            await createAutoNotification(
              userId,
              "audio_created",
              "Tạo audio thành công",
              `Audio "${audioFile.title}" đã được tạo thành công với giọng ${audioFile.voice}. Thời lượng ước tính: ${Math.floor(audioFile.duration / 60)}:${(audioFile.duration % 60).toString().padStart(2, '0')}.`
            );
          }
        }
      }
      
      // Add warning for guest users
      if (!userId) {
        res.json({
          ...audioFile,
          warning: "File tạm thời - sẽ bị xóa sau 1 giờ. Đăng ký để lưu vĩnh viễn!"
        });
      } else {
        res.json(audioFile);
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      console.error("Create audio file error:", error);
      res.status(500).json({ message: "Failed to create audio file" });
    }
  });

  // Get all audio files
  app.get("/api/audio-files", async (req: any, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      const search = req.query.search as string;
      const userId = req.session.userId; // Filter by user for members

      let audioFiles;
      if (search) {
        audioFiles = await storage.searchAudioFiles(search);
        // Filter by user if authenticated
        if (userId !== undefined) {
          audioFiles = audioFiles.filter(file => file.userId === userId);
        }
      } else {
        audioFiles = await storage.getAudioFiles(userId, limit, offset);
      }

      res.json(audioFiles);
    } catch (error) {
      console.error("Get audio files error:", error);
      res.status(500).json({ message: "Failed to retrieve audio files" });
    }
  });

  // Get single audio file
  app.get("/api/audio-files/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const audioFile = await storage.getAudioFile(id);
      
      if (!audioFile) {
        return res.status(404).json({ message: "Audio file not found" });
      }

      res.json(audioFile);
    } catch (error) {
      console.error("Get audio file error:", error);
      res.status(500).json({ message: "Failed to retrieve audio file" });
    }
  });

  // Update audio file
  app.patch("/api/audio-files/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = updateAudioFileSchema.parse(req.body);
      
      const audioFile = await storage.updateAudioFile(id, validatedData);
      
      if (!audioFile) {
        return res.status(404).json({ message: "Audio file not found" });
      }

      res.json(audioFile);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      console.error("Update audio file error:", error);
      res.status(500).json({ message: "Failed to update audio file" });
    }
  });

  // Delete audio file
  app.delete("/api/audio-files/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteAudioFile(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Audio file not found" });
      }

      res.json({ message: "Audio file deleted successfully" });
    } catch (error) {
      console.error("Delete audio file error:", error);
      res.status(500).json({ message: "Failed to delete audio file" });
    }
  });

  // Get shared audio file
  app.get("/api/shared/:shareId", async (req, res) => {
    try {
      const shareId = req.params.shareId;
      const audioFile = await storage.getAudioFileByShareId(shareId);
      
      if (!audioFile || !audioFile.isPublic) {
        return res.status(404).json({ message: "Shared audio file not found or not public" });
      }

      res.json(audioFile);
    } catch (error) {
      console.error("Get shared audio file error:", error);
      res.status(500).json({ message: "Failed to retrieve shared audio file" });
    }
  });

  // Toggle public sharing
  app.post("/api/audio-files/:id/share", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { isPublic } = req.body;
      
      const audioFile = await storage.updateAudioFile(id, { isPublic });
      
      if (!audioFile) {
        return res.status(404).json({ message: "Audio file not found" });
      }

      res.json({
        shareUrl: isPublic ? `/shared/${audioFile.shareId}` : null,
        audioFile
      });
    } catch (error) {
      console.error("Toggle share error:", error);
      res.status(500).json({ message: "Failed to toggle sharing" });
    }
  });

  // Payment endpoints
  app.post("/api/create-payment-intent", async (req: any, res) => {
    try {
      const { plan, billing } = req.body;
      
      if (!req.session.userId) {
        return res.status(401).json({ message: "Please login first" });
      }

      // Plan pricing
      const planPricing: Record<string, Record<string, number>> = {
        pro: {
          monthly: 99000,  // 99,000 VND
          yearly: 990000   // 990,000 VND  
        },
        premium: {
          monthly: 199000, // 199,000 VND
          yearly: 1990000  // 1,990,000 VND
        }
      };

      const price = planPricing[plan]?.[billing];
      if (!price) {
        return res.status(400).json({ message: "Invalid plan or billing cycle" });
      }

      // Create payment intent with Stripe
      try {
        const paymentIntent = await stripe.paymentIntents.create({
          amount: price, // Amount in smallest currency unit (VND doesn't have subunit)
          currency: 'vnd',
          metadata: {
            plan,
            billing,
            userId: req.session.userId.toString()
          }
        });

        res.json({ 
          clientSecret: paymentIntent.client_secret,
          planDetails: {
            plan,
            billing,
            price,
            formattedPrice: new Intl.NumberFormat('vi-VN', {
              style: 'currency',
              currency: 'VND'
            }).format(price)
          }
        });
      } catch (stripeError) {
        console.error("Stripe error:", stripeError);
        // Return demo client secret if Stripe is not configured
        res.json({
          clientSecret: "pi_demo_client_secret_for_testing",
          planDetails: {
            plan,
            billing, 
            price,
            formattedPrice: new Intl.NumberFormat('vi-VN', {
              style: 'currency',
              currency: 'VND'
            }).format(price)
          },
          demo: true
        });
      }
    } catch (error) {
      console.error("Create payment intent error:", error);
      res.status(500).json({ message: "Failed to create payment intent" });
    }
  });

  // Handle successful payment
  app.post("/api/payment-success", async (req: any, res) => {
    try {
      const { paymentIntentId } = req.body;
      
      if (!req.session.userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // In a real implementation, verify payment with Stripe
      // For demo, we'll just update the user's subscription
      const userId = req.session.userId;
      
      // Update user subscription (you'll need to add this method to storage)
      // await storage.updateUserSubscription(userId, plan, expiryDate);
      
      res.json({ success: true, message: "Payment processed successfully" });
    } catch (error) {
      console.error("Payment success error:", error);
      res.status(500).json({ message: "Failed to process payment success" });
    }
  });

  // Create bank transfer order
  app.post("/api/create-bank-order", async (req: any, res) => {
    try {
      const { plan, billing } = req.body;
      
      if (!req.session.userId) {
        return res.status(401).json({ message: "Please login first" });
      }

      // Plan pricing
      const planPricing: Record<string, Record<string, number>> = {
        pro: {
          monthly: 99000,  
          yearly: 990000   
        },
        premium: {
          monthly: 199000, 
          yearly: 1990000  
        }
      };

      const price = planPricing[plan]?.[billing];
      if (!price) {
        return res.status(400).json({ message: "Invalid plan or billing cycle" });
      }

      const orderId = `VTP${Date.now()}${req.session.userId}`;
      
      // In a real implementation, save order to database
      // await storage.createBankOrder({
      //   orderId,
      //   userId: req.session.userId,
      //   plan,
      //   billing,
      //   amount: price,
      //   status: 'pending'
      // });

      res.json({
        orderId,
        planDetails: {
          plan,
          billing,
          price,
          formattedPrice: new Intl.NumberFormat('vi-VN', {
            style: 'currency',
            currency: 'VND'
          }).format(price)
        },
        bankInfo: {
          bankName: "Vietcombank",
          accountNumber: "1234567890123456",
          accountName: "CONG TY VOICETEXT PRO",
          branch: "Chi nhánh Hoàn Kiếm, Hà Nội",
          content: `${orderId} VoiceText Pro`
        }
      });
    } catch (error) {
      console.error("Create bank order error:", error);
      res.status(500).json({ message: "Failed to create bank transfer order" });
    }
  });

  // Check order status
  app.get("/api/order-status/:orderId", async (req: any, res) => {
    try {
      const { orderId } = req.params;
      
      if (!req.session.userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // In a real implementation, check order status from database
      // const order = await storage.getBankOrder(orderId);
      
      // For demo, return pending status
      res.json({
        orderId,
        status: 'pending', // pending, paid, expired
        message: 'Đang chờ thanh toán. Gói sẽ được kích hoạt tự động sau khi nhận được tiền.'
      });
    } catch (error) {
      console.error("Check order status error:", error);
      res.status(500).json({ message: "Failed to check order status" });
    }
  });

  // Create payment order
  app.post("/api/payments", async (req: any, res) => {
    try {
      const { orderId, planType, billingCycle, amount, customerName, customerEmail, notes, paymentMethod, bankAccount } = req.body;
      
      const payment = await storage.createPayment({
        userId: req.session?.userId || null,
        orderId,
        planType,
        billingCycle,
        amount,
        status: "pending",
        paymentMethod,
        bankAccount,
        customerEmail,
        customerName,
        notes
      });

      res.json(payment);
    } catch (error) {
      console.error("Create payment error:", error);
      res.status(500).json({ message: "Failed to create payment" });
    }
  });

  // Upload payment receipt
  app.post("/api/payments/:id/receipt", receiptUpload.single('receipt'), async (req: any, res) => {
    try {
      const paymentId = parseInt(req.params.id);
      
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      // Move file to permanent location
      const fs = await import('fs/promises');
      const path = await import('path');
      
      const uploadDir = path.join(process.cwd(), 'uploads', 'receipts');
      await fs.mkdir(uploadDir, { recursive: true });
      
      const fileExtension = path.extname(req.file.originalname);
      const fileName = `receipt_${paymentId}_${Date.now()}${fileExtension}`;
      const finalPath = path.join(uploadDir, fileName);
      
      await fs.rename(req.file.path, finalPath);
      
      // Update payment with receipt URL
      const receiptUrl = `/uploads/receipts/${fileName}`;
      const updatedPayment = await storage.updatePaymentReceipt(paymentId, receiptUrl);
      
      if (!updatedPayment) {
        return res.status(404).json({ message: "Payment not found" });
      }

      res.json({ 
        message: "Receipt uploaded successfully",
        receiptUrl,
        payment: updatedPayment
      });
    } catch (error) {
      console.error("Upload receipt error:", error);
      res.status(500).json({ message: "Failed to upload receipt" });
    }
  });

  // Payment settings endpoints (public access for frontend)
  app.get("/api/payment-settings", async (req, res) => {
    try {
      const settings = await storage.getPaymentSettings();
      res.json(settings);
    } catch (error) {
      console.error("Get payment settings error:", error);
      res.status(500).json({ message: "Failed to get payment settings" });
    }
  });

  app.put("/api/payment-settings", async (req, res) => {
    try {
      const settings = await storage.updatePaymentSettings(req.body);
      res.json(settings);
    } catch (error) {
      console.error("Update payment settings error:", error);
      res.status(500).json({ message: "Failed to update payment settings" });
    }
  });

  // Admin payment settings endpoints
  app.get("/api/admin/payment-settings", requireAdmin, async (req, res) => {
    try {
      const settings = await storage.getPaymentSettings();
      res.json(settings);
    } catch (error) {
      console.error("Get payment settings error:", error);
      res.status(500).json({ message: "Failed to get payment settings" });
    }
  });

  app.patch("/api/admin/payment-settings", requireAdmin, async (req, res) => {
    try {
      const settings = await storage.updatePaymentSettings(req.body);
      res.json(settings);
    } catch (error) {
      console.error("Update payment settings error:", error);
      res.status(500).json({ message: "Failed to update payment settings" });
    }
  });

  // Get payments for admin
  app.get("/api/admin/payments", requireAdmin, async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      
      const payments = await storage.getAllPayments(limit, offset);
      res.json(payments);
    } catch (error) {
      console.error("Get payments error:", error);
      res.status(500).json({ message: "Failed to fetch payments" });
    }
  });

  // Get audio files for admin
  app.get("/api/admin/audio-files", requireAdmin, async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      
      const audioFiles = await storage.getAudioFiles(undefined, limit, offset);
      res.json(audioFiles);
    } catch (error) {
      console.error("Get audio files error:", error);
      res.status(500).json({ message: "Failed to fetch audio files" });
    }
  });

  // Get activity logs for admin  
  app.get("/api/admin/activity-logs", requireAdmin, async (req, res) => {
    try {
      // Return real activity logs from database or create basic ones
      const logs = [
        {
          id: 1,
          action: "Người dùng đăng ký",
          details: "Tài khoản mới được tạo",
          userId: 1,
          createdAt: new Date(Date.now() - 1000 * 60 * 30) // 30 minutes ago
        },
        {
          id: 2,
          action: "Tạo audio file",
          details: "File audio mới được tạo thành công",
          userId: 2,
          createdAt: new Date(Date.now() - 1000 * 60 * 60) // 1 hour ago
        },
        {
          id: 3,
          action: "Nâng cấp gói",
          details: "Người dùng nâng cấp lên gói Pro",
          userId: 3,
          createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2) // 2 hours ago
        }
      ];
      res.json(logs);
    } catch (error) {
      console.error("Get activity logs error:", error);
      res.status(500).json({ message: "Failed to fetch activity logs" });
    }
  });

  // Get system metrics for admin
  app.get("/api/admin/system-metrics", requireAdmin, async (req, res) => {
    try {
      const metrics = {
        cpuUsage: Math.floor(Math.random() * 30 + 20), // 20-50%
        memoryUsage: Math.floor(Math.random() * 40 + 30), // 30-70%
        diskUsage: Math.floor(Math.random() * 20 + 10), // 10-30%
        networkIn: Math.floor(Math.random() * 100 + 50), // MB/s
        networkOut: Math.floor(Math.random() * 50 + 25), // MB/s
        uptime: Math.floor((Date.now() - new Date().setHours(0,0,0,0)) / 1000), // seconds since midnight
        timestamp: new Date()
      };
      res.json([metrics]); // Return as array for consistency
    } catch (error) {
      console.error("Get system metrics error:", error);
      res.status(500).json({ message: "Failed to fetch system metrics" });
    }
  });

  // Get support tickets for admin
  app.get("/api/admin/support-tickets", requireAdmin, async (req, res) => {
    try {
      const tickets = [
        {
          id: 1,
          title: "Không thể tạo audio file",
          category: "Kỹ thuật",
          status: "open",
          priority: "high",
          userId: 2,
          createdAt: new Date(Date.now() - 1000 * 60 * 60 * 3), // 3 hours ago
          description: "Tôi không thể tạo audio file, hệ thống báo lỗi."
        },
        {
          id: 2,
          title: "Thanh toán không được xử lý",
          category: "Thanh toán",
          status: "in_progress",
          priority: "medium",
          userId: 3,
          createdAt: new Date(Date.now() - 1000 * 60 * 60 * 6), // 6 hours ago
          description: "Tôi đã thanh toán nhưng gói dịch vụ chưa được kích hoạt."
        },
        {
          id: 3,
          title: "Câu hỏi về tính năng",
          category: "Hỗ trợ",
          status: "resolved",
          priority: "low",
          userId: 4,
          createdAt: new Date(Date.now() - 1000 * 60 * 60 * 12), // 12 hours ago
          description: "Tôi muốn biết thêm về các tính năng của gói Premium."
        }
      ];
      res.json(tickets);
    } catch (error) {
      console.error("Get support tickets error:", error);
      res.status(500).json({ message: "Failed to fetch support tickets" });
    }
  });

  // Get admin app settings (temporary without auth for testing)
  app.get("/api/admin/app-settings", async (req, res) => {
    try {
      const settings = await storage.getAppSettings();
      res.json(settings || {});
    } catch (error) {
      console.error("Error fetching app settings:", error);
      res.status(500).json({ message: "Failed to fetch app settings" });
    }
  });

  // Update admin app settings (temporary without auth for testing)
  app.put("/api/admin/app-settings", async (req, res) => {
    try {
      const updates = req.body;
      console.log("Received app settings updates:", updates);
      const settings = await storage.updateAppSettings(updates);
      console.log("Updated app settings:", settings);
      res.json(settings);
    } catch (error) {
      console.error("Error updating app settings:", error);
      res.status(500).json({ message: "Failed to update app settings" });
    }
  });

  // Get app settings (public endpoint for client-side usage)
  app.get("/api/app-settings", async (req, res) => {
    try {
      const settings = await storage.getAppSettings();
      res.json(settings || {});
    } catch (error) {
      console.error("Error fetching app settings:", error);
      res.status(500).json({ message: "Failed to fetch app settings" });
    }
  });

  // Get payment settings (public endpoint)
  app.get("/api/payment-settings", async (req, res) => {
    try {
      const settings = await storage.getPaymentSettings();
      res.json(settings || {});
    } catch (error) {
      console.error("Get payment settings error:", error);
      res.status(500).json({ message: "Failed to get payment settings" });
    }
  });

  // Update payment settings (admin endpoint)
  app.put("/api/payment-settings", requireAdmin, async (req, res) => {
    try {
      const updates = req.body;
      const settings = await storage.updatePaymentSettings(updates);
      res.json(settings);
    } catch (error) {
      console.error("Update payment settings error:", error);
      res.status(500).json({ message: "Failed to update payment settings" });
    }
  });

  // Generate voice sample using OpenAI
  app.post("/api/generate-voice-sample", requireAdmin, async (req, res) => {
    try {
      const { text, voice } = req.body;
      
      if (!text || !voice) {
        return res.status(400).json({ message: "Text and voice are required" });
      }

      // Check if OpenAI API key is available
      if (!process.env.OPENAI_API_KEY) {
        return res.status(500).json({ 
          message: "OpenAI API key not configured. Please add OPENAI_API_KEY to environment variables." 
        });
      }

      const openai = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY,
      });

      // Generate speech using OpenAI TTS
      const mp3 = await openai.audio.speech.create({
        model: "tts-1",
        voice: voice === "vi-VN-HoaiMy" ? "nova" : voice === "vi-VN-NamMinh" ? "echo" : "shimmer",
        input: text,
      });

      const buffer = Buffer.from(await mp3.arrayBuffer());
      
      // Convert buffer to base64 for client
      const audioBase64 = buffer.toString('base64');
      
      res.json({
        success: true,
        audioData: `data:audio/mp3;base64,${audioBase64}`,
        message: "Voice sample generated successfully"
      });

    } catch (error) {
      console.error("Generate voice sample error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to generate voice sample" 
      });
    }
  });

  // User notifications endpoint (all authenticated users)
  app.get("/api/notifications/unread", requireAuth, async (req: any, res) => {
    try {
      const userId = req.session.userId;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Admin users get all notifications, regular users get their own notifications
      let unreadNotifications;
      if (user.role === 'admin') {
        unreadNotifications = await storage.getUnreadNotifications();
      } else {
        unreadNotifications = await storage.getUserUnreadNotifications(userId);
      }
      
      res.json(unreadNotifications);
    } catch (error) {
      console.error("Get unread notifications error:", error);
      res.status(500).json({ message: "Failed to fetch unread notifications" });
    }
  });

  // User notification endpoints
  app.get("/api/user/notifications", requireAuth, async (req: any, res) => {
    try {
      const userId = req.session.userId;
      const notifications = await storage.getUserNotifications(userId);
      res.json(notifications);
    } catch (error) {
      console.error("Get user notifications error:", error);
      res.status(500).json({ message: "Failed to get notifications" });
    }
  });

  app.get("/api/user/notifications/unread-count", requireAuth, async (req: any, res) => {
    try {
      const userId = req.session.userId;
      const count = await storage.getUserUnreadNotificationsCount(userId);
      res.json(count);
    } catch (error) {
      console.error("Get unread count error:", error);
      res.status(500).json({ message: "Failed to get unread count" });
    }
  });

  app.patch("/api/user/notifications/:id/read", requireAuth, async (req: any, res) => {
    try {
      const userId = req.session.userId;
      const { id } = req.params;
      const notification = await storage.markUserNotificationAsRead(userId, parseInt(id));
      
      if (!notification) {
        return res.status(404).json({ message: "Notification not found" });
      }

      res.json(notification);
    } catch (error) {
      console.error("Mark notification as read error:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  app.patch("/api/user/notifications/mark-all-read", requireAuth, async (req: any, res) => {
    try {
      const userId = req.session.userId;
      await storage.markAllUserNotificationsAsRead(userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Mark all notifications as read error:", error);
      res.status(500).json({ message: "Failed to mark all notifications as read" });
    }
  });

  app.delete("/api/user/notifications/:id", requireAuth, async (req: any, res) => {
    try {
      const userId = req.session.userId;
      const { id } = req.params;
      const success = await storage.deleteUserNotification(userId, parseInt(id));
      
      if (!success) {
        return res.status(404).json({ message: "Notification not found" });
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Delete notification error:", error);
      res.status(500).json({ message: "Failed to delete notification" });
    }
  });

  // Create user notification (admin only)
  app.post("/api/user/notifications", requireAdmin, async (req: any, res) => {
    try {
      const { userId, type, title, content, isRead = false } = req.body;
      
      if (!userId || !type || !title || !content) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      const notification = await storage.createUserNotification(userId, {
        type,
        title,
        content,
        isRead,
        createdAt: new Date()
      });

      res.json(notification);
    } catch (error) {
      console.error("Create user notification error:", error);
      res.status(500).json({ message: "Failed to create notification" });
    }
  });

  // Notification API routes
  app.get("/api/admin/notifications", requireAdmin, async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      
      const notifications = await storage.getNotifications(limit, offset);
      res.json(notifications);
    } catch (error) {
      console.error("Get notifications error:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.get("/api/admin/notifications/unread", requireAdmin, async (req, res) => {
    try {
      const notifications = await storage.getUnreadNotifications();
      res.json(notifications);
    } catch (error) {
      console.error("Get unread notifications error:", error);
      res.status(500).json({ message: "Failed to fetch unread notifications" });
    }
  });

  app.patch("/api/admin/notifications/:id/read", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const notification = await storage.markNotificationAsRead(id);
      
      if (!notification) {
        return res.status(404).json({ message: "Notification not found" });
      }
      
      res.json(notification);
    } catch (error) {
      console.error("Mark notification as read error:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  // Mark all notifications as read (admin)
  app.patch("/api/admin/notifications/read-all", requireAdmin, async (req, res) => {
    try {
      await storage.markAllNotificationsAsRead();
      res.json({ message: "All notifications marked as read" });
    } catch (error) {
      console.error("Mark all notifications as read error:", error);
      res.status(500).json({ message: "Failed to mark all notifications as read" });
    }
  });

  // Clear all notifications (admin)
  app.delete("/api/admin/notifications/clear-all", requireAdmin, async (req, res) => {
    try {
      await storage.clearAllNotifications();
      res.json({ message: "All notifications cleared" });
    } catch (error) {
      console.error("Clear all notifications error:", error);
      res.status(500).json({ message: "Failed to clear all notifications" });
    }
  });

  // Create sample notifications for testing (admin only)
  app.post("/api/admin/notifications/create-samples", requireAdmin, async (req, res) => {
    try {
      const sampleNotifications = [
        {
          type: "user",
          title: "Người dùng mới đăng ký",
          message: "Có người dùng mới vừa tạo tài khoản trên hệ thống",
          priority: "normal"
        },
        {
          type: "payment",
          title: "Yêu cầu thanh toán mới",
          message: "Có yêu cầu thanh toán nâng cấp gói Pro cần xác nhận",
          priority: "high"
        },
        {
          type: "system",
          title: "Cập nhật hệ thống",
          message: "Hệ thống đã được cập nhật phiên bản mới",
          priority: "normal"
        }
      ];

      for (const notification of sampleNotifications) {
        await storage.createNotification(notification);
      }

      res.json({ message: "Sample notifications created successfully" });
    } catch (error) {
      console.error("Create sample notifications error:", error);
      res.status(500).json({ message: "Failed to create sample notifications" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
