import fetch from 'node-fetch';

if (!process.env.FPT_API_KEY) {
  throw new Error("FPT_API_KEY environment variable must be set");
}

export interface FPTVoice {
  voice: string;
  name: string;
  gender: string;
  region: string;
  description: string;
}

export const FPT_VOICES: FPTVoice[] = [
  {
    voice: 'banmai',
    name: 'Ban Mai',
    gender: 'female',
    region: 'north',
    description: 'Giọng nữ miền Bắc, tự nhiên'
  },
  {
    voice: 'leminh',
    name: 'Lê Minh',
    gender: 'male',
    region: 'north',
    description: 'Giọng nam miền Bắc, mạnh mẽ'
  },
  {
    voice: 'thuminh',
    name: 'Thu Minh',
    gender: 'female',
    region: 'south',
    description: 'Giọng nữ miền Nam, dịu dàng'
  },
  {
    voice: 'giahuy',
    name: 'Gia Huy',
    gender: 'male',
    region: 'south',
    description: 'Giọng nam miền Nam, trầm ấm'
  },
  {
    voice: 'ngoclam',
    name: 'Ngọc Lam',
    gender: 'female',
    region: 'central',
    description: 'Giọng nữ miền Trung, thanh thoát'
  }
];

export interface FPTTTSRequest {
  text: string;
  voice: string;
  speed?: number; // 0.5 - 2.0, default 1.0
  format?: 'wav' | 'mp3'; // default 'wav'
}

export interface FPTTTSResponse {
  async: string;
  error?: number;
  message?: string;
}

export interface FPTTTSResult {
  finished: boolean;
  request_id: string;
  url?: string;
  error?: number;
  message?: string;
}

class FPTAIService {
  private readonly baseUrl = 'https://api.fpt.ai/hmi/tts/v5';
  private readonly apiKey = process.env.FPT_API_KEY!;

  async synthesizeText(request: FPTTTSRequest): Promise<Buffer> {
    try {
      // Step 1: Request synthesis
      const synthesisResponse = await fetch(`${this.baseUrl}`, {
        method: 'POST',
        headers: {
          'api-key': this.apiKey,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text: request.text,
          voice: request.voice,
          speed: request.speed || 1.0,
          format: request.format || 'wav'
        }),
      });

      if (!synthesisResponse.ok) {
        throw new Error(`FPT AI synthesis failed: ${synthesisResponse.status}`);
      }

      const synthesisResult: FPTTTSResponse = await synthesisResponse.json() as FPTTTSResponse;
      
      if (synthesisResult.error) {
        throw new Error(`FPT AI error: ${synthesisResult.message}`);
      }

      const requestId = synthesisResult.async;

      // Step 2: Poll for completion
      let attempts = 0;
      const maxAttempts = 30; // 30 seconds max wait
      
      while (attempts < maxAttempts) {
        await new Promise(resolve => setTimeout(resolve, 1000)); // Wait 1 second
        
        const resultResponse = await fetch(`${this.baseUrl}/${requestId}`, {
          method: 'GET',
          headers: {
            'api-key': this.apiKey,
          },
        });

        if (!resultResponse.ok) {
          throw new Error(`FPT AI result check failed: ${resultResponse.status}`);
        }

        const result: FPTTTSResult = await resultResponse.json() as FPTTTSResult;
        
        if (result.error) {
          throw new Error(`FPT AI error: ${result.message}`);
        }

        if (result.finished && result.url) {
          // Step 3: Download the audio file
          const audioResponse = await fetch(result.url);
          if (!audioResponse.ok) {
            throw new Error(`Failed to download audio: ${audioResponse.status}`);
          }
          
          const audioBuffer = await audioResponse.buffer();
          return audioBuffer;
        }

        attempts++;
      }

      throw new Error('FPT AI synthesis timeout');
    } catch (error) {
      console.error('FPT AI synthesis error:', error);
      throw error;
    }
  }

  getAvailableVoices(): FPTVoice[] {
    return FPT_VOICES;
  }

  isValidVoice(voice: string): boolean {
    return FPT_VOICES.some(v => v.voice === voice);
  }
}

export const fptAI = new FPTAIService();