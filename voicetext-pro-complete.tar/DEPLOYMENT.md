# VoiceText Pro - Deployment Guide

## Environment Variables Required

### Database
- DATABASE_URL=postgresql://username:password@host:port/database

### API Keys
- FPT_API_KEY=your_fpt_api_key
- OPENAI_API_KEY=your_openai_api_key

### Session
- SESSION_SECRET=your_random_session_secret_here

## Database Setup

1. Create PostgreSQL database
2. Run migrations:
   ```bash
   npm run db:push
   ```

## Production Deployment

1. Install dependencies:
   ```bash
   npm install
   ```

2. Build the project:
   ```bash
   npm run build
   ```

3. Start production server:
   ```bash
   npm run start
   ```

## File Structure
- `client/` - React frontend
- `server/` - Express backend
- `shared/` - Shared types and schemas
- `uploads/` - Audio file storage (create this directory)

## Important Notes
- Make sure uploads directory exists and is writable
- Configure your hosting to serve static files from dist/
- Set NODE_ENV=production for production builds
- Ensure database connection is stable for best performance
