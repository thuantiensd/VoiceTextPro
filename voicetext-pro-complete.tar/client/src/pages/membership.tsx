import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { 
  Crown, 
  Star, 
  Gem, 
  Check, 
  X, 
  Zap,
  Clock,
  FileAudio,
  Mic,
  Settings
} from "lucide-react";

export default function Membership() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  
  // Lấy cài đặt app để biết giá và giới hạn
  const { data: appSettings } = useQuery({
    queryKey: ["/api/app-settings"]
  });

  const plans = [
    {
      id: "free",
      name: "Miễn phí",
      icon: <Star className="h-8 w-8 text-gray-500" />,
      price: "0",
      period: "Vĩnh viễn",
      description: "Dành cho người dùng cá nhân",
      maxFiles: appSettings?.freeMaxFiles || 5,
      maxCharacters: appSettings?.freeMaxCharacters || 1000,
      features: [
        "Giọng đọc cơ bản",
        "Định dạng MP3",
        "Tốc độ tiêu chuẩn",
        "Hỗ trợ email"
      ],
      limitations: [
        "Giới hạn số file",
        "Giới hạn số ký tự",
        "Không có giọng premium",
        "Không thể điều chỉnh nâng cao"
      ],
      buttonText: "Gói hiện tại",
      buttonVariant: "outline" as const,
      popular: false
    },
    {
      id: "pro",
      name: "Pro",
      icon: <Zap className="h-8 w-8 text-blue-500" />,
      price: "199.000",
      period: "tháng",
      description: "Dành cho doanh nghiệp nhỏ",
      maxFiles: appSettings?.proMaxFiles || 100,
      maxCharacters: appSettings?.proMaxCharacters || 50000,
      features: [
        "Tất cả giọng đọc",
        "Nhiều định dạng (MP3, WAV)",
        "Điều chỉnh tốc độ, cao độ",
        "Ưu tiên hỗ trợ",
        "Xuất file chất lượng cao",
        "API access"
      ],
      limitations: [],
      buttonText: "Nâng cấp Pro",
      buttonVariant: "default" as const,
      popular: true
    },
    {
      id: "premium",
      name: "Premium",
      icon: <Crown className="h-8 w-8 text-purple-500" />,
      price: "399.000",
      period: "tháng",
      description: "Dành cho doanh nghiệp lớn",
      maxFiles: appSettings?.premiumMaxFiles || 500,
      maxCharacters: appSettings?.premiumMaxCharacters || 200000,
      features: [
        "Tất cả tính năng Pro",
        "Giọng đọc AI cao cấp",
        "Tùy chỉnh giọng nói",
        "Batch processing",
        "Hỗ trợ 24/7",
        "Tích hợp enterprise",
        "Backup & sync cloud"
      ],
      limitations: [],
      buttonText: "Nâng cấp Premium",
      buttonVariant: "default" as const,
      popular: false
    }
  ];

  const handleUpgrade = (planId: string) => {
    if (!isAuthenticated) {
      toast({
        title: "Yêu cầu đăng nhập",
        description: "Vui lòng đăng nhập để nâng cấp gói dịch vụ",
        variant: "destructive"
      });
      return;
    }

    // Chuyển hướng đến trang thanh toán
    window.location.href = `/payment?plan=${planId}`;
  };

  const getCurrentPlanInfo = () => {
    if (!user) return plans[0];
    return plans.find(plan => plan.id === user.subscriptionType) || plans[0];
  };

  const currentPlan = getCurrentPlanInfo();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Gem className="h-8 w-8 text-purple-600" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Gói thành viên
            </h1>
          </div>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Chọn gói dịch vụ phù hợp với nhu cầu của bạn
          </p>
        </div>

        {/* Current Plan Status */}
        {isAuthenticated && (
          <div className="mb-8">
            <Card className="bg-gradient-to-r from-blue-500 to-purple-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    {currentPlan.icon}
                    <div>
                      <h3 className="text-xl font-semibold">Gói hiện tại: {currentPlan.name}</h3>
                      <p className="text-blue-100">
                        {user?.subscriptionExpiry 
                          ? `Hết hạn: ${new Date(user.subscriptionExpiry).toLocaleDateString('vi-VN')}`
                          : "Không giới hạn thời gian"
                        }
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-blue-100">Đã sử dụng</div>
                    <div className="text-lg font-semibold">
                      {user?.totalAudioFiles || 0}/{currentPlan.maxFiles} files
                    </div>
                    <div className="text-lg font-semibold">
                      {user?.totalCharactersUsed || 0}/{currentPlan.maxCharacters} ký tự
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Pricing Plans */}
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan) => (
            <Card 
              key={plan.id} 
              className={`relative overflow-hidden transition-all hover:shadow-xl ${
                plan.popular ? 'ring-2 ring-blue-500 scale-105' : ''
              } ${
                user?.subscriptionType === plan.id ? 'bg-green-50 dark:bg-green-900/20 border-green-300' : ''
              }`}
            >
              {plan.popular && (
                <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-blue-500 to-purple-600 text-white text-center py-2 text-sm font-semibold">
                  Phổ biến nhất
                </div>
              )}
              
              <CardHeader className={plan.popular ? 'pt-8' : ''}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {plan.icon}
                    <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  </div>
                  {user?.subscriptionType === plan.id && (
                    <Badge className="bg-green-500 text-white">Đang sử dụng</Badge>
                  )}
                </div>
                <CardDescription className="text-base">{plan.description}</CardDescription>
                
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-bold">{plan.price.toLocaleString()}</span>
                  <span className="text-lg">₫</span>
                  <span className="text-muted-foreground">/{plan.period}</span>
                </div>
              </CardHeader>

              <CardContent className="space-y-6">
                {/* Usage Limits */}
                <div className="bg-muted/50 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Settings className="h-4 w-4" />
                    Giới hạn sử dụng
                  </h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-2">
                        <FileAudio className="h-3 w-3" />
                        Số file tối đa
                      </span>
                      <span className="font-semibold">{plan.maxFiles}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-2">
                        <Mic className="h-3 w-3" />
                        Ký tự/tháng
                      </span>
                      <span className="font-semibold">{plan.maxCharacters.toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                {/* Features */}
                <div className="space-y-3">
                  <h4 className="font-semibold">Tính năng bao gồm:</h4>
                  <ul className="space-y-2">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-center gap-2 text-sm">
                        <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Limitations */}
                {plan.limitations.length > 0 && (
                  <div className="space-y-3">
                    <h4 className="font-semibold text-orange-600">Giới hạn:</h4>
                    <ul className="space-y-2">
                      {plan.limitations.map((limitation, index) => (
                        <li key={index} className="flex items-center gap-2 text-sm text-muted-foreground">
                          <X className="h-4 w-4 text-orange-500 flex-shrink-0" />
                          <span>{limitation}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Action Button */}
                <Button 
                  className="w-full" 
                  variant={user?.subscriptionType === plan.id ? "outline" : plan.buttonVariant}
                  onClick={() => handleUpgrade(plan.id)}
                  disabled={user?.subscriptionType === plan.id || (plan.id === "free" && user?.subscriptionType !== "free")}
                >
                  {user?.subscriptionType === plan.id ? "Gói hiện tại" : plan.buttonText}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* FAQ Section */}
        <div className="mt-16 max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold text-center mb-8">Câu hỏi thường gặp</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Tôi có thể thay đổi gói bất cứ lúc nào?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Có, bạn có thể nâng cấp hoặc hạ cấp gói bất cứ lúc nào. Thay đổi sẽ có hiệu lực ngay lập tức.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Phương thức thanh toán nào được hỗ trợ?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Chúng tôi hỗ trợ chuyển khoản ngân hàng, ví điện tử và thẻ tín dụng/ghi nợ.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Có thể hủy gói đăng ký không?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Có, bạn có thể hủy đăng ký bất cứ lúc nào. Bạn vẫn có thể sử dụng dịch vụ đến hết chu kỳ đã thanh toán.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Dữ liệu có được bảo mật không?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Tất cả dữ liệu được mã hóa và bảo mật theo tiêu chuẩn quốc tế. Chúng tôi không chia sẻ thông tin với bên thứ ba.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}