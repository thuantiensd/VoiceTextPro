import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { User, AudioFile, ActivityLog, SystemMetric, SupportTicket } from "@shared/schema";
import { 
  Users, 
  Search, 
  Edit, 
  Trash2, 
  FileAudio,
  ArrowLeft,
  CreditCard,
  BarChart3,
  MessageSquare,
  Eye,
  FileText,
  Plus,
  Volume2,
  TrendingUp,
  DollarSign,
  Clock,
  Settings,
  HeadphonesIcon,
  Activity,
  Globe,
  Server,
  Shield,
  AlertTriangle,
  CheckCircle,
  Timer,
  Calendar,
  Zap
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell, AreaChart, Area } from 'recharts';
import { format, subDays, startOfDay } from 'date-fns';

export default function AdminDashboard() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("overview");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedVoice, setSelectedVoice] = useState("vi-VN-HoaiMy");
  const [sampleText, setSampleText] = useState("Xin chào, đây là mẫu giọng nói tiếng Việt chất lượng cao.");
  const [isGeneratingSample, setIsGeneratingSample] = useState(false);
  const [timeRange, setTimeRange] = useState("7d");

  // Fetch data
  const { data: users = [], isLoading: usersLoading } = useQuery({
    queryKey: ["/api/admin/users"],
  });

  const { data: audioFiles = [], isLoading: audioLoading } = useQuery({
    queryKey: ["/api/admin/audio-files"],
  });

  const { data: payments = [], isLoading: paymentsLoading } = useQuery({
    queryKey: ["/api/admin/payments"],
  });

  const { data: analytics = {}, isLoading: analyticsLoading } = useQuery({
    queryKey: ["/api/admin/analytics", timeRange],
  });

  const { data: activityLogs = [], isLoading: logsLoading } = useQuery({
    queryKey: ["/api/admin/activity-logs"],
  });

  // Fetch app settings
  const { data: appSettings = {}, isLoading: appSettingsLoading } = useQuery({
    queryKey: ["/api/app-settings"],
  });

  // Update app settings mutation
  const updateAppSettings = useMutation({
    mutationFn: async (settings: any) => {
      const response = await apiRequest("POST", "/api/app-settings", settings);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Cập nhật thành công",
        description: "Cài đặt ứng dụng đã được cập nhật",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/app-settings"] });
    },
    onError: (error) => {
      toast({
        title: "Lỗi cập nhật",
        description: "Không thể cập nhật cài đặt ứng dụng",
        variant: "destructive",
      });
    },
  });

  const handleUpdateAppSettings = (event: React.FormEvent) => {
    event.preventDefault();
    const formData = new FormData(event.target as HTMLFormElement);
    const settings = {
      maxCharacters: parseInt(formData.get("maxCharacters") as string),
      maxFilesPerUser: parseInt(formData.get("maxFilesPerUser") as string),
      maxFileSize: parseInt(formData.get("maxFileSize") as string),
      spellCheckEnabled: formData.get("spellCheckEnabled") === "on",
      voicePreviewEnabled: formData.get("voicePreviewEnabled") === "on",
      defaultFormat: formData.get("defaultFormat") as string,
      defaultVoice: formData.get("defaultVoice") as string,
      audioQuality: formData.get("audioQuality") as string,
      cacheDuration: parseInt(formData.get("cacheDuration") as string),
      maintenanceMode: formData.get("maintenanceMode") === "on",
      registrationEnabled: formData.get("registrationEnabled") === "on",
      rateLimitingEnabled: formData.get("rateLimitingEnabled") === "on",
    };
    updateAppSettings.mutate(settings);
  };

  const { data: supportTickets = [], isLoading: ticketsLoading } = useQuery({
    queryKey: ["/api/admin/support-tickets"],
  });

  const { data: systemHealth = {}, isLoading: healthLoading } = useQuery({
    queryKey: ["/api/admin/system-health"],
  });

  // Generate voice sample mutation
  const generateVoiceSampleMutation = useMutation({
    mutationFn: async ({ voice, text }: { voice: string; text: string }) => {
      const response = await apiRequest("POST", "/api/admin/generate-voice-sample", {
        voice,
        text,
      });
      return response;
    },
    onSuccess: () => {
      setIsGeneratingSample(false);
      toast({
        title: "Thành công",
        description: "Đã tạo mẫu giọng nói",
      });
    },
    onError: (error: any) => {
      setIsGeneratingSample(false);
      toast({
        title: "Lỗi",
        description: error.message || "Không thể tạo mẫu giọng nói",
        variant: "destructive",
      });
    },
  });

  // Delete user mutation
  const deleteUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      await apiRequest("DELETE", `/api/admin/users/${userId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({ title: "Thành công", description: "Đã xóa người dùng" });
    },
  });

  // Update user mutation
  const updateUserMutation = useMutation({
    mutationFn: async ({ userId, updates }: { userId: number; updates: any }) => {
      await apiRequest("PATCH", `/api/admin/users/${userId}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      setIsEditDialogOpen(false);
      toast({ title: "Thành công", description: "Đã cập nhật người dùng" });
    },
  });

  // Calculate stats
  const totalUsers = (users as any[]).length;
  const totalAudioFiles = (audioFiles as any[]).length;
  const proUsers = (users as any[]).filter((user: User) => user.subscriptionType === "pro").length;
  const premiumUsers = (users as any[]).filter((user: User) => user.subscriptionType === "premium").length;
  const activeUsers = (users as any[]).filter((user: User) => {
    const lastActive = new Date(user.updatedAt || user.createdAt);
    const sevenDaysAgo = subDays(new Date(), 7);
    return lastActive > sevenDaysAgo;
  }).length;

  // Mock data for charts (in real app, this comes from analytics API)
  const revenueData = [
    { date: '2025-01-01', revenue: 1200000, users: 45 },
    { date: '2025-01-02', revenue: 1800000, users: 52 },
    { date: '2025-01-03', revenue: 2100000, users: 61 },
    { date: '2025-01-04', revenue: 1900000, users: 58 },
    { date: '2025-01-05', revenue: 2400000, users: 67 },
    { date: '2025-01-06', revenue: 2800000, users: 74 },
    { date: '2025-01-07', revenue: 3200000, users: 82 },
  ];

  const voiceUsageData = [
    { voice: 'Hoài My', usage: 340, percentage: 28 },
    { voice: 'Nam Minh', usage: 290, percentage: 24 },
    { voice: 'Thu Hà', usage: 250, percentage: 21 },
    { voice: 'Quang Anh', usage: 180, percentage: 15 },
    { voice: 'Hồng Lan', usage: 140, percentage: 12 },
  ];

  const subscriptionData = [
    { name: 'Free', value: totalUsers - proUsers - premiumUsers, color: '#8884d8' },
    { name: 'Pro', value: proUsers, color: '#82ca9d' },
    { name: 'Premium', value: premiumUsers, color: '#ffc658' },
  ];

  const userActivityData = [
    { hour: '00:00', active: 12 },
    { hour: '04:00', active: 8 },
    { hour: '08:00', active: 45 },
    { hour: '12:00', active: 67 },
    { hour: '16:00', active: 89 },
    { hour: '20:00', active: 56 },
  ];

  const filteredUsers = (users as any[]).filter((user: User) =>
    user.username?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleGenerateVoiceSample = () => {
    if (!selectedVoice || !sampleText.trim()) {
      toast({
        title: "Lỗi",
        description: "Vui lòng chọn giọng và nhập văn bản mẫu",
        variant: "destructive",
      });
      return;
    }
    setIsGeneratingSample(true);
    generateVoiceSampleMutation.mutate({ voice: selectedVoice, text: sampleText });
  };

  const voices = [
    { id: "vi-VN-HoaiMy", name: "👩 Hoài My - Giọng nữ miền Bắc" },
    { id: "vi-VN-NamMinh", name: "👨 Nam Minh - Giọng nam miền Bắc" },
    { id: "vi-VN-ThuHa", name: "👩 Thu Hà - Giọng nữ miền Trung" },
    { id: "vi-VN-QuangAnh", name: "👨 Quang Anh - Giọng nam miền Nam" },
    { id: "vi-VN-HongLan", name: "👩 Hồng Lan - Giọng nữ miền Nam" },
    { id: "vi-VN-TuanVu", name: "👨 Tuấn Vũ - Giọng nam trầm ấm" }
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Dashboard Quản Trị VoiceText Pro</h1>
            <p className="text-gray-600 dark:text-gray-400">
              Giám sát hiệu suất hệ thống và quản lý toàn diện
            </p>
          </div>
          <div className="flex items-center gap-4">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">7 ngày</SelectItem>
                <SelectItem value="30d">30 ngày</SelectItem>
                <SelectItem value="90d">90 ngày</SelectItem>
              </SelectContent>
            </Select>
            <Button 
              variant="outline" 
              onClick={() => window.location.href = '/'}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Về trang chủ
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <div className="overflow-x-auto">
            <TabsList className="grid w-max min-w-full grid-cols-9 md:grid-cols-9 gap-1">
              <TabsTrigger value="overview" className="flex items-center gap-1 text-xs md:text-sm">
                <BarChart3 className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden sm:inline">Tổng quan</span>
              </TabsTrigger>
              <TabsTrigger value="analytics" className="flex items-center gap-1 text-xs md:text-sm">
                <TrendingUp className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden sm:inline">Phân tích</span>
              </TabsTrigger>
              <TabsTrigger value="users" className="flex items-center gap-1 text-xs md:text-sm">
                <Users className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden sm:inline">Người dùng</span>
              </TabsTrigger>
              <TabsTrigger value="audio" className="flex items-center gap-1 text-xs md:text-sm">
                <FileAudio className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden sm:inline">Audio</span>
              </TabsTrigger>
              <TabsTrigger value="payments" className="flex items-center gap-1 text-xs md:text-sm">
                <CreditCard className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden sm:inline">Thanh toán</span>
              </TabsTrigger>
              <TabsTrigger value="support" className="flex items-center gap-1 text-xs md:text-sm">
                <MessageSquare className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden sm:inline">Hỗ trợ</span>
              </TabsTrigger>
              <TabsTrigger value="system" className="flex items-center gap-1 text-xs md:text-sm">
                <Settings className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden sm:inline">Hệ thống</span>
              </TabsTrigger>
              <TabsTrigger value="app-settings" className="flex items-center gap-1 text-xs md:text-sm">
                <Zap className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden sm:inline">Cài đặt app</span>
              </TabsTrigger>
              <TabsTrigger value="voice-samples" className="flex items-center gap-1 text-xs md:text-sm">
                <Volume2 className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden sm:inline">Mẫu giọng</span>
              </TabsTrigger>
            </TabsList>
          </div>

          {/* Overview Tab - Enhanced */}
          <TabsContent value="overview" className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card className="border-l-4 border-l-blue-500">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Tổng người dùng</p>
                      <p className="text-3xl font-bold text-blue-600">{totalUsers}</p>
                      <p className="text-xs text-green-600">+12% so với tuần trước</p>
                    </div>
                    <Users className="h-8 w-8 text-blue-500" />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-l-green-500">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Người dùng hoạt động</p>
                      <p className="text-3xl font-bold text-green-600">{activeUsers}</p>
                      <p className="text-xs text-green-600">+8% so với tuần trước</p>
                    </div>
                    <Activity className="h-8 w-8 text-green-500" />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-l-orange-500">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">File audio</p>
                      <p className="text-3xl font-bold text-orange-600">{totalAudioFiles}</p>
                      <p className="text-xs text-green-600">+24% so với tuần trước</p>
                    </div>
                    <FileAudio className="h-8 w-8 text-orange-500" />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-l-purple-500">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Doanh thu tháng</p>
                      <p className="text-3xl font-bold text-purple-600">₫28.5M</p>
                      <p className="text-xs text-green-600">+15% so với tháng trước</p>
                    </div>
                    <DollarSign className="h-8 w-8 text-purple-500" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Charts Row */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Revenue Chart */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Xu hướng doanh thu 7 ngày
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={revenueData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" tickFormatter={(value) => format(new Date(value), 'dd/MM')} />
                      <YAxis tickFormatter={(value) => `₫${(value / 1000000).toFixed(1)}M`} />
                      <Tooltip 
                        labelFormatter={(value) => format(new Date(value), 'dd/MM/yyyy')}
                        formatter={(value: any) => [`₫${(value / 1000).toLocaleString()}K`, 'Doanh thu']}
                      />
                      <Area type="monotone" dataKey="revenue" stroke="#8884d8" fill="#8884d8" fillOpacity={0.3} />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Subscription Distribution */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Phân bố gói đăng ký
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={subscriptionData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percentage }) => `${name}: ${percentage}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {subscriptionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* System Health */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Trạng thái API</p>
                      <p className="text-lg font-semibold text-green-600">Hoạt động tốt</p>
                      <p className="text-xs text-gray-500">Uptime: 99.9%</p>
                    </div>
                    <CheckCircle className="h-6 w-6 text-green-500" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Thời gian phản hồi</p>
                      <p className="text-lg font-semibold text-blue-600">142ms</p>
                      <p className="text-xs text-green-600">-8% so với hôm qua</p>
                    </div>
                    <Zap className="h-6 w-6 text-blue-500" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Lưu trữ đã sử dụng</p>
                      <p className="text-lg font-semibold text-orange-600">2.4GB</p>
                      <p className="text-xs text-gray-500">/ 100GB</p>
                    </div>
                    <Server className="h-6 w-6 text-orange-500" />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Analytics Tab - New */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Voice Usage Chart */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <HeadphonesIcon className="h-5 w-5" />
                    Top giọng được sử dụng
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={voiceUsageData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="voice" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="usage" fill="#8884d8" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* User Activity by Hour */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="h-5 w-5" />
                    Hoạt động theo giờ
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={userActivityData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="hour" />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="active" stroke="#82ca9d" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Detailed Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardContent className="pt-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-blue-600">1,234</p>
                    <p className="text-sm text-gray-600">Phút audio tạo ra</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-green-600">456K</p>
                    <p className="text-sm text-gray-600">Ký tự xử lý</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-orange-600">78%</p>
                    <p className="text-sm text-gray-600">Tỷ lệ chuyển đổi</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-purple-600">92%</p>
                    <p className="text-sm text-gray-600">Độ hài lòng</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Users Tab - Enhanced */}
          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Quản lý người dùng</span>
                  <div className="flex items-center gap-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        placeholder="Tìm kiếm người dùng..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10 w-64"
                      />
                    </div>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Người dùng</TableHead>
                      <TableHead>Gói</TableHead>
                      <TableHead>Hoạt động cuối</TableHead>
                      <TableHead>Files</TableHead>
                      <TableHead>Trạng thái</TableHead>
                      <TableHead className="text-right">Thao tác</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredUsers.slice(0, 10).map((user: User) => (
                      <TableRow key={user.id}>
                        <TableCell>
                          <div>
                            <p className="font-medium">{user.username}</p>
                            <p className="text-sm text-gray-500">{user.email}</p>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant={
                              user.subscriptionType === 'premium' ? 'default' :
                              user.subscriptionType === 'pro' ? 'secondary' : 'outline'
                            }
                          >
                            {user.subscriptionType}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {user.updatedAt ? format(new Date(user.updatedAt), 'dd/MM/yyyy HH:mm') : 'N/A'}
                        </TableCell>
                        <TableCell>{user.totalAudioFiles || 0}</TableCell>
                        <TableCell>
                          <Badge variant={user.isActive ? 'default' : 'destructive'}>
                            {user.isActive ? 'Hoạt động' : 'Khóa'}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end space-x-2">
                            <Button variant="outline" size="sm">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm">
                              <Edit className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Audio Tab - Enhanced */}
          <TabsContent value="audio" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Quản lý file audio</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Tiêu đề</TableHead>
                      <TableHead>Người tạo</TableHead>
                      <TableHead>Giọng</TableHead>
                      <TableHead>Thời lượng</TableHead>
                      <TableHead>Kích thước</TableHead>
                      <TableHead>Ngày tạo</TableHead>
                      <TableHead className="text-right">Thao tác</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(audioFiles as any[]).slice(0, 20).map((file: any) => (
                      <TableRow key={file.id}>
                        <TableCell className="font-medium">{file.title}</TableCell>
                        <TableCell>
                          {(users as any[]).find((u: User) => u.id === file.userId)?.username || "Unknown"}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{file.voice}</Badge>
                        </TableCell>
                        <TableCell>{file.duration || 0}s</TableCell>
                        <TableCell>{(file.fileSize / 1024).toFixed(1)}KB</TableCell>
                        <TableCell>
                          {file.createdAt ? format(new Date(file.createdAt), 'dd/MM/yyyy') : 'N/A'}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end space-x-2">
                            <Button variant="outline" size="sm">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payments Tab */}
          <TabsContent value="payments" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Quản lý thanh toán</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Mã đơn</TableHead>
                      <TableHead>Khách hàng</TableHead>
                      <TableHead>Gói</TableHead>
                      <TableHead>Số tiền</TableHead>
                      <TableHead>Trạng thái</TableHead>
                      <TableHead>Ngày tạo</TableHead>
                      <TableHead className="text-right">Thao tác</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(payments as any[]).map((payment: any) => (
                      <TableRow key={payment.id}>
                        <TableCell className="font-medium">{payment.orderId}</TableCell>
                        <TableCell>{payment.customerName}</TableCell>
                        <TableCell>
                          <Badge variant="secondary">{payment.planType}</Badge>
                        </TableCell>
                        <TableCell>{payment.amount.toLocaleString('vi-VN')}đ</TableCell>
                        <TableCell>
                          <Badge variant={
                            payment.status === 'completed' ? 'default' :
                            payment.status === 'pending' ? 'secondary' : 'destructive'
                          }>
                            {payment.status === 'completed' ? 'Hoàn thành' :
                             payment.status === 'pending' ? 'Chờ xử lý' : 'Thất bại'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {payment.createdAt ? format(new Date(payment.createdAt), 'dd/MM/yyyy') : 'N/A'}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="outline" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Support Tab - New */}
          <TabsContent value="support" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  Ticket hỗ trợ khách hàng
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                  <Card>
                    <CardContent className="pt-4">
                      <div className="text-center">
                        <p className="text-2xl font-bold text-red-600">12</p>
                        <p className="text-sm text-gray-600">Mở</p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-4">
                      <div className="text-center">
                        <p className="text-2xl font-bold text-yellow-600">8</p>
                        <p className="text-sm text-gray-600">Đang xử lý</p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-4">
                      <div className="text-center">
                        <p className="text-2xl font-bold text-green-600">45</p>
                        <p className="text-sm text-gray-600">Đã giải quyết</p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-4">
                      <div className="text-center">
                        <p className="text-2xl font-bold text-blue-600">2.4h</p>
                        <p className="text-sm text-gray-600">Thời gian phản hồi TB</p>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Ticket</TableHead>
                      <TableHead>Khách hàng</TableHead>
                      <TableHead>Loại</TableHead>
                      <TableHead>Ưu tiên</TableHead>
                      <TableHead>Trạng thái</TableHead>
                      <TableHead>Ngày tạo</TableHead>
                      <TableHead className="text-right">Thao tác</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell>
                        <div>
                          <p className="font-medium">#001 Lỗi tạo audio</p>
                          <p className="text-sm text-gray-500">Không thể tạo file audio với giọng Nam Minh</p>
                        </div>
                      </TableCell>
                      <TableCell>user@example.com</TableCell>
                      <TableCell><Badge variant="destructive">Bug</Badge></TableCell>
                      <TableCell><Badge variant="default">Cao</Badge></TableCell>
                      <TableCell><Badge variant="secondary">Mở</Badge></TableCell>
                      <TableCell>{format(new Date(), 'dd/MM/yyyy HH:mm')}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="outline" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* System Tab - New */}
          <TabsContent value="system" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Cài đặt API
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">OpenAI API</p>
                      <p className="text-sm text-gray-500">Trạng thái kết nối</p>
                    </div>
                    <Badge variant="default">Hoạt động</Badge>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Rate Limiting</p>
                      <p className="text-sm text-gray-500">1000 requests/hour</p>
                    </div>
                    <Switch checked />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Cache System</p>
                      <p className="text-sm text-gray-500">Redis cache</p>
                    </div>
                    <Badge variant="default">Hoạt động</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    Bảo mật hệ thống
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">SSL Certificate</p>
                      <p className="text-sm text-gray-500">Hết hạn: 15/06/2025</p>
                    </div>
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Backup tự động</p>
                      <p className="text-sm text-gray-500">Mỗi 6 giờ</p>
                    </div>
                    <Switch checked />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Monitoring</p>
                      <p className="text-sm text-gray-500">Uptime: 99.9%</p>
                    </div>
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Payment Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="h-5 w-5" />
                  Cài đặt thanh toán
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg">Thông tin ngân hàng</h3>
                    
                    <div className="space-y-2">
                      <Label htmlFor="bank-name">Tên ngân hàng</Label>
                      <Input
                        id="bank-name"
                        placeholder="VD: Vietcombank"
                        defaultValue="Vietcombank"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="account-number">Số tài khoản</Label>
                      <Input
                        id="account-number"
                        placeholder="VD: 1234567890"
                        defaultValue="1234567890"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="account-name">Tên chủ tài khoản</Label>
                      <Input
                        id="account-name"
                        placeholder="VD: CONG TY VOICETEXT PRO"
                        defaultValue="CONG TY VOICETEXT PRO"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="support-email">Email hỗ trợ</Label>
                      <Input
                        id="support-email"
                        type="email"
                        placeholder="support@voicetextpro.com"
                        defaultValue="support@voicetextpro.com"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="support-phone">Số điện thoại hỗ trợ</Label>
                      <Input
                        id="support-phone"
                        placeholder="0123456789"
                        defaultValue="0123456789"
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg">Bảng giá</h3>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="pro-monthly">Pro - Tháng</Label>
                        <Input
                          id="pro-monthly"
                          type="number"
                          defaultValue="99000"
                          placeholder="99000"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="pro-yearly">Pro - Năm</Label>
                        <Input
                          id="pro-yearly"
                          type="number"
                          defaultValue="990000"
                          placeholder="990000"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="premium-monthly">Premium - Tháng</Label>
                        <Input
                          id="premium-monthly"
                          type="number"
                          defaultValue="199000"
                          placeholder="199000"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="premium-yearly">Premium - Năm</Label>
                        <Input
                          id="premium-yearly"
                          type="number"
                          defaultValue="1990000"
                          placeholder="1990000"
                        />
                      </div>
                    </div>

                    <div className="pt-4">
                      <Button className="w-full">
                        <Settings className="h-4 w-4 mr-2" />
                        Cập nhật cài đặt thanh toán
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Storage Management */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Server className="h-5 w-5" />
                  Quản lý lưu trữ
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-4 border rounded">
                    <p className="text-2xl font-bold text-blue-600">2.4GB</p>
                    <p className="text-sm text-gray-600">Audio files</p>
                  </div>
                  <div className="text-center p-4 border rounded">
                    <p className="text-2xl font-bold text-green-600">1.2GB</p>
                    <p className="text-sm text-gray-600">Database</p>
                  </div>
                  <div className="text-center p-4 border rounded">
                    <p className="text-2xl font-bold text-orange-600">0.8GB</p>
                    <p className="text-sm text-gray-600">Logs</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* App Settings Tab - New */}
          <TabsContent value="app-settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5" />
                  Cài đặt ứng dụng
                </CardTitle>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Quản lý các thiết lập chính của hệ thống
                </p>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleUpdateAppSettings}>
                  <Accordion type="multiple" defaultValue={["text-settings", "audio-settings"]} className="space-y-2">
                    
                    {/* Text Processing Settings */}
                    <AccordionItem value="text-settings">
                      <AccordionTrigger className="flex items-center gap-2">
                        <FileText className="h-4 w-4" />
                        Cài đặt xử lý văn bản
                      </AccordionTrigger>
                      <AccordionContent className="space-y-4 pt-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="maxCharacters">Giới hạn ký tự tối đa</Label>
                            <Input
                              id="maxCharacters"
                              name="maxCharacters"
                              type="number"
                              defaultValue={appSettings.maxCharacters || 500}
                              min="100"
                              max="5000"
                              className="w-full"
                            />
                            <p className="text-xs text-gray-500">
                              Số ký tự tối đa cho mỗi lần chuyển đổi văn bản
                            </p>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="maxFilesPerUser">Giới hạn file audio/user</Label>
                            <Input
                              id="maxFilesPerUser"
                              name="maxFilesPerUser"
                              type="number"
                              defaultValue={appSettings.maxFilesPerUser || 100}
                              min="10"
                              max="1000"
                              className="w-full"
                            />
                            <p className="text-xs text-gray-500">
                              Số file audio tối đa mỗi người dùng có thể lưu trữ
                            </p>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="maxFileSize">Kích thước file tối đa (MB)</Label>
                            <Input
                              id="maxFileSize"
                              name="maxFileSize"
                              type="number"
                              defaultValue={appSettings.maxFileSize || 10}
                              min="1"
                              max="100"
                              className="w-full"
                            />
                            <p className="text-xs text-gray-500">
                              Kích thước tối đa cho file upload
                            </p>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">Kiểm tra chính tả</p>
                              <p className="text-sm text-gray-500">Tự động sửa lỗi chính tả phổ biến</p>
                            </div>
                            <Switch 
                              name="spellCheckEnabled"
                              defaultChecked={appSettings.spellCheckEnabled !== false} 
                            />
                          </div>

                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">Voice preview</p>
                              <p className="text-sm text-gray-500">Cho phép nghe thử giọng nói</p>
                            </div>
                            <Switch 
                              name="voicePreviewEnabled"
                              defaultChecked={appSettings.voicePreviewEnabled !== false} 
                            />
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    {/* Audio Processing Settings */}
                    <AccordionItem value="audio-settings">
                      <AccordionTrigger className="flex items-center gap-2">
                        <Volume2 className="h-4 w-4" />
                        Cài đặt xử lý âm thanh
                      </AccordionTrigger>
                      <AccordionContent className="space-y-4 pt-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="defaultFormat">Định dạng audio mặc định</Label>
                            <Select name="defaultFormat" defaultValue={appSettings.defaultFormat || "mp3"}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="mp3">MP3</SelectItem>
                                <SelectItem value="wav">WAV</SelectItem>
                                <SelectItem value="ogg">OGG</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="defaultVoice">Giọng nói mặc định</Label>
                            <Select name="defaultVoice" defaultValue={appSettings.defaultVoice || "vi-VN-HoaiMy"}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="vi-VN-HoaiMy">Hoài My - Giọng nữ miền Bắc</SelectItem>
                                <SelectItem value="vi-VN-NamMinh">Nam Minh - Giọng nam miền Bắc</SelectItem>
                                <SelectItem value="vi-VN-ThuHa">Thu Hà - Giọng nữ miền Trung</SelectItem>
                                <SelectItem value="vi-VN-QuangAnh">Quang Anh - Giọng nam miền Nam</SelectItem>
                                <SelectItem value="vi-VN-HongLan">Hồng Lan - Giọng nữ miền Nam</SelectItem>
                                <SelectItem value="vi-VN-TuanVu">Tuấn Vũ - Giọng nam trầm ấm</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="audioQuality">Chất lượng âm thanh</Label>
                            <Select name="audioQuality" defaultValue={appSettings.audioQuality || "high"}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="low">Thấp (16kHz)</SelectItem>
                                <SelectItem value="medium">Trung bình (22kHz)</SelectItem>
                                <SelectItem value="high">Cao (44kHz)</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="cacheDuration">Thời gian lưu cache (giờ)</Label>
                            <Input
                              id="cacheDuration"
                              name="cacheDuration"
                              type="number"
                              defaultValue={appSettings.cacheDuration || 24}
                              min="1"
                              max="168"
                              className="w-full"
                            />
                            <p className="text-xs text-gray-500">
                              Thời gian lưu trữ file audio tạm thời
                            </p>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    {/* System Maintenance Settings */}
                    <AccordionItem value="system-settings">
                      <AccordionTrigger className="flex items-center gap-2">
                        <Settings className="h-4 w-4" />
                        Bảo trì hệ thống
                      </AccordionTrigger>
                      <AccordionContent className="space-y-4 pt-4">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">Chế độ bảo trì</p>
                              <p className="text-sm text-gray-500">Tạm ngưng dịch vụ cho user</p>
                            </div>
                            <Switch 
                              name="maintenanceMode"
                              defaultChecked={appSettings.maintenanceMode === true}
                            />
                          </div>

                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">Đăng ký mới</p>
                              <p className="text-sm text-gray-500">Cho phép tạo tài khoản mới</p>
                            </div>
                            <Switch 
                              name="registrationEnabled"
                              defaultChecked={appSettings.registrationEnabled !== false}
                            />
                          </div>

                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">API Rate Limiting</p>
                              <p className="text-sm text-gray-500">Giới hạn số request/phút</p>
                            </div>
                            <Switch 
                              name="rateLimitingEnabled"
                              defaultChecked={appSettings.rateLimitingEnabled !== false}
                            />
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                  </Accordion>

                  <div className="mt-6 pt-6 border-t">
                    <Button type="submit" disabled={updateAppSettings.isPending} className="w-full md:w-auto">
                      <Settings className="h-4 w-4 mr-2" />
                      {updateAppSettings.isPending ? "Đang cập nhật..." : "Cập nhật cài đặt ứng dụng"}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Voice Samples Tab */}
          <TabsContent value="voice-samples" className="space-y-6">
            <Card>
              <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Volume2 className="h-5 w-5" />
                    Cài đặt xử lý âm thanh
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="default-format">Định dạng audio mặc định</Label>
                    <Select defaultValue="mp3">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mp3">MP3</SelectItem>
                        <SelectItem value="wav">WAV</SelectItem>
                        <SelectItem value="ogg">OGG</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="default-voice">Giọng nói mặc định</Label>
                    <Select defaultValue="vi-VN-HoaiMy">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="vi-VN-HoaiMy">Hoài My - Giọng nữ miền Bắc</SelectItem>
                        <SelectItem value="vi-VN-NamMinh">Nam Minh - Giọng nam miền Bắc</SelectItem>
                        <SelectItem value="vi-VN-ThuHa">Thu Hà - Giọng nữ miền Trung</SelectItem>
                        <SelectItem value="vi-VN-QuangAnh">Quang Anh - Giọng nam miền Nam</SelectItem>
                        <SelectItem value="vi-VN-HongLan">Hồng Lan - Giọng nữ miền Nam</SelectItem>
                        <SelectItem value="vi-VN-TuanVu">Tuấn Vũ - Giọng nam trầm ấm</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="audio-quality">Chất lượng âm thanh</Label>
                    <Select defaultValue="high">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Thấp (16kHz)</SelectItem>
                        <SelectItem value="medium">Trung bình (22kHz)</SelectItem>
                        <SelectItem value="high">Cao (44kHz)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="cache-duration">Thời gian lưu cache (giờ)</Label>
                    <Input
                      id="cache-duration"
                      type="number"
                      defaultValue="24"
                      min="1"
                      max="168"
                      className="w-full"
                    />
                    <p className="text-xs text-gray-500">
                      Thời gian lưu trữ file audio tạm thời
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* System Maintenance */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5" />
                  Bảo trì hệ thống
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Chế độ bảo trì</p>
                      <p className="text-sm text-gray-500">Tạm ngưng dịch vụ cho user</p>
                    </div>
                    <Switch />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Đăng ký mới</p>
                      <p className="text-sm text-gray-500">Cho phép tạo tài khoản mới</p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">API Rate Limiting</p>
                      <p className="text-sm text-gray-500">Giới hạn số request/phút</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>

                <div className="mt-6 pt-6 border-t">
                  <Button type="submit" disabled={updateAppSettings.isPending} className="w-full md:w-auto">
                    <Settings className="h-4 w-4 mr-2" />
                    {updateAppSettings.isPending ? "Đang cập nhật..." : "Cập nhật cài đặt ứng dụng"}
                  </Button>
                </div>
              </CardContent>
            </Card>
            </form>
          </TabsContent>

          {/* Voice Samples Tab */}
          <TabsContent value="voice-samples" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Tạo mẫu giọng nói</CardTitle>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Tạo các file mẫu giọng nói để người dùng nghe thử trước khi sử dụng
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="voice-select">Chọn giọng</Label>
                    <Select value={selectedVoice} onValueChange={setSelectedVoice}>
                      <SelectTrigger>
                        <SelectValue placeholder="Chọn giọng nói" />
                      </SelectTrigger>
                      <SelectContent>
                        {voices.map((voice) => (
                          <SelectItem key={voice.id} value={voice.id}>
                            {voice.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="sample-text">Văn bản mẫu</Label>
                    <Textarea
                      id="sample-text"
                      value={sampleText}
                      onChange={(e) => setSampleText(e.target.value)}
                      placeholder="Nhập văn bản để tạo mẫu giọng..."
                      className="min-h-[80px]"
                    />
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button
                    onClick={handleGenerateVoiceSample}
                    disabled={isGeneratingSample || !selectedVoice || !sampleText.trim()}
                    className="flex items-center gap-2"
                  >
                    {isGeneratingSample ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        Đang tạo...
                      </>
                    ) : (
                      <>
                        <Volume2 className="h-4 w-4" />
                        Tạo mẫu giọng
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}