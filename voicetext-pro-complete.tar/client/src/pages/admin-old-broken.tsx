import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import Breadcrumb from "@/components/breadcrumb";
import type { User, AudioFile, ActivityLog, SystemMetric, SupportTicket } from "@shared/schema";
import { 
  Users, 
  Files, 
  Settings, 
  Activity, 
  BarChart3, 
  MessageSquare, 
  Zap, 
  Shield, 
  Volume2, 
  FileText, 
  AlertTriangle,
  Eye,
  Edit,
  Trash2,
  Download,
  CheckCircle,
  XCircle,
  Loader2,
  Search,
  Filter,
  MoreHorizontal,
  TrendingUp,
  TrendingDown,
  Calendar,
  Clock,
  CreditCard,
  Mic,
  Play
} from "lucide-react";

export default function AdminDashboard() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // States for various functionalities
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [selectedFile, setSelectedFile] = useState<AudioFile | null>(null);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [isUserDialogOpen, setIsUserDialogOpen] = useState(false);
  const [isFileDialogOpen, setIsFileDialogOpen] = useState(false);
  const [isTicketDialogOpen, setIsTicketDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterRole, setFilterRole] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [selectedVoice, setSelectedVoice] = useState("vi-VN-HoaiMy");
  const [sampleText, setSampleText] = useState("Xin chào, đây là mẫu giọng nói của VoiceText Pro.");
  const [isGeneratingSample, setIsGeneratingSample] = useState(false);
  const [generatedAudio, setGeneratedAudio] = useState<string | null>(null);

  // Fetch data
  const { data: users = [], isLoading: usersLoading } = useQuery({
    queryKey: ["/api/admin/users"],
  });

  const { data: audioFiles = [], isLoading: filesLoading } = useQuery({
    queryKey: ["/api/admin/audio-files"],
  });

  const { data: activityLogs = [], isLoading: logsLoading } = useQuery({
    queryKey: ["/api/admin/activity-logs"],
  });

  const { data: systemMetrics = [], isLoading: metricsLoading } = useQuery({
    queryKey: ["/api/admin/system-metrics"],
  });

  const { data: supportTickets = [], isLoading: ticketsLoading } = useQuery({
    queryKey: ["/api/admin/support-tickets"],
  });

  const { data: appSettings = {} } = useQuery({
    queryKey: ["/api/app-settings"],
  });

  const { data: paymentSettings = {} } = useQuery({
    queryKey: ["/api/payment-settings"],
  });

  // Generate voice sample mutation
  const generateVoiceSample = useMutation({
    mutationFn: async ({ text, voice }: { text: string; voice: string }) => {
      return apiRequest("POST", "/api/generate-voice-sample", { text, voice });
    },
    onSuccess: (data: any) => {
      setGeneratedAudio(data.audioData);
      toast({
        title: "Thành công",
        description: "Đã tạo mẫu giọng nói thành công",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Lỗi",
        description: error.message || "Không thể tạo mẫu giọng nói",
        variant: "destructive",
      });
    },
  });

  // Generate voice sample handler
  const handleGenerateVoiceSample = () => {
    if (!sampleText.trim()) {
      toast({
        title: "Lỗi",
        description: "Vui lòng nhập văn bản mẫu",
        variant: "destructive",
      });
      return;
    }
    generateVoiceSample.mutate({ text: sampleText, voice: selectedVoice });
  };

  // Mutations
  const updateUserRole = useMutation({
    mutationFn: async ({ userId, role }: { userId: number; role: string }) => {
      return apiRequest("PUT", `/api/admin/users/${userId}/role`, { role });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "Cập nhật thành công",
        description: "Vai trò người dùng đã được cập nhật",
      });
    },
    onError: () => {
      toast({
        title: "Lỗi",
        description: "Không thể cập nhật vai trò người dùng",
        variant: "destructive",
      });
    },
  });

  const updateUserSubscription = useMutation({
    mutationFn: async ({ userId, subscriptionType, expiryDate }: { userId: number; subscriptionType: string; expiryDate?: string }) => {
      return apiRequest("PUT", `/api/admin/users/${userId}/subscription`, { subscriptionType, expiryDate });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "Cập nhật thành công",
        description: "Gói dịch vụ đã được cập nhật",
      });
    },
    onError: () => {
      toast({
        title: "Lỗi",
        description: "Không thể cập nhật gói dịch vụ",
        variant: "destructive",
      });
    },
  });

  const deleteUser = useMutation({
    mutationFn: async (userId: number) => {
      return apiRequest("DELETE", `/api/admin/users/${userId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "Đã xóa",
        description: "Người dùng đã được xóa khỏi hệ thống",
      });
      setIsUserDialogOpen(false);
    },
    onError: () => {
      toast({
        title: "Lỗi",
        description: "Không thể xóa người dùng",
        variant: "destructive",
      });
    },
  });

  const deleteAudioFile = useMutation({
    mutationFn: async (fileId: number) => {
      return apiRequest("DELETE", `/api/admin/audio-files/${fileId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/audio-files"] });
      toast({
        title: "Đã xóa",
        description: "File audio đã được xóa",
      });
      setIsFileDialogOpen(false);
    },
    onError: () => {
      toast({
        title: "Lỗi",
        description: "Không thể xóa file audio",
        variant: "destructive",
      });
    },
  });

  const updateAppSettings = useMutation({
    mutationFn: async (formData: FormData) => {
      const settings = Object.fromEntries(formData.entries());
      return apiRequest("PUT", "/api/app-settings", settings);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/app-settings"] });
      toast({
        title: "Cập nhật thành công",
        description: "Cài đặt ứng dụng đã được cập nhật",
      });
    },
    onError: () => {
      toast({
        title: "Lỗi",
        description: "Không thể cập nhật cài đặt",
        variant: "destructive",
      });
    },
  });

  const updatePaymentSettings = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("PATCH", "/api/admin/payment-settings", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/payment-settings"] });
      toast({
        title: "Cập nhật thành công",
        description: "Cài đặt thanh toán đã được cập nhật",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Lỗi",
        description: error.message || "Không thể cập nhật cài đặt thanh toán",
        variant: "destructive",
      });
    },
  });

  // Event handlers
  const handleUpdateAppSettings = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    updateAppSettings.mutate(formData);
  };

  const handleUpdatePaymentSettings = (formData: FormData) => {
    const settings = Object.fromEntries(formData.entries());
    updatePaymentSettings.mutate(settings);
  };

  // Calculate statistics
  const totalUsers = (users as any[]).length;
  const activeUsers = (users as any[]).filter((user: User) => user.isActive).length;
  const proUsers = (users as any[]).filter((user: User) => user.subscriptionType === "pro").length;
  const premiumUsers = (users as any[]).filter((user: User) => user.subscriptionType === "premium").length;
  const totalAudioFiles = (audioFiles as any[]).length;
  const totalStorageUsed = (audioFiles as any[]).reduce((acc: number, file: AudioFile) => acc + file.fileSize, 0);

  // Filter users
  const filteredUsers = (users as any[]).filter((user: User) => {
    const matchesSearch = user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.fullName?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = filterRole === "all" || user.role === filterRole;
    const matchesStatus = filterStatus === "all" || 
                         (filterStatus === "active" && user.isActive) ||
                         (filterStatus === "inactive" && !user.isActive);
    
    return matchesSearch && matchesRole && matchesStatus;
  });

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Breadcrumb 
        title="Quản trị hệ thống" 
        showBackButton={true}
        backUrl="/"
        showHomeButton={true}
      />
      
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <p className="text-gray-600 dark:text-gray-300 mt-2">
            Quản lý người dùng, file audio và cài đặt hệ thống
          </p>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-7">
            <TabsTrigger value="overview">Tổng quan</TabsTrigger>
            <TabsTrigger value="users">Người dùng</TabsTrigger>
            <TabsTrigger value="files">File audio</TabsTrigger>
            <TabsTrigger value="activity">Hoạt động</TabsTrigger>
            <TabsTrigger value="metrics">Thống kê</TabsTrigger>
            <TabsTrigger value="support">Hỗ trợ</TabsTrigger>
            <TabsTrigger value="app-settings">Cài đặt app</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Tổng người dùng</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{totalUsers}</div>
                  <p className="text-xs text-muted-foreground">
                    {activeUsers} đang hoạt động
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">File audio</CardTitle>
                  <Files className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{totalAudioFiles}</div>
                  <p className="text-xs text-muted-foreground">
                    {(totalStorageUsed / (1024 * 1024)).toFixed(1)} MB lưu trữ
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Pro Users</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{proUsers}</div>
                  <p className="text-xs text-muted-foreground">
                    Gói Pro đang sử dụng
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Premium Users</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{premiumUsers}</div>
                  <p className="text-xs text-muted-foreground">
                    Gói Premium đang sử dụng
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Thao tác nhanh</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Button className="w-full" variant="outline">
                    <Users className="mr-2 h-4 w-4" />
                    Tạo tài khoản admin
                  </Button>
                  <Button className="w-full" variant="outline">
                    <Files className="mr-2 h-4 w-4" />
                    Dọn dẹp file tạm
                  </Button>
                  <Button className="w-full" variant="outline">
                    <BarChart3 className="mr-2 h-4 w-4" />
                    Xuất báo cáo
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-6">
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Tìm kiếm người dùng..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={filterRole} onValueChange={setFilterRole}>
                <SelectTrigger className="w-full sm:w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả vai trò</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="user">User</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full sm:w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả trạng thái</SelectItem>
                  <SelectItem value="active">Đang hoạt động</SelectItem>
                  <SelectItem value="inactive">Không hoạt động</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Danh sách người dùng</CardTitle>
              </CardHeader>
              <CardContent>
                {usersLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin" />
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Người dùng</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Vai trò</TableHead>
                        <TableHead>Gói dịch vụ</TableHead>
                        <TableHead>Trạng thái</TableHead>
                        <TableHead>Thao tác</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredUsers.slice(0, 10).map((user: User) => (
                        <TableRow key={user.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium">{user.fullName || user.username}</div>
                              <div className="text-sm text-gray-500">@{user.username}</div>
                            </div>
                          </TableCell>
                          <TableCell>{user.email}</TableCell>
                          <TableCell>
                            <Badge variant={user.role === "admin" ? "default" : "secondary"}>
                              {user.role === "admin" ? "Admin" : "User"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant={
                              user.subscriptionType === "premium" ? "default" :
                              user.subscriptionType === "pro" ? "secondary" : "outline"
                            }>
                              {user.subscriptionType}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant={user.isActive ? "default" : "secondary"}>
                              {user.isActive ? "Hoạt động" : "Tạm ngưng"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setSelectedUser(user);
                                setIsUserDialogOpen(true);
                              }}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Files Tab */}
          <TabsContent value="files" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Quản lý file audio</CardTitle>
              </CardHeader>
              <CardContent>
                {filesLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin" />
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Tiêu đề</TableHead>
                        <TableHead>Người tạo</TableHead>
                        <TableHead>Định dạng</TableHead>
                        <TableHead>Kích thước</TableHead>
                        <TableHead>Ngày tạo</TableHead>
                        <TableHead>Thao tác</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(audioFiles as any[]).slice(0, 10).map((file: AudioFile) => (
                        <TableRow key={file.id}>
                          <TableCell className="font-medium">{file.title}</TableCell>
                          <TableCell>
                            {(users as any[]).find((u: User) => u.id === file.userId)?.username || "Unknown"}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{file.format?.toUpperCase()}</Badge>
                          </TableCell>
                          <TableCell>{(file.fileSize / 1024).toFixed(1)} KB</TableCell>
                          <TableCell>{new Date(file.createdAt).toLocaleDateString('vi-VN')}</TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setSelectedFile(file);
                                setIsFileDialogOpen(true);
                              }}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Activity Tab */}
          <TabsContent value="activity" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Nhật ký hoạt động</CardTitle>
              </CardHeader>
              <CardContent>
                {logsLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin" />
                  </div>
                ) : (
                  <div className="space-y-4">
                    {(activityLogs as any[]).slice(0, 10).map((log: ActivityLog, index: number) => (
                      <div key={index} className="flex items-center space-x-4 p-4 border rounded-lg">
                        <Activity className="h-5 w-5 text-blue-500" />
                        <div className="flex-1">
                          <p className="text-sm font-medium">{log.action}</p>
                          <p className="text-xs text-gray-500">
                            {new Date(log.createdAt).toLocaleString('vi-VN')}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Metrics Tab */}
          <TabsContent value="metrics" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Thống kê hệ thống</CardTitle>
              </CardHeader>
              <CardContent>
                {metricsLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin" />
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">CPU Usage</span>
                          <TrendingUp className="h-4 w-4 text-green-500" />
                        </div>
                        <div className="text-2xl font-bold mt-2">45%</div>
                      </div>
                      <div className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">Memory Usage</span>
                          <TrendingUp className="h-4 w-4 text-yellow-500" />
                        </div>
                        <div className="text-2xl font-bold mt-2">68%</div>
                      </div>
                      <div className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">Storage Usage</span>
                          <TrendingDown className="h-4 w-4 text-red-500" />
                        </div>
                        <div className="text-2xl font-bold mt-2">23%</div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Support Tab */}
          <TabsContent value="support" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Hỗ trợ khách hàng</CardTitle>
              </CardHeader>
              <CardContent>
                {ticketsLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin" />
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Tiêu đề</TableHead>
                        <TableHead>Khách hàng</TableHead>
                        <TableHead>Mức độ</TableHead>
                        <TableHead>Trạng thái</TableHead>
                        <TableHead>Ngày tạo</TableHead>
                        <TableHead>Thao tác</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(supportTickets as any[]).slice(0, 10).map((ticket: SupportTicket) => (
                        <TableRow key={ticket.id}>
                          <TableCell className="font-medium">{ticket.subject}</TableCell>
                          <TableCell>{ticket.customerName}</TableCell>
                          <TableCell>
                            <Badge variant={
                              ticket.priority === "high" ? "destructive" :
                              ticket.priority === "medium" ? "default" : "secondary"
                            }>
                              {ticket.priority}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant={ticket.status === "open" ? "default" : "secondary"}>
                              {ticket.status}
                            </Badge>
                          </TableCell>
                          <TableCell>{new Date(ticket.createdAt).toLocaleDateString('vi-VN')}</TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setSelectedTicket(ticket);
                                setIsTicketDialogOpen(true);
                              }}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* System Settings Tab */}
          <TabsContent value="app-settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Cài đặt hệ thống
                </CardTitle>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Quản lý các thiết lập chính của hệ thống
                </p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  
                  {/* 1. Text Processing Settings */}
                  <div className="border rounded-lg p-6 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="p-2 bg-blue-600 text-white rounded-lg">
                        <FileText className="h-6 w-6" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg">Cài đặt xử lý văn bản</h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Quản lý giới hạn và kiểm tra văn bản</p>
                      </div>
                    </div>
                    <form onSubmit={handleUpdateAppSettings}>
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="maxCharacters">Giới hạn ký tự tối đa</Label>
                            <Input
                              id="maxCharacters"
                              name="maxCharacters"
                              type="number"
                              defaultValue={(appSettings as any)?.maxCharacters || 500}
                              min="100"
                              max="5000"
                              className="w-full"
                            />
                            <p className="text-xs text-gray-500">
                              Số ký tự tối đa cho mỗi lần chuyển đổi văn bản
                            </p>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="maxFilesPerUser">Giới hạn file audio/user</Label>
                            <Input
                              id="maxFilesPerUser"
                              name="maxFilesPerUser"
                              type="number"
                              defaultValue={(appSettings as any)?.maxFilesPerUser || 100}
                              min="10"
                              max="1000"
                              className="w-full"
                            />
                            <p className="text-xs text-gray-500">
                              Số file audio tối đa mỗi người dùng có thể tạo
                            </p>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="maxFileSize">Kích thước file tối đa (MB)</Label>
                            <Input
                              id="maxFileSize"
                              name="maxFileSize"
                              type="number"
                              defaultValue={(appSettings as any)?.maxFileSize || 10}
                              min="1"
                              max="100"
                              className="w-full"
                            />
                            <p className="text-xs text-gray-500">
                              Kích thước tối đa cho file upload
                            </p>
                          </div>

                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="font-medium">Kiểm tra chính tả</p>
                                <p className="text-sm text-gray-500">Tự động sửa lỗi chính tả phổ biến</p>
                              </div>
                              <Switch 
                                name="spellCheckEnabled"
                                defaultChecked={(appSettings as any)?.spellCheckEnabled !== false} 
                              />
                            </div>
                          </div>
                        </div>
                        <Button type="submit" disabled={updateAppSettings.isPending} className="w-full">
                          <FileText className="h-4 w-4 mr-2" />
                          {updateAppSettings.isPending ? "Đang lưu..." : "Lưu cài đặt văn bản"}
                        </Button>
                      </div>
                    </form>
                  </div>

                  {/* 2. Audio Processing Settings */}
                  <div className="border rounded-lg p-6 bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950 dark:to-purple-900">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="p-2 bg-purple-600 text-white rounded-lg">
                        <Volume2 className="h-6 w-6" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg">Cài đặt xử lý âm thanh</h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Cấu hình chất lượng và định dạng âm thanh</p>
                      </div>
                    </div>
                    <form onSubmit={handleUpdateAppSettings}>
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="defaultFormat">Định dạng audio mặc định</Label>
                            <Select name="defaultFormat" defaultValue={(appSettings as any)?.defaultFormat || "mp3"}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="mp3">MP3 (Nén tốt)</SelectItem>
                                <SelectItem value="wav">WAV (Chất lượng cao)</SelectItem>
                                <SelectItem value="ogg">OGG (Mã nguồn mở)</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="defaultVoice">Giọng nói mặc định</Label>
                            <Select name="defaultVoice" defaultValue={(appSettings as any)?.defaultVoice || "vi-VN-HoaiMy"}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="vi-VN-HoaiMy">Hoài My - Giọng nữ miền Bắc</SelectItem>
                                <SelectItem value="vi-VN-NamMinh">Nam Minh - Giọng nam miền Bắc</SelectItem>
                                <SelectItem value="vi-VN-ThuHa">Thu Hà - Giọng nữ miền Trung</SelectItem>
                                <SelectItem value="vi-VN-QuangAnh">Quang Anh - Giọng nam miền Nam</SelectItem>
                                <SelectItem value="vi-VN-HongLan">Hồng Lan - Giọng nữ miền Nam</SelectItem>
                                <SelectItem value="vi-VN-TuanVu">Tuấn Vũ - Giọng nam trầm ấm</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="audioQuality">Chất lượng âm thanh</Label>
                            <Select name="audioQuality" defaultValue={(appSettings as any)?.audioQuality || "high"}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="low">Thấp (16kHz)</SelectItem>
                                <SelectItem value="medium">Trung bình (22kHz)</SelectItem>
                                <SelectItem value="high">Cao (44kHz)</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="cacheDuration">Thời gian lưu cache (giờ)</Label>
                            <Input
                              id="cacheDuration"
                              name="cacheDuration"
                              type="number"
                              defaultValue={(appSettings as any)?.cacheDuration || 24}
                              min="1"
                              max="168"
                              className="w-full"
                            />
                            <p className="text-xs text-gray-500">
                              Thời gian lưu trữ file audio tạm thời
                            </p>
                          </div>

                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="font-medium">Voice preview</p>
                                <p className="text-sm text-gray-500">Cho phép nghe thử giọng nói</p>
                              </div>
                              <Switch 
                                name="voicePreviewEnabled"
                                defaultChecked={(appSettings as any)?.voicePreviewEnabled !== false} 
                              />
                            </div>
                          </div>
                        </div>
                        <Button type="submit" disabled={updateAppSettings.isPending} className="w-full">
                          <Volume2 className="h-4 w-4 mr-2" />
                          {updateAppSettings.isPending ? "Đang lưu..." : "Lưu cài đặt âm thanh"}
                        </Button>
                      </div>
                    </form>
                  </div>

                  {/* 3. Payment Settings */}
                  <div className="border rounded-lg p-6 bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950 dark:to-green-900">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="p-2 bg-green-600 text-white rounded-lg">
                        <CreditCard className="h-6 w-6" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg">Cài đặt thanh toán</h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Cấu hình thông tin ngân hàng và thanh toán</p>
                      </div>
                    </div>
                    <form onSubmit={(e) => {
                      e.preventDefault();
                      const formData = new FormData(e.currentTarget);
                      handleUpdatePaymentSettings(formData);
                    }}>
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label>Tên ngân hàng</Label>
                            <Input 
                              name="bankName"
                              defaultValue={(paymentSettings as any)?.bankName || ""}
                              placeholder="VD: Vietcombank"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Số tài khoản</Label>
                            <Input 
                              name="accountNumber"
                              defaultValue={(paymentSettings as any)?.accountNumber || ""}
                              placeholder="VD: 1234567890"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Tên chủ tài khoản</Label>
                            <Input 
                              name="accountName"
                              defaultValue={(paymentSettings as any)?.accountName || ""}
                              placeholder="VD: NGUYEN VAN A"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Email hỗ trợ</Label>
                            <Input 
                              name="supportEmail"
                              type="email"
                              defaultValue={(paymentSettings as any)?.supportEmail || ""}
                              placeholder="support@voicetext.vn"
                            />
                          </div>
                        </div>
                        <Button 
                          type="submit" 
                          disabled={updatePaymentSettings.isPending}
                          className="w-full"
                        >
                          <CreditCard className="h-4 w-4 mr-2" />
                          {updatePaymentSettings.isPending ? "Đang lưu..." : "Lưu cài đặt thanh toán"}
                        </Button>
                      </div>
                    </form>
                  </div>

                  {/* 4. Voice Sample Creation */}
                  <div className="border rounded-lg p-6 bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-950 dark:to-orange-900">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="p-2 bg-orange-600 text-white rounded-lg">
                        <Mic className="h-6 w-6" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg">Tạo mẫu giọng nói</h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Tạo mẫu âm thanh cho preview giọng nói</p>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="sampleText">Văn bản mẫu</Label>
                          <Textarea
                            id="sampleText"
                            value={sampleText}
                            onChange={(e) => setSampleText(e.target.value)}
                            placeholder="Nhập văn bản để tạo mẫu giọng nói..."
                            className="min-h-[100px]"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="sampleVoice">Chọn giọng nói</Label>
                          <Select value={selectedVoice} onValueChange={setSelectedVoice}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="vi-VN-HoaiMy">Hoài My - Giọng nữ miền Bắc</SelectItem>
                              <SelectItem value="vi-VN-NamMinh">Nam Minh - Giọng nam miền Bắc</SelectItem>
                              <SelectItem value="vi-VN-ThuHa">Thu Hà - Giọng nữ miền Trung</SelectItem>
                              <SelectItem value="vi-VN-QuangAnh">Quang Anh - Giọng nam miền Nam</SelectItem>
                              <SelectItem value="vi-VN-HongLan">Hồng Lan - Giọng nữ miền Nam</SelectItem>
                              <SelectItem value="vi-VN-TuanVu">Tuấn Vũ - Giọng nam trầm ấm</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <Button 
                          onClick={handleCreateVoiceSample}
                          disabled={createVoiceSample.isPending || !sampleText.trim()}
                          className="w-full"
                        >
                          <Mic className="h-4 w-4 mr-2" />
                          {createVoiceSample.isPending ? "Đang tạo..." : "Tạo mẫu giọng nói"}
                        </Button>

                        {generatedAudio && (
                          <div className="mt-4 p-3 bg-white dark:bg-gray-800 rounded border">
                            <p className="text-sm font-medium mb-2">Mẫu giọng đã tạo:</p>
                            <audio controls className="w-full">
                              <source src={generatedAudio} type="audio/mpeg" />
                              Trình duyệt không hỗ trợ audio.
                            </audio>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* 5. System Maintenance */}
                  <div className="border rounded-lg p-6 bg-gradient-to-br from-red-50 to-red-100 dark:from-red-950 dark:to-red-900">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="p-2 bg-red-600 text-white rounded-lg">
                        <Database className="h-6 w-6" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg">Bảo trì hệ thống</h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Dọn dẹp cache và bảo trì dữ liệu</p>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 gap-4">
                        <Button 
                          variant="outline" 
                          className="w-full justify-start"
                          onClick={() => {
                            if (confirm('Bạn có chắc muốn xóa tất cả file cache?')) {
                              // Implement cache cleanup
                              console.log('Cleaning cache...');
                            }
                          }}
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Dọn dẹp cache hệ thống
                        </Button>

                        <Button 
                          variant="outline" 
                          className="w-full justify-start"
                          onClick={() => {
                            if (confirm('Bạn có chắc muốn xóa các file tạm thời?')) {
                              // Implement temp files cleanup
                              console.log('Cleaning temp files...');
                            }
                          }}
                        >
                          <FileX className="h-4 w-4 mr-2" />
                          Xóa file tạm thời
                        </Button>

                        <Button 
                          variant="outline" 
                          className="w-full justify-start"
                          onClick={() => {
                            // Implement backup
                            console.log('Creating backup...');
                          }}
                        >
                          <Download className="h-4 w-4 mr-2" />
                          Sao lưu dữ liệu
                        </Button>

                        <div className="p-3 bg-white dark:bg-gray-800 rounded border">
                          <div className="flex items-center justify-between text-sm">
                            <span>Dung lượng đã sử dụng:</span>
                            <span className="font-medium">2.3 GB / 10 GB</span>
                          </div>
                          <div className="mt-2 w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-blue-600 h-2 rounded-full" 
                              style={{ width: '23%' }}
                            ></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>
              </CardContent>
            </Card>
          </TabsContent>
                      <AccordionContent className="space-y-4 pt-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="maxCharacters">Giới hạn ký tự tối đa</Label>
                            <Input
                              id="maxCharacters"
                              name="maxCharacters"
                              type="number"
                              defaultValue={(appSettings as any).maxCharacters || 500}
                              min="100"
                              max="5000"
                              className="w-full"
                            />
                            <p className="text-xs text-gray-500">
                              Số ký tự tối đa cho mỗi lần chuyển đổi văn bản
                            </p>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="maxFilesPerUser">Giới hạn file audio/user</Label>
                            <Input
                              id="maxFilesPerUser"
                              name="maxFilesPerUser"
                              type="number"
                              defaultValue={(appSettings as any).maxFilesPerUser || 100}
                              min="10"
                              max="1000"
                              className="w-full"
                            />
                            <p className="text-xs text-gray-500">
                              Số file audio tối đa mỗi người dùng có thể lưu trữ
                            </p>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="maxFileSize">Kích thước file tối đa (MB)</Label>
                            <Input
                              id="maxFileSize"
                              name="maxFileSize"
                              type="number"
                              defaultValue={(appSettings as any).maxFileSize || 10}
                              min="1"
                              max="100"
                              className="w-full"
                            />
                            <p className="text-xs text-gray-500">
                              Kích thước tối đa cho file upload
                            </p>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">Kiểm tra chính tả</p>
                              <p className="text-sm text-gray-500">Tự động sửa lỗi chính tả phổ biến</p>
                            </div>
                            <Switch 
                              name="spellCheckEnabled"
                              defaultChecked={(appSettings as any).spellCheckEnabled !== false} 
                            />
                          </div>

                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">Voice preview</p>
                              <p className="text-sm text-gray-500">Cho phép nghe thử giọng nói</p>
                            </div>
                            <Switch 
                              name="voicePreviewEnabled"
                              defaultChecked={(appSettings as any).voicePreviewEnabled !== false} 
                            />
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    {/* Audio Processing Settings */}
                    <AccordionItem value="audio-settings">
                      <AccordionTrigger className="flex items-center gap-2">
                        <Volume2 className="h-4 w-4" />
                        Cài đặt xử lý âm thanh
                      </AccordionTrigger>
                      <AccordionContent className="space-y-4 pt-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="defaultFormat">Định dạng audio mặc định</Label>
                            <Select name="defaultFormat" defaultValue={(appSettings as any).defaultFormat || "mp3"}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="mp3">MP3</SelectItem>
                                <SelectItem value="wav">WAV</SelectItem>
                                <SelectItem value="ogg">OGG</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="defaultVoice">Giọng nói mặc định</Label>
                            <Select name="defaultVoice" defaultValue={(appSettings as any).defaultVoice || "vi-VN-HoaiMy"}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="vi-VN-HoaiMy">Hoài My - Giọng nữ miền Bắc</SelectItem>
                                <SelectItem value="vi-VN-NamMinh">Nam Minh - Giọng nam miền Bắc</SelectItem>
                                <SelectItem value="vi-VN-ThuHa">Thu Hà - Giọng nữ miền Trung</SelectItem>
                                <SelectItem value="vi-VN-QuangAnh">Quang Anh - Giọng nam miền Nam</SelectItem>
                                <SelectItem value="vi-VN-HongLan">Hồng Lan - Giọng nữ miền Nam</SelectItem>
                                <SelectItem value="vi-VN-TuanVu">Tuấn Vũ - Giọng nam trầm ấm</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="audioQuality">Chất lượng âm thanh</Label>
                            <Select name="audioQuality" defaultValue={(appSettings as any).audioQuality || "high"}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="low">Thấp (16kHz)</SelectItem>
                                <SelectItem value="medium">Trung bình (22kHz)</SelectItem>
                                <SelectItem value="high">Cao (44kHz)</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="cacheDuration">Thời gian lưu cache (giờ)</Label>
                            <Input
                              id="cacheDuration"
                              name="cacheDuration"
                              type="number"
                              defaultValue={(appSettings as any).cacheDuration || 24}
                              min="1"
                              max="168"
                              className="w-full"
                            />
                            <p className="text-xs text-gray-500">
                              Thời gian lưu trữ file audio tạm thời
                            </p>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    {/* System Settings */}
                    <AccordionItem value="system-settings">
                      <AccordionTrigger className="flex items-center gap-2">
                        <Settings className="h-4 w-4" />
                        Cài đặt hệ thống
                      </AccordionTrigger>
                      <AccordionContent className="space-y-6 pt-4">
                        {/* Payment Settings */}
                        <form onSubmit={(e) => {
                          e.preventDefault();
                          const formData = new FormData(e.currentTarget);
                          handleUpdatePaymentSettings(formData);
                        }}>
                          <div className="border rounded-lg p-4 bg-blue-50 dark:bg-blue-950/20">
                            <h4 className="font-semibold mb-4 flex items-center gap-2">
                              <CreditCard className="h-4 w-4" />
                              Cài đặt thanh toán
                            </h4>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                              <div className="space-y-2">
                                <Label>Tên ngân hàng</Label>
                                <Input 
                                  name="bankName"
                                  defaultValue={(paymentSettings as any)?.bankName || ""}
                                  placeholder="VD: Vietcombank"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label>Số tài khoản</Label>
                                <Input 
                                  name="accountNumber"
                                  defaultValue={(paymentSettings as any)?.accountNumber || ""}
                                  placeholder="VD: 1234567890"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label>Tên chủ tài khoản</Label>
                                <Input 
                                  name="accountName"
                                  defaultValue={(paymentSettings as any)?.accountName || ""}
                                  placeholder="VD: NGUYEN VAN A"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label>Email hỗ trợ</Label>
                                <Input 
                                  name="supportEmail"
                                  type="email"
                                  defaultValue={(paymentSettings as any)?.supportEmail || ""}
                                  placeholder="support@voicetext.vn"
                                />
                              </div>
                            </div>
                            <Button 
                              type="submit" 
                              disabled={updatePaymentSettings.isPending}
                              size="sm"
                              className="w-full md:w-auto"
                            >
                              <CreditCard className="h-4 w-4 mr-2" />
                              {updatePaymentSettings.isPending ? "Đang lưu..." : "Lưu cài đặt thanh toán"}
                            </Button>
                          </div>
                        </form>

                        {/* Voice Sample Creation */}
                        <div className="border rounded-lg p-4 bg-green-50 dark:bg-green-950/20">
                          <h4 className="font-semibold mb-4 flex items-center gap-2">
                            <Mic className="h-4 w-4" />
                            Tạo mẫu giọng nói
                          </h4>
                          <div className="space-y-4">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <Label>Văn bản mẫu</Label>
                                <Textarea 
                                  name="sampleText"
                                  placeholder="Nhập văn bản để tạo mẫu giọng nói..."
                                  rows={3}
                                  defaultValue="Xin chào, đây là giọng nói mẫu của VoiceText Pro. Chúng tôi cung cấp dịch vụ chuyển văn bản thành giọng nói chất lượng cao."
                                />
                              </div>
                              <div className="space-y-2">
                                <Label>Giọng nói</Label>
                                <Select name="sampleVoice" defaultValue="vi-VN-HoaiMy">
                                  <SelectTrigger>
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="vi-VN-HoaiMy">Hoài My (Nữ)</SelectItem>
                                    <SelectItem value="vi-VN-NamMinh">Nam Minh (Nam)</SelectItem>
                                    <SelectItem value="vi-VN-ThanhAn">Thanh An (Nữ)</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>
                            <div className="space-y-3">
                              <Button 
                                type="button" 
                                variant="outline" 
                                className="w-full md:w-auto"
                                onClick={handleGenerateVoiceSample}
                                disabled={generateVoiceSample.isPending}
                              >
                                {generateVoiceSample.isPending ? (
                                  <>
                                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                    Đang tạo...
                                  </>
                                ) : (
                                  <>
                                    <Play className="h-4 w-4 mr-2" />
                                    Tạo mẫu giọng nói
                                  </>
                                )}
                              </Button>
                              {generatedAudio && (
                                <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                                  <p className="text-sm font-medium mb-2">Mẫu giọng nói đã tạo:</p>
                                  <audio controls className="w-full">
                                    <source src={generatedAudio} type="audio/mp3" />
                                    Trình duyệt không hỗ trợ audio.
                                  </audio>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">Chế độ bảo trì</p>
                              <p className="text-sm text-gray-500">Tạm ngưng dịch vụ cho user</p>
                            </div>
                            <Switch 
                              name="maintenanceMode"
                              defaultChecked={(appSettings as any).maintenanceMode === true}
                            />
                          </div>

                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">Đăng ký mới</p>
                              <p className="text-sm text-gray-500">Cho phép tạo tài khoản mới</p>
                            </div>
                            <Switch 
                              name="registrationEnabled"
                              defaultChecked={(appSettings as any).registrationEnabled !== false}
                            />
                          </div>

                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">API Rate Limiting</p>
                              <p className="text-sm text-gray-500">Giới hạn số request/phút</p>
                            </div>
                            <Switch 
                              name="rateLimitingEnabled"
                              defaultChecked={(appSettings as any).rateLimitingEnabled !== false}
                            />
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                  </Accordion>

                  <div className="mt-6 pt-6 border-t">
                    <Button type="submit" disabled={updateAppSettings.isPending} className="w-full md:w-auto">
                      <Settings className="h-4 w-4 mr-2" />
                      {updateAppSettings.isPending ? "Đang cập nhật..." : "Cập nhật cài đặt ứng dụng"}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

        </Tabs>
      </div>
    </div>
  );
}