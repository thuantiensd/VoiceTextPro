import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Bell, 
  Mic, 
  FileAudio, 
  Zap, 
  Shield, 
  Globe, 
  Sparkles, 
  ArrowRight,
  Check,
  Star,
  Users,
  BarChart3,
  MessageSquare,
  Download,
  Settings,
  Crown,
  Rocket,
  Gift
} from "lucide-react";
import { Link } from "wouter";
import { useAuth } from "@/hooks/useAuth";

export default function FeaturesPage() {
  const { user, isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState("new");

  const newFeatures = [
    {
      id: "auto-notifications",
      title: "Hệ thống thông báo tự động",
      description: "Nhận thông báo tức thì về thanh toán, nâng cấp gói, và các hoạt động quan trọng",
      icon: <Bell className="h-6 w-6" />,
      status: "Mới",
      color: "bg-green-500",
      features: [
        "Thông báo chào mừng khi đăng ký",
        "Thông báo thanh toán thành công",
        "Cảnh báo hết hạn gói",
        "Thông báo khi tạo file âm thanh",
        "Nhấn để chuyển đến trang liên quan"
      ]
    },
    {
      id: "advanced-tts",
      title: "TTS nâng cao với OpenAI",
      description: "Công nghệ Text-to-Speech tốt nhất với nhiều giọng đọc chất lượng cao",
      icon: <Mic className="h-6 w-6" />,
      status: "Nâng cấp",
      color: "bg-blue-500",
      features: [
        "11 giọng đọc OpenAI chất lượng cao",
        "Giọng đọc tiếng Việt từ FPT AI",
        "Điều chỉnh tốc độ, độ cao, âm lượng",
        "Xuất file MP3, WAV, OGG",
        "Xem trước trước khi tải về"
      ]
    },
    {
      id: "file-management",
      title: "Quản lý file thông minh",
      description: "Hệ thống quản lý file âm thanh toàn diện với tìm kiếm và chia sẻ",
      icon: <FileAudio className="h-6 w-6" />,
      status: "Cải tiến",
      color: "bg-purple-500",
      features: [
        "Lưu trữ file không giới hạn (gói Premium)",
        "Tìm kiếm file theo tên, nội dung",
        "Chia sẻ file với link công khai",
        "Xem lịch sử tạo file",
        "Tải xuống hàng loạt"
      ]
    }
  ];

  const comingSoonFeatures = [
    {
      id: "voice-cloning",
      title: "Sao chép giọng nói",
      description: "Tạo giọng đọc từ mẫu giọng của bạn",
      icon: <Users className="h-6 w-6" />,
      estimatedDate: "Q2 2025"
    },
    {
      id: "batch-processing",
      title: "Xử lý hàng loạt",
      description: "Tạo nhiều file âm thanh cùng lúc từ danh sách văn bản",
      icon: <Zap className="h-6 w-6" />,
      estimatedDate: "Q1 2025"
    },
    {
      id: "analytics",
      title: "Thống kê chi tiết",
      description: "Xem báo cáo sử dụng và thống kê chi tiết",
      icon: <BarChart3 className="h-6 w-6" />,
      estimatedDate: "Q2 2025"
    },
    {
      id: "api-access",
      title: "API tích hợp",
      description: "Tích hợp VoiceText Pro vào ứng dụng của bạn",
      icon: <Settings className="h-6 w-6" />,
      estimatedDate: "Q3 2025"
    }
  ];

  const planFeatures = {
    free: {
      name: "Miễn phí",
      price: "0₫",
      color: "border-gray-300",
      popular: false,
      features: [
        "500 ký tự/tháng",
        "5 file âm thanh",
        "2 giọng đọc cơ bản",
        "Định dạng MP3",
        "Hỗ trợ email"
      ]
    },
    pro: {
      name: "Pro",
      price: "99.000₫",
      color: "border-blue-500",
      popular: true,
      features: [
        "10.000 ký tự/tháng",
        "100 file âm thanh",
        "Tất cả giọng đọc",
        "Nhiều định dạng xuất",
        "Chia sẻ file công khai",
        "Hỗ trợ ưu tiên"
      ]
    },
    premium: {
      name: "Premium",
      price: "199.000₫",
      color: "border-yellow-500",
      popular: false,
      features: [
        "50.000 ký tự/tháng",
        "1.000 file âm thanh",
        "Tất cả tính năng Pro",
        "Sao chép giọng nói (sắp ra mắt)",
        "Xử lý hàng loạt (sắp ra mắt)",
        "API tích hợp (sắp ra mắt)",
        "Hỗ trợ 24/7"
      ]
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4 flex items-center justify-center gap-2">
            <Sparkles className="h-8 w-8 text-blue-500" />
            Tính năng VoiceText Pro
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
            Khám phá những tính năng mới nhất và sắp ra mắt của nền tảng TTS hàng đầu Việt Nam
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="new" className="flex items-center gap-2">
              <Rocket className="h-4 w-4" />
              Tính năng mới
            </TabsTrigger>
            <TabsTrigger value="coming" className="flex items-center gap-2">
              <Gift className="h-4 w-4" />
              Sắp ra mắt
            </TabsTrigger>
            <TabsTrigger value="plans" className="flex items-center gap-2">
              <Crown className="h-4 w-4" />
              Gói dịch vụ
            </TabsTrigger>
          </TabsList>

          <TabsContent value="new">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {newFeatures.map((feature) => (
                <Card key={feature.id} className="relative overflow-hidden hover:shadow-lg transition-shadow">
                  <div className={`absolute top-0 right-0 ${feature.color} text-white px-3 py-1 text-sm rounded-bl-lg`}>
                    {feature.status}
                  </div>
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className={`p-2 ${feature.color} text-white rounded-lg`}>
                        {feature.icon}
                      </div>
                      <div>
                        <CardTitle className="text-lg">{feature.title}</CardTitle>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 dark:text-gray-400 mb-4">
                      {feature.description}
                    </p>
                    <ul className="space-y-2">
                      {feature.features.map((item, index) => (
                        <li key={index} className="flex items-center gap-2 text-sm">
                          <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="coming">
            <div className="grid gap-6 md:grid-cols-2">
              {comingSoonFeatures.map((feature) => (
                <Card key={feature.id} className="relative overflow-hidden">
                  <div className="absolute top-0 right-0 bg-orange-500 text-white px-3 py-1 text-sm rounded-bl-lg">
                    {feature.estimatedDate}
                  </div>
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-gray-500 text-white rounded-lg">
                        {feature.icon}
                      </div>
                      <div>
                        <CardTitle className="text-lg">{feature.title}</CardTitle>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 dark:text-gray-400">
                      {feature.description}
                    </p>
                    <div className="mt-4 p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                      <p className="text-sm text-orange-700 dark:text-orange-300">
                        🚀 Dự kiến ra mắt: {feature.estimatedDate}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            <div className="mt-8 text-center">
              <Card className="inline-block p-6 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20">
                <div className="flex items-center gap-3 mb-4">
                  <MessageSquare className="h-6 w-6 text-blue-500" />
                  <h3 className="text-lg font-semibold">Góp ý tính năng</h3>
                </div>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  Bạn có ý tưởng cho tính năng mới? Hãy liên hệ với chúng tôi!
                </p>
                <Button variant="outline">
                  Gửi góp ý
                </Button>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="plans">
            <div className="grid gap-6 md:grid-cols-3">
              {Object.entries(planFeatures).map(([key, plan]) => (
                <Card key={key} className={`relative ${plan.color} border-2 ${plan.popular ? 'ring-2 ring-blue-500' : ''}`}>
                  {plan.popular && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-blue-500 text-white px-4 py-1">
                        <Star className="h-3 w-3 mr-1" />
                        Phổ biến nhất
                      </Badge>
                    </div>
                  )}
                  <CardHeader className="text-center">
                    <CardTitle className="text-2xl">{plan.name}</CardTitle>
                    <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">
                      {plan.price}
                      {key !== 'free' && <span className="text-sm text-gray-500">/tháng</span>}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3 mb-6">
                      {plan.features.map((feature, index) => (
                        <li key={index} className="flex items-center gap-2">
                          <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Link href="/membership">
                      <Button 
                        className={`w-full ${plan.popular ? 'bg-blue-500 hover:bg-blue-600' : ''}`}
                        variant={plan.popular ? 'default' : 'outline'}
                      >
                        {user?.subscriptionType === key ? 'Gói hiện tại' : 
                         key === 'free' ? 'Miễn phí' : 'Nâng cấp ngay'}
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Call to Action */}
        <div className="text-center mt-12">
          <Card className="inline-block p-8 bg-gradient-to-r from-blue-500 to-indigo-600 text-white">
            <h2 className="text-2xl font-bold mb-4">Sẵn sàng trải nghiệm?</h2>
            <p className="mb-6 text-blue-100">
              Bắt đầu tạo file âm thanh chất lượng cao ngay hôm nay
            </p>
            <div className="flex gap-4 justify-center">
              {!isAuthenticated ? (
                <>
                  <Link href="/register">
                    <Button variant="secondary" size="lg">
                      Đăng ký miễn phí
                    </Button>
                  </Link>
                  <Link href="/login">
                    <Button variant="outline" size="lg" className="text-white border-white hover:bg-white/10">
                      Đăng nhập
                    </Button>
                  </Link>
                </>
              ) : (
                <Link href="/dashboard">
                  <Button variant="secondary" size="lg">
                    Vào Dashboard
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                </Link>
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}