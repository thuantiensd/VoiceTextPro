import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { Check, Crown, Zap, Star, ArrowRight, ArrowLeft } from "lucide-react";
import Breadcrumb from "@/components/breadcrumb";

export default function PricingPage() {
  const { isAuthenticated, user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();

  // Khách vãng lai có thể xem pricing để biết các gói nâng cấp
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly");

  const plans = [
    {
      name: "Free",
      price: { monthly: 0, yearly: 0 },
      description: "Dành cho người dùng cá nhân",
      features: [
        "5 file audio mỗi tháng",
        "Giọng nói cơ bản",
        "File tự động xóa sau 24h",
        "Chất lượng standard",
        "Hỗ trợ qua email"
      ],
      limitations: [
        "Giới hạn 5 file/tháng",
        "Không lưu trữ vĩnh viễn",
        "Chỉ có 2 giọng nói"
      ],
      current: user?.subscriptionType === "free",
      popular: false,
      icon: Zap,
      color: "gray"
    },
    {
      name: "Pro",
      price: { monthly: 99000, yearly: 990000 },
      description: "Dành cho chuyên gia và doanh nghiệp nhỏ",
      features: [
        "100 file audio mỗi tháng", 
        "Tất cả giọng nói premium",
        "Lưu trữ vĩnh viễn",
        "Export đa định dạng (MP3, WAV, OGG)",
        "Chất lượng cao HD",
        "Hỗ trợ ưu tiên",
        "API access cơ bản"
      ],
      current: user?.subscriptionType === "pro",
      popular: true,
      icon: Crown,
      color: "blue"
    },
    {
      name: "Premium",
      price: { monthly: 199000, yearly: 1990000 },
      description: "Dành cho doanh nghiệp và người dùng chuyên nghiệp",
      features: [
        "Unlimited file audio",
        "Tất cả giọng nói + AI voices",
        "Lưu trữ không giới hạn",
        "Tất cả định dạng export",
        "Chất lượng studio",
        "Custom voice training",
        "API access đầy đủ",
        "Hỗ trợ 24/7",
        "White-label option"
      ],
      current: user?.subscriptionType === "premium",
      popular: false,
      icon: Star,
      color: "purple"
    }
  ];

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND"
    }).format(price);
  };

  const getYearlySavings = (monthly: number, yearly: number) => {
    const monthlyCost = monthly * 12;
    const savings = monthlyCost - yearly;
    const percentage = Math.round((savings / monthlyCost) * 100);
    return { savings, percentage };
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Breadcrumb 
        title="Bảng giá" 
        showBackButton={true}
        backUrl="/"
        showHomeButton={true}
      />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Chọn gói phù hợp với bạn
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 mb-8">
            Nâng cấp để trải nghiệm đầy đủ tính năng VoiceText Pro
          </p>
          
          {/* Billing Toggle */}
          <div className="flex items-center justify-center space-x-4 mb-8">
            <span className={`text-sm ${billingCycle === "monthly" ? "text-gray-900 dark:text-white font-medium" : "text-gray-500"}`}>
              Hàng tháng
            </span>
            <button
              onClick={() => setBillingCycle(billingCycle === "monthly" ? "yearly" : "monthly")}
              className="relative w-14 h-7 bg-gray-200 dark:bg-gray-700 rounded-full transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <div
                className={`absolute top-0.5 left-0.5 w-6 h-6 bg-white rounded-full shadow transition-transform duration-200 ${
                  billingCycle === "yearly" ? "translate-x-7" : ""
                }`}
              />
            </button>
            <span className={`text-sm ${billingCycle === "yearly" ? "text-gray-900 dark:text-white font-medium" : "text-gray-500"}`}>
              Hàng năm
            </span>
            {billingCycle === "yearly" && (
              <Badge className="bg-green-100 text-green-800 text-xs">
                Tiết kiệm 17%
              </Badge>
            )}
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {plans.map((plan) => {
            const Icon = plan.icon;
            const savings = billingCycle === "yearly" ? getYearlySavings(plan.price.monthly, plan.price.yearly) : null;
            
            return (
              <Card 
                key={plan.name}
                className={`relative overflow-hidden ${
                  plan.popular 
                    ? "ring-2 ring-blue-500 shadow-xl scale-105" 
                    : "shadow-lg hover:shadow-xl"
                } transition-all duration-200`}
              >
                {plan.popular && (
                  <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-blue-500 to-purple-600 text-white text-center py-2 text-sm font-medium">
                    Phổ biến nhất
                  </div>
                )}
                
                <CardHeader className={`text-center ${plan.popular ? "pt-12" : "pt-6"}`}>
                  <div className={`w-12 h-12 mx-auto mb-4 rounded-full bg-${plan.color}-100 dark:bg-${plan.color}-900 flex items-center justify-center`}>
                    <Icon className={`h-6 w-6 text-${plan.color}-600 dark:text-${plan.color}-400`} />
                  </div>
                  <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
                  <p className="text-gray-600 dark:text-gray-400 text-sm">
                    {plan.description}
                  </p>
                  
                  <div className="mt-4">
                    <div className="flex items-baseline justify-center">
                      <span className="text-4xl font-bold">
                        {formatPrice(plan.price[billingCycle])}
                      </span>
                      {plan.price[billingCycle] > 0 && (
                        <span className="text-gray-500 ml-1">
                          /{billingCycle === "monthly" ? "tháng" : "năm"}
                        </span>
                      )}
                    </div>
                    {savings && plan.price.yearly > 0 && (
                      <p className="text-sm text-green-600 mt-1">
                        Tiết kiệm {formatPrice(savings.savings)}/năm
                      </p>
                    )}
                  </div>
                </CardHeader>

                <CardContent className="pt-0">
                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <Check className="h-4 w-4 text-green-500 mt-0.5 mr-3 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  {plan.current ? (
                    <Button className="w-full" disabled>
                      Gói hiện tại
                    </Button>
                  ) : !isAuthenticated ? (
                    <Button className="w-full" asChild>
                      <Link href="/register">
                        Bắt đầu miễn phí
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  ) : plan.name === "Free" ? (
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => window.location.href = `/downgrade?plan=${plan.name.toLowerCase()}`}
                    >
                      Chuyển về Free
                    </Button>
                  ) : (
                    <Button 
                      className={`w-full ${
                        plan.popular 
                          ? "bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700" 
                          : ""
                      }`}
                      onClick={() => window.location.href = `/payment?plan=${plan.name.toLowerCase()}&billing=${billingCycle}`}
                    >
                      Nâng cấp lên {plan.name}
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* FAQ Section */}
        <div className="max-w-3xl mx-auto">
          <h2 className="text-2xl font-bold text-center mb-8">Câu hỏi thường gặp</h2>
          <div className="space-y-6">
            <div className="border-b border-gray-200 dark:border-gray-700 pb-6">
              <h3 className="font-medium mb-2">Tôi có thể hủy đăng ký bất cứ lúc nào không?</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Có, bạn có thể hủy đăng ký bất cứ lúc nào. Gói dịch vụ sẽ vẫn hoạt động đến hết chu kỳ thanh toán.
              </p>
            </div>
            <div className="border-b border-gray-200 dark:border-gray-700 pb-6">
              <h3 className="font-medium mb-2">Có được hoàn tiền không?</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Chúng tôi có chính sách hoàn tiền trong vòng 30 ngày đầu nếu bạn không hài lòng với dịch vụ.
              </p>
            </div>
            <div className="border-b border-gray-200 dark:border-gray-700 pb-6">
              <h3 className="font-medium mb-2">Tôi có thể thay đổi gói dịch vụ không?</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Có, bạn có thể nâng cấp hoặc hạ cấp gói dịch vụ bất cứ lúc nào. Phí sẽ được tính theo tỷ lệ.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}