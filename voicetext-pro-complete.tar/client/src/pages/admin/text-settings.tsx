import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAdminFormState } from "@/hooks/useAdminFormState";
import AdminConfirmDialog from "@/components/admin-confirm-dialog";
import { useAuth } from "@/hooks/useAuth";
import { useEffect } from "react";
import { FileText, Type, AlignLeft } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import Breadcrumb from "@/components/breadcrumb";
import type { UpdateAppSettings, AppSettings } from "@shared/schema";

export default function TextSettings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: appSettings, isLoading } = useQuery({
    queryKey: ["/api/app-settings"],
  });

  const updateSettings = useMutation({
    mutationFn: async (data: UpdateAppSettings) => {
      return await apiRequest("PUT", "/api/admin/app-settings", data);
    },
    onSuccess: () => {
      toast({
        title: "Thành công",
        description: "Cài đặt văn bản đã được cập nhật",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/app-settings"] });
      formState.resetFormState();
    },
    onError: (error: Error) => {
      toast({
        title: "Lỗi",
        description: error.message,
        variant: "destructive",
      });
      formState.setIsSubmitting(false);
    },
  });

  const formState = useAdminFormState<UpdateAppSettings>({
    initialData: appSettings as AppSettings,
    onSave: (data) => updateSettings.mutate(data),
  });

  const handleFormSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data: UpdateAppSettings = {
      maxTextLength: Number(formData.get("maxTextLength")),
      allowedLanguages: (formData.get("allowedLanguages") as string)?.split(',').map(l => l.trim()).filter(Boolean),
      defaultLanguage: formData.get("defaultLanguage") as string,
    };
    formState.handleSubmit(data);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="max-w-4xl mx-auto">
        <Breadcrumb 
          title="Cài đặt văn bản" 
          showBackButton={true} 
          backUrl="/admin"
        />
        
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 mt-6">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <FileText className="h-6 w-6 text-blue-600" />
            Cài đặt văn bản
          </h2>
          
          <form onSubmit={handleFormSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  <Type className="h-5 w-5 text-green-600" />
                  Giới hạn văn bản
                </h3>
                
                <div>
                  <Label htmlFor="maxTextLength">Độ dài tối đa (ký tự)</Label>
                  <Input
                    id="maxTextLength"
                    name="maxTextLength"
                    type="number"
                    defaultValue={appSettings?.maxTextLength || 5000}
                    onChange={formState.handleInputChange}
                    placeholder="5000"
                  />
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  <AlignLeft className="h-5 w-5 text-purple-600" />
                  Ngôn ngữ hỗ trợ
                </h3>
                
                <div>
                  <Label htmlFor="defaultLanguage">Ngôn ngữ mặc định</Label>
                  <Input
                    id="defaultLanguage"
                    name="defaultLanguage"
                    type="text"
                    defaultValue={appSettings?.defaultLanguage || "vi"}
                    onChange={formState.handleInputChange}
                    placeholder="vi"
                  />
                </div>

                <div>
                  <Label htmlFor="allowedLanguages">Ngôn ngữ cho phép (phân cách bằng dấu phẩy)</Label>
                  <Textarea
                    id="allowedLanguages"
                    name="allowedLanguages"
                    defaultValue={appSettings?.allowedLanguages?.join(', ') || "vi, en, ja, ko, zh"}
                    onChange={formState.handleInputChange}
                    placeholder="vi, en, ja, ko, zh"
                    rows={3}
                  />
                </div>
              </div>
            </div>

            <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <h4 className="font-medium mb-2">Hướng dẫn cài đặt</h4>
              <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                <li>• Độ dài tối đa: Giới hạn số ký tự cho mỗi lần chuyển đổi</li>
                <li>• Ngôn ngữ mặc định: Ngôn ngữ được chọn mặc định khi tạo audio mới</li>
                <li>• Ngôn ngữ cho phép: Danh sách ngôn ngữ người dùng có thể sử dụng</li>
              </ul>
            </div>

            <div className="flex gap-4 pt-6 border-t">
              {formState.hasChanges && (
                <Button
                  type="button"
                  variant="outline"
                  onClick={formState.handleReset}
                >
                  Hủy thay đổi
                </Button>
              )}
              <Button
                type="submit"
                disabled={formState.isSubmitting || !formState.hasChanges}
                className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50"
              >
                {formState.isSubmitting ? "Đang lưu..." : "Lưu cài đặt"}
              </Button>
            </div>
          </form>
        </div>
      </div>

      <AdminConfirmDialog
        open={formState.showConfirmDialog}
        onOpenChange={formState.setShowConfirmDialog}
        onConfirm={formState.handleConfirmSave}
        title="Xác nhận lưu thay đổi"
        description="Bạn có chắc chắn muốn lưu các thay đổi cài đặt văn bản này?"
      />
    </div>
  );
}