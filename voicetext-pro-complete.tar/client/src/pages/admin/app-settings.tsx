import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import Breadcrumb from "@/components/breadcrumb";
import { useAdminFormState } from "@/hooks/useAdminFormState";
import AdminConfirmDialog from "@/components/admin-confirm-dialog";
import type { AppSettings, UpdateAppSettings } from "@shared/schema";
import { 
  Save, 
  Settings2, 
  Users, 
  Crown, 
  Star,
  FileText,
  Type,
  Shield,
  RotateCcw
} from "lucide-react";

export default function AppSettingsPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: settings, isLoading } = useQuery<AppSettings>({
    queryKey: ["/api/admin/app-settings"],
  });

  const updateMutation = useMutation({
    mutationFn: async (data: UpdateAppSettings) => {
      console.log("Sending app settings update:", data);
      return await apiRequest("PUT", "/api/admin/app-settings", data);
    },
    onSuccess: (result) => {
      console.log("App settings update successful:", result);
      queryClient.invalidateQueries({ queryKey: ["/api/admin/app-settings"] });
      queryClient.invalidateQueries({ queryKey: ["/api/app-settings"] }); // Invalidate client settings too
      
      // Reset form state với data mới từ server để đồng bộ
      setTimeout(() => {
        formState.resetFormState();
      }, 100);
      
      toast({
        title: "Thành công",
        description: "Cài đặt ứng dụng đã được cập nhật",
      });
    },
    onError: (error: Error) => {
      console.error("App settings update error:", error);
      formState.setIsSubmitting(false);
      toast({
        title: "Lỗi",
        description: error.message || "Không thể cập nhật cài đặt",
        variant: "destructive",
      });
    },
  });

  // Sử dụng hook mới cho form state management
  const formState = useAdminFormState<UpdateAppSettings>({
    initialData: settings,
    onSave: (data) => updateMutation.mutate(data),
  });

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    if (formState.currentData) {
      console.log("Submitting current data:", formState.currentData);
      formState.handleSubmit(formState.currentData);
    }
  };

  const handleSwitchChange = (name: string, checked: boolean) => {
    formState.handleSwitchChange(name, checked);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-6">
        <div className="max-w-4xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded"></div>
            <div className="h-64 bg-gray-200 dark:bg-gray-700 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <Breadcrumb title="Cài đặt ứng dụng" showBackButton backUrl="/admin" />

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Free Tier Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-gray-500" />
                Gói Miễn phí
                <Badge variant="secondary">Free</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="freeMaxFiles" className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Số file tối đa/tháng
                  </Label>
                  <Input
                    id="freeMaxFiles"
                    name="freeMaxFiles"
                    type="number"
                    value={formState.currentData?.freeMaxFiles ?? settings?.freeMaxFiles ?? 5}
                    onChange={formState.handleInputChange}
                    min="1"
                    max="1000"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="freeMaxCharacters" className="flex items-center gap-2">
                    <Type className="h-4 w-4" />
                    Số ký tự tối đa/file
                  </Label>
                  <Input
                    id="freeMaxCharacters"
                    name="freeMaxCharacters"
                    type="number"
                    value={formState.currentData?.freeMaxCharacters ?? settings?.freeMaxCharacters ?? 100}
                    onChange={formState.handleInputChange}
                    min="10"
                    max="100000"
                    required
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Pro Tier Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Crown className="h-5 w-5 text-blue-500" />
                Gói Pro
                <Badge variant="default" className="bg-blue-500">Pro</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="proMaxFiles" className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Số file tối đa/tháng
                  </Label>
                  <Input
                    id="proMaxFiles"
                    name="proMaxFiles"
                    type="number"
                    value={formState.currentData?.proMaxFiles ?? settings?.proMaxFiles ?? 100}
                    onChange={formState.handleInputChange}
                    min="1"
                    max="10000"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="proMaxCharacters" className="flex items-center gap-2">
                    <Type className="h-4 w-4" />
                    Số ký tự tối đa/file
                  </Label>
                  <Input
                    id="proMaxCharacters"
                    name="proMaxCharacters"
                    type="number"
                    value={formState.currentData?.proMaxCharacters ?? settings?.proMaxCharacters ?? 10000}
                    onChange={formState.handleInputChange}
                    min="100"
                    max="1000000"
                    required
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Premium Tier Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="h-5 w-5 text-yellow-500" />
                Gói Premium
                <Badge variant="default" className="bg-yellow-500">Premium</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="premiumMaxFiles" className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Số file tối đa/tháng
                  </Label>
                  <Input
                    id="premiumMaxFiles"
                    name="premiumMaxFiles"
                    type="number"
                    value={formState.currentData?.premiumMaxFiles ?? settings?.premiumMaxFiles ?? 1000}
                    onChange={formState.handleInputChange}
                    min="1"
                    max="100000"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="premiumMaxCharacters" className="flex items-center gap-2">
                    <Type className="h-4 w-4" />
                    Số ký tự tối đa/file
                  </Label>
                  <Input
                    id="premiumMaxCharacters"
                    name="premiumMaxCharacters"
                    type="number"
                    value={formState.currentData?.premiumMaxCharacters ?? settings?.premiumMaxCharacters ?? 50000}
                    onChange={formState.handleInputChange}
                    min="1000"
                    max="10000000"
                    required
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Guest Access Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-gray-500" />
                Truy cập Khách
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="enableGuestAccess">Cho phép truy cập khách</Label>
                  <p className="text-sm text-gray-500">
                    Cho phép người dùng chưa đăng ký sử dụng dịch vụ
                  </p>
                </div>
                <Switch
                  id="enableGuestAccess"
                  name="enableGuestAccess"
                  checked={formState.currentData?.enableGuestAccess ?? settings?.enableGuestAccess ?? false}
                  onCheckedChange={(checked) => handleSwitchChange("enableGuestAccess", checked)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="guestMaxCharacters" className="flex items-center gap-2">
                  <Type className="h-4 w-4" />
                  Số ký tự tối đa cho khách
                </Label>
                <Input
                  id="guestMaxCharacters"
                  name="guestMaxCharacters"
                  type="number"
                  value={formState.currentData?.guestMaxCharacters ?? settings?.guestMaxCharacters ?? 100}
                  onChange={formState.handleInputChange}
                  min="10"
                  max="1000"
                  required
                />
              </div>
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                {formState.hasChanges && (
                  <Button
                    type="button"
                    variant="outline"
                    onClick={formState.handleReset}
                    className="flex items-center gap-2"
                  >
                    <RotateCcw className="h-4 w-4" />
                    Đặt lại
                  </Button>
                )}
                {!formState.hasChanges && <div />}
                
                <Button
                  type="submit"
                  disabled={formState.isSubmitting || !formState.hasChanges}
                  className="flex items-center gap-2"
                >
                  <Save className="h-4 w-4" />
                  {formState.isSubmitting ? "Đang lưu..." : "Lưu cài đặt"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </form>
      </div>

      <AdminConfirmDialog
        open={formState.showConfirmDialog}
        onOpenChange={formState.setShowConfirmDialog}
        onConfirm={formState.handleConfirmSave}
        title="Xác nhận lưu cài đặt"
        description="Bạn có chắc chắn muốn lưu các thay đổi này? Điều này sẽ ảnh hưởng đến tất cả người dùng."
      />
    </div>
  );
}