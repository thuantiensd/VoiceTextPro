import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Mic, Play, Save } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import Breadcrumb from "@/components/breadcrumb";

export default function VoiceSamples() {
  const { toast } = useToast();
  
  const [sampleText, setSampleText] = useState("Xin chào, đây là mẫu giọng nói cho hệ thống VoiceText Pro. Chúng tôi cung cấp dịch vụ chuyển đổi văn bản thành giọng nói chất lượng cao với nhiều giọng đọc tự nhiên.");
  const [selectedVoice, setSelectedVoice] = useState("vi-VN-HoaiMy");
  const [generatedAudio, setGeneratedAudio] = useState<string | null>(null);

  const createVoiceSample = useMutation({
    mutationFn: async ({ text, voice }: { text: string; voice: string }) => {
      return await apiRequest("POST", "/api/admin/create-voice-sample", { text, voice });
    },
    onSuccess: (data: any) => {
      setGeneratedAudio(data.audioUrl);
      toast({
        title: "Thành công",
        description: "Mẫu giọng nói đã được tạo thành công",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Lỗi",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleCreateVoiceSample = () => {
    if (!sampleText.trim()) {
      toast({
        title: "Lỗi",
        description: "Vui lòng nhập văn bản mẫu",
        variant: "destructive",
      });
      return;
    }
    
    createVoiceSample.mutate({ text: sampleText, voice: selectedVoice });
  };

  const voiceOptions = [
    { value: "vi-VN-HoaiMy", label: "Hoài My - Giọng nữ miền Bắc (tự nhiên)" },
    { value: "vi-VN-NamMinh", label: "Nam Minh - Giọng nam miền Bắc (rõ ràng)" },
    { value: "vi-VN-ThuHa", label: "Thu Hà - Giọng nữ miền Trung (ấm áp)" },
    { value: "vi-VN-QuangAnh", label: "Quang Anh - Giọng nam miền Nam (thân thiện)" },
    { value: "vi-VN-HongLan", label: "Hồng Lan - Giọng nữ miền Nam (dịu dàng)" },
    { value: "vi-VN-TuanVu", label: "Tuấn Vũ - Giọng nam trầm ấm (chuyên nghiệp)" },
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <Breadcrumb 
          title="Tạo mẫu giọng nói" 
          showBackButton={true} 
          backUrl="/admin"
        />
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Mic className="h-5 w-5 text-orange-600" />
              Tạo mẫu giọng nói
            </CardTitle>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Tạo và quản lý các mẫu âm thanh để người dùng nghe thử các giọng nói
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            
            {/* Sample Text Input */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Văn bản mẫu</h3>
              <div className="space-y-2">
                <Label htmlFor="sampleText">Nội dung mẫu</Label>
                <Textarea
                  id="sampleText"
                  value={sampleText}
                  onChange={(e) => setSampleText(e.target.value)}
                  placeholder="Nhập văn bản để tạo mẫu giọng nói..."
                  className="min-h-[120px]"
                />
                <p className="text-xs text-gray-500">
                  Văn bản này sẽ được chuyển đổi thành audio mẫu cho từng giọng nói
                </p>
              </div>
            </div>

            {/* Voice Selection */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Chọn giọng nói</h3>
              <div className="space-y-2">
                <Label htmlFor="sampleVoice">Giọng nói</Label>
                <Select value={selectedVoice} onValueChange={setSelectedVoice}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {voiceOptions.map((voice) => (
                      <SelectItem key={voice.value} value={voice.value}>
                        {voice.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-gray-500">
                  Chọn giọng nói để tạo mẫu audio demo
                </p>
              </div>
            </div>

            {/* Generate Button */}
            <div className="flex justify-center pt-4">
              <Button 
                onClick={handleCreateVoiceSample}
                disabled={createVoiceSample.isPending || !sampleText.trim()}
                size="lg"
                className="min-w-48"
              >
                <Mic className="h-4 w-4 mr-2" />
                {createVoiceSample.isPending ? "Đang tạo..." : "Tạo mẫu giọng nói"}
              </Button>
            </div>

            {/* Generated Audio */}
            {generatedAudio && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Mẫu âm thanh đã tạo</h3>
                <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg border">
                  <div className="flex items-center justify-between mb-3">
                    <p className="text-sm font-medium">
                      Giọng: {voiceOptions.find(v => v.value === selectedVoice)?.label}
                    </p>
                    <Play className="h-4 w-4 text-green-600" />
                  </div>
                  <audio controls className="w-full">
                    <source src={generatedAudio} type="audio/mpeg" />
                    Trình duyệt của bạn không hỗ trợ phát audio.
                  </audio>
                  <p className="text-xs text-gray-500 mt-2">
                    File audio mẫu có thể được sử dụng cho voice preview
                  </p>
                </div>
              </div>
            )}

            {/* Usage Instructions */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Hướng dẫn sử dụng</h3>
              <div className="p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg">
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2 list-disc list-inside">
                  <li>Tạo mẫu giọng nói cho từng voice để người dùng có thể nghe thử</li>
                  <li>Nên sử dụng văn bản mô tả tính năng hoặc giới thiệu dịch vụ</li>
                  <li>Độ dài văn bản nên từ 20-100 từ để tạo mẫu demo hiệu quả</li>
                  <li>Mẫu audio sẽ được lưu trữ và hiển thị trong phần voice preview</li>
                  <li>Có thể tạo nhiều mẫu khác nhau cho từng giọng nói</li>
                </ul>
              </div>
            </div>

          </CardContent>
        </Card>
      </div>
    </div>
  );
}