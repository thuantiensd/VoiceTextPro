import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAdminFormState } from "@/hooks/useAdminFormState";
import AdminConfirmDialog from "@/components/admin-confirm-dialog";
import type { UpdatePaymentSettings, PaymentSettings } from "@shared/schema";

export default function PaymentSettings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: paymentSettings, isLoading: paymentSettingsLoading } = useQuery({
    queryKey: ["/api/payment-settings"],
  });

  const updatePaymentSettings = useMutation({
    mutationFn: async (data: UpdatePaymentSettings) => {
      return await apiRequest("PUT", "/api/payment-settings", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/payment-settings"] });
      toast({
        title: "Thành công",
        description: "Cài đặt thanh toán đã được cập nhật",
      });
      formState.resetFormState();
    },
    onError: (error: Error) => {
      toast({
        title: "Lỗi",
        description: error.message,
        variant: "destructive",
      });
      formState.setIsSubmitting(false);
    },
  });

  const formState = useAdminFormState<UpdatePaymentSettings>({
    initialData: paymentSettings as PaymentSettings,
    onSave: (data) => updatePaymentSettings.mutate(data),
  });

  const handleFormSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data: UpdatePaymentSettings = {
      bankName: formData.get("bankName") as string,
      accountNumber: formData.get("accountNumber") as string,
      accountName: formData.get("accountName") as string,
      bankCode: formData.get("bankCode") as string,
      supportEmail: formData.get("supportEmail") as string,
      supportPhone: formData.get("supportPhone") as string,
      proMonthlyPrice: Number(formData.get("proMonthlyPrice")),
      proYearlyPrice: Number(formData.get("proYearlyPrice")),
      premiumMonthlyPrice: Number(formData.get("premiumMonthlyPrice")),
      premiumYearlyPrice: Number(formData.get("premiumYearlyPrice")),
    };
    formState.handleSubmit(data);
  };

  if (paymentSettingsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
          <h2 className="text-2xl font-bold mb-6">Cài đặt Thanh toán</h2>
          
          <form onSubmit={handleFormSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Thông tin Ngân hàng</h3>
                <div>
                  <label htmlFor="bankName" className="block text-sm font-medium mb-2">
                    Tên Ngân hàng
                  </label>
                  <input
                    id="bankName"
                    name="bankName"
                    type="text"
                    value={formState.currentData?.bankName || paymentSettings?.bankName || "Ngân hàng TMCP Công Thương Việt Nam"}
                    onChange={formState.handleInputChange}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="accountNumber" className="block text-sm font-medium mb-2">
                    Số Tài khoản
                  </label>
                  <input
                    id="accountNumber"
                    name="accountNumber"
                    type="text"
                    value={formState.currentData?.accountNumber || paymentSettings?.accountNumber || "1234567890123456"}
                    onChange={formState.handleInputChange}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="accountName" className="block text-sm font-medium mb-2">
                    Tên Chủ tài khoản
                  </label>
                  <input
                    id="accountName"
                    name="accountName"
                    type="text"
                    value={formState.currentData?.accountName || paymentSettings?.accountName || "NGUYEN VAN A"}
                    onChange={formState.handleInputChange}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="bankCode" className="block text-sm font-medium mb-2">
                    Mã Ngân hàng
                  </label>
                  <input
                    id="bankCode"
                    name="bankCode"
                    type="text"
                    value={formState.currentData?.bankCode || paymentSettings?.bankCode || "ICB"}
                    onChange={formState.handleInputChange}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Thông tin Hỗ trợ</h3>
                <div>
                  <label htmlFor="supportEmail" className="block text-sm font-medium mb-2">
                    Email Hỗ trợ
                  </label>
                  <input
                    id="supportEmail"
                    name="supportEmail"
                    type="email"
                    value={formState.currentData?.supportEmail || paymentSettings?.supportEmail || "support@voicetextpro.com"}
                    onChange={formState.handleInputChange}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="supportPhone" className="block text-sm font-medium mb-2">
                    Số điện thoại Hỗ trợ
                  </label>
                  <input
                    id="supportPhone"
                    name="supportPhone"
                    type="tel"
                    value={formState.currentData?.supportPhone || paymentSettings?.supportPhone || "0123456789"}
                    onChange={formState.handleInputChange}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>

                <h3 className="text-lg font-semibold mt-6">Gói Pro</h3>
                <div>
                  <label htmlFor="proMonthlyPrice" className="block text-sm font-medium mb-2">
                    Giá hàng tháng (VND)
                  </label>
                  <input
                    id="proMonthlyPrice"
                    name="proMonthlyPrice"
                    type="number"
                    value={formState.currentData?.proMonthlyPrice || paymentSettings?.proMonthlyPrice || 99000}
                    onChange={formState.handleInputChange}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="proYearlyPrice" className="block text-sm font-medium mb-2">
                    Giá hàng năm (VND)
                  </label>
                  <input
                    id="proYearlyPrice"
                    name="proYearlyPrice"
                    type="number"
                    value={formState.currentData?.proYearlyPrice || paymentSettings?.proYearlyPrice || 990000}
                    onChange={formState.handleInputChange}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>

                <h3 className="text-lg font-semibold mt-6">Gói Premium</h3>
                <div>
                  <label htmlFor="premiumMonthlyPrice" className="block text-sm font-medium mb-2">
                    Giá hàng tháng (VND)
                  </label>
                  <input
                    id="premiumMonthlyPrice"
                    name="premiumMonthlyPrice"
                    type="number"
                    value={formState.currentData?.premiumMonthlyPrice || paymentSettings?.premiumMonthlyPrice || 199000}
                    onChange={formState.handleInputChange}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="premiumYearlyPrice" className="block text-sm font-medium mb-2">
                    Giá hàng năm (VND)
                  </label>
                  <input
                    id="premiumYearlyPrice"
                    name="premiumYearlyPrice"
                    type="number"
                    value={formState.currentData?.premiumYearlyPrice || paymentSettings?.premiumYearlyPrice || 1990000}
                    onChange={formState.handleInputChange}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>
            </div>

            <div className="flex gap-4 pt-6 border-t">
              {formState.hasChanges && (
                <button
                  type="button"
                  onClick={formState.handleReset}
                  className="px-6 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Hủy thay đổi
                </button>
              )}
              <button
                type="submit"
                disabled={formState.isSubmitting || !formState.hasChanges}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
              >
                {formState.isSubmitting ? "Đang lưu..." : "Lưu cài đặt"}
              </button>
            </div>
          </form>
        </div>
      </div>

      <AdminConfirmDialog
        open={formState.showConfirmDialog}
        onOpenChange={formState.setShowConfirmDialog}
        onConfirm={formState.handleConfirmSave}
        title="Xác nhận lưu thay đổi"
        description="Bạn có chắc chắn muốn lưu các thay đổi này?"
      />
    </div>
  );
}