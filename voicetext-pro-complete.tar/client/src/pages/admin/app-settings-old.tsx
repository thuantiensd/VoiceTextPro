import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import Breadcrumb from "@/components/breadcrumb";
import { useAdminFormState } from "@/hooks/useAdminFormState";
import AdminConfirmDialog from "@/components/admin-confirm-dialog";
import type { AppSettings, UpdateAppSettings } from "@shared/schema";
import { 
  Save, 
  Settings2, 
  Users, 
  Crown, 
  Star,
  Volume2,
  FileText,
  Shield,
  RotateCcw
} from "lucide-react";

export default function AppSettingsPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: settings, isLoading } = useQuery<AppSettings>({
    queryKey: ["/api/admin/app-settings"],
  });

  // Sử dụng hook mới cho form state management
  const formState = useAdminFormState<UpdateAppSettings>({
    initialData: settings,
    onSave: (data) => updateMutation.mutate(data),
  });

  // Hàm để reset form về giá trị ban đầu
  const handleReset = () => {
    if (originalSettings) {
      // Reset form bằng cách trigger reload
      window.location.reload();
    }
    setHasChanges(false);
  };

  // Hàm để track thay đổi form
  const handleInputChange = () => {
    if (!hasChanges) {
      setHasChanges(true);
    }
  };

  // Hàm xử lý confirm save
  const handleConfirmSave = (data: UpdateAppSettings) => {
    console.log("handleConfirmSave called with:", data);
    setShowConfirmDialog(false);
    setIsSubmitting(true);
    updateMutation.mutate(data);
  };

  const updateMutation = useMutation({
    mutationFn: async (data: UpdateAppSettings) => {
      console.log("Sending app settings update:", data);
      try {
        const response = await apiRequest("PUT", "/api/admin/app-settings", data);
        const result = await response.json();
        console.log("App settings update response:", result);
        return result;
      } catch (error) {
        console.error("App settings update error:", error);
        throw error;
      }
    },
    onSuccess: (data) => {
      console.log("App settings update successful:", data);
      queryClient.invalidateQueries({ queryKey: ["/api/admin/app-settings"] });
      queryClient.invalidateQueries({ queryKey: ["/api/app-settings"] });
      toast({
        title: "Thành công",
        description: "Cài đặt ứng dụng đã được cập nhật!",
      });
      setIsSubmitting(false);
      setHasChanges(false);
      setPendingData(null);
    },
    onError: (error: any) => {
      console.error("App settings mutation error:", error);
      toast({
        title: "Lỗi",
        description: error.message || "Có lỗi xảy ra khi cập nhật cài đặt",
        variant: "destructive",
      });
      setIsSubmitting(false);
    },
  });

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    const formData = new FormData(e.currentTarget);
    
    // Debug form data
    console.log("Form data entries:");
    const entries = Array.from(formData.entries());
    entries.forEach(([key, value]) => {
      console.log(`${key}: ${value}`);
    });
    
    const data: UpdateAppSettings = {
      // Free tier
      freeMaxFiles: parseInt(formData.get("freeMaxFiles") as string) || 5,
      freeMaxCharacters: parseInt(formData.get("freeMaxCharacters") as string) || 500,
      
      // Pro tier
      proMaxFiles: parseInt(formData.get("proMaxFiles") as string) || 100,
      proMaxCharacters: parseInt(formData.get("proMaxCharacters") as string) || 10000,
      
      // Premium tier
      premiumMaxFiles: parseInt(formData.get("premiumMaxFiles") as string) || 1000,
      premiumMaxCharacters: parseInt(formData.get("premiumMaxCharacters") as string) || 50000,
      
      // General
      enableGuestAccess: formData.get("enableGuestAccess") === "on",
      guestMaxCharacters: parseInt(formData.get("guestMaxCharacters") as string) || 100,
    };

    console.log("Parsed form data:", data);
    
    // Lưu data và hiển thị dialog xác nhận
    setPendingData(data);
    setShowConfirmDialog(true);
    setIsSubmitting(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded mb-4"></div>
            <div className="h-64 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <Breadcrumb title="Cài đặt ứng dụng" showBackButton backUrl="/admin" />

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Free Tier Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-gray-500" />
                Gói Miễn phí
                <Badge variant="secondary">Free</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="freeMaxFiles" className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Số file tối đa/tháng
                  </Label>
                  <Input
                    id="freeMaxFiles"
                    name="freeMaxFiles"
                    type="number"
                    defaultValue={settings?.freeMaxFiles || 5}
                    min="1"
                    max="50"
                    onChange={handleInputChange}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="freeMaxCharacters" className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Số ký tự tối đa
                  </Label>
                  <Input
                    id="freeMaxCharacters"
                    name="freeMaxCharacters"
                    type="number"
                    defaultValue={settings?.freeMaxCharacters || 500}
                    min="100"
                    max="2000"
                    onChange={handleInputChange}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Volume2 className="h-4 w-4" />
                  Giọng đọc available
                </Label>
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  Free users: 2 giọng cơ bản (vi-VN-HoaiMyNeural, vi-VN-NamMinhNeural)
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Pro Tier Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Crown className="h-5 w-5 text-blue-500" />
                Gói Pro
                <Badge className="bg-blue-100 text-blue-800">Pro</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="proMaxFiles" className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Số file tối đa/tháng
                  </Label>
                  <Input
                    id="proMaxFiles"
                    name="proMaxFiles"
                    type="number"
                    defaultValue={settings?.proMaxFiles || 100}
                    min="50"
                    max="500"
                    onChange={handleInputChange}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="proMaxCharacters" className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Số ký tự tối đa
                  </Label>
                  <Input
                    id="proMaxCharacters"
                    name="proMaxCharacters"
                    type="number"
                    defaultValue={settings?.proMaxCharacters || 10000}
                    min="2000"
                    max="25000"
                    onChange={handleInputChange}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Volume2 className="h-4 w-4" />
                  Giọng đọc available
                </Label>
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  Pro users: Tất cả giọng đọc premium
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Premium Tier Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="h-5 w-5 text-yellow-500" />
                Gói Premium
                <Badge className="bg-yellow-100 text-yellow-800">Premium</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="premiumMaxFiles" className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Số file tối đa/tháng
                  </Label>
                  <Input
                    id="premiumMaxFiles"
                    name="premiumMaxFiles"
                    type="number"
                    defaultValue={settings?.premiumMaxFiles || 1000}
                    min="500"
                    max="5000"
                    onChange={handleInputChange}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="premiumMaxCharacters" className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Số ký tự tối đa
                  </Label>
                  <Input
                    id="premiumMaxCharacters"
                    name="premiumMaxCharacters"
                    type="number"
                    defaultValue={settings?.premiumMaxCharacters || 50000}
                    min="25000"
                    max="100000"
                    onChange={handleInputChange}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Volume2 className="h-4 w-4" />
                  Giọng đọc available
                </Label>
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  Premium users: Tất cả giọng đọc + tính năng đặc biệt
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Guest Access Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-gray-500" />
                Cài đặt khách vãng lai
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Cho phép truy cập khách vãng lai</Label>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Người dùng chưa đăng ký có thể sử dụng tính năng TTS cơ bản
                  </p>
                </div>
                <Switch
                  name="enableGuestAccess"
                  defaultChecked={settings?.enableGuestAccess || false}
                  onCheckedChange={handleInputChange}
                />
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <Label htmlFor="guestMaxCharacters" className="flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Số ký tự tối đa cho khách
                </Label>
                <Input
                  id="guestMaxCharacters"
                  name="guestMaxCharacters"
                  type="number"
                  defaultValue={settings?.guestMaxCharacters || 100}
                  min="50"
                  max="500"
                  onChange={handleInputChange}
                />
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Khách chỉ có 1 giọng demo: vi-VN-HoaiMyNeural
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Submit Buttons */}
          <div className="flex justify-end gap-3">
            {hasChanges && (
              <Button
                type="button"
                variant="outline"
                onClick={handleReset}
                className="min-w-32"
              >
                <RotateCcw className="h-4 w-4 mr-2" />
                Hủy bỏ
              </Button>
            )}
            
            <Button
              type="submit"
              disabled={isSubmitting || !hasChanges}
              className="min-w-32 disabled:opacity-50"
            >
              {isSubmitting ? (
                <div className="flex items-center gap-2">
                  <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                  Đang lưu...
                </div>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Lưu cài đặt
                </>
              )}
            </Button>
          </div>
        </form>
      </div>

      {/* Confirmation Dialog */}
      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Xác nhận lưu cài đặt</AlertDialogTitle>
            <AlertDialogDescription>
              Bạn có chắc chắn muốn lưu các thay đổi này không? 
              Điều này sẽ ảnh hưởng đến tất cả người dùng trong hệ thống.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setIsSubmitting(false)}>
              Hủy bỏ
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => {
                if (pendingData) {
                  handleConfirmSave(pendingData);
                }
              }}
            >
              Xác nhận lưu
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}