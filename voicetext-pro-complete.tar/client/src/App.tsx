import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "./components/theme-provider";
import Home from "@/pages/home";
import Login from "@/pages/login";
import Register from "@/pages/register";
import Dashboard from "@/pages/dashboard";
import AdminDashboard from "@/pages/admin";
import AdminLogin from "@/pages/admin-login";
import TextSettings from "@/pages/admin/text-settings";
import AudioSettings from "@/pages/admin/audio-settings";
import PaymentSettings from "@/pages/admin/payment-settings";
import GeneralSettings from "@/pages/admin/general-settings";
import PricingSettings from "@/pages/admin/pricing-settings";
import AppSettings from "@/pages/admin/app-settings";
import BannerSettings from "@/pages/admin/banner-settings";
import VoiceSamples from "@/pages/admin/voice-samples";
import SystemMaintenance from "@/pages/admin/system-maintenance";
import PricingPage from "@/pages/pricing";
import PaymentPage from "@/pages/payment";
import SimplePayment from "@/pages/simple-payment";
import BasicPayment from "@/pages/basic-payment";
import Membership from "@/pages/membership";
import Notifications from "@/pages/notifications";
import Features from "@/pages/features";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/admin-login" component={AdminLogin} />
      <Route path="/admin" component={AdminDashboard} />
      <Route path="/admin/general-settings" component={GeneralSettings} />
      <Route path="/admin/text-settings" component={TextSettings} />
      <Route path="/admin/audio-settings" component={AudioSettings} />
      <Route path="/admin/payment-settings" component={PaymentSettings} />
      <Route path="/admin/pricing-settings" component={PricingSettings} />
      <Route path="/admin/app-settings" component={AppSettings} />
      <Route path="/admin/banner-settings" component={BannerSettings} />
      <Route path="/admin/voice-samples" component={VoiceSamples} />
      <Route path="/admin/system-maintenance" component={SystemMaintenance} />
      <Route path="/pricing" component={PricingPage} />
      <Route path="/payment" component={PaymentPage} />
      <Route path="/payment/plans/:plan/billing/:billing" component={PaymentPage} />
      <Route path="/thanhtoan" component={PaymentPage} />
      <Route path="/payment-basic" component={BasicPayment} />
      <Route path="/payment-simple" component={SimplePayment} />
      <Route path="/membership" component={Membership} />
      <Route path="/notifications" component={Notifications} />
      <Route path="/features" component={Features} />
      <Route path="/shared/:shareId" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light" storageKey="vite-ui-theme">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
