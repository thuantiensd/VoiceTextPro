import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useTheme } from "./theme-provider";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Menu, Mic, Moon, Sun, X, User, LogOut, LogIn, UserPlus, Settings, Crown, Home, FileText, Volume2, Shield, Users, BarChart3, Bell } from "lucide-react";
import { Link } from "wouter";

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { theme, setTheme } = useTheme();
  const { user, isAuthenticated, logout, isLoggingOut } = useAuth();

  // Lấy số thông báo chưa đọc cho tất cả user
  const { data: unreadNotifications, isLoading: notificationsLoading } = useQuery({
    queryKey: ['/api/notifications/unread'],
    enabled: isAuthenticated, // Tất cả user đã đăng nhập đều có thông báo
    refetchInterval: 15000, // Refresh mỗi 15 giây để cập nhật nhanh hơn
    retry: false,
  });

  const unreadCount = Array.isArray(unreadNotifications) ? unreadNotifications.length : 0;

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setMobileMenuOpen(false);
    }
  };

  const toggleTheme = () => {
    setTheme(theme === "light" ? "dark" : "light");
  };

  return (
    <header className="gradient-primary sticky top-0 z-50 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
              <Mic className="text-xl text-white" />
            </div>
            <h1 className="text-2xl font-bold text-white">VoiceText Pro</h1>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <button
              onClick={() => scrollToSection("tts-tool")}
              className="text-white hover:text-yellow-300 transition-colors duration-200 font-medium"
            >
              Công cụ TTS
            </button>
            <button
              onClick={() => scrollToSection("features")}
              className="text-white hover:text-yellow-300 transition-colors duration-200 font-medium"
            >
              Tính năng
            </button>
            <button
              onClick={() => scrollToSection("file-manager")}
              className="text-white hover:text-yellow-300 transition-colors duration-200 font-medium"
            >
              Quản lý File
            </button>
            <Link href="/pricing">
              <button className="text-white hover:text-yellow-300 transition-colors duration-200 font-medium">
                Bảng giá
              </button>
            </Link>
            
            {/* Additional links for authenticated users */}
            {isAuthenticated && (
              <>
                <Link href="/features">
                  <button className="text-white hover:text-yellow-300 transition-colors duration-200 font-medium">
                    Chi tiết tính năng
                  </button>
                </Link>
                <Link href="/dashboard">
                  <button className="text-white hover:text-yellow-300 transition-colors duration-200 font-medium">
                    Dashboard
                  </button>
                </Link>
              </>
            )}
          </nav>

          {/* Auth & Theme Toggle & Mobile Menu */}
          <div className="flex items-center space-x-4">
            {/* Notification Bell for All Users */}
            {isAuthenticated && (
              <Link href={user?.role === "admin" ? "/admin?tab=notifications" : "/notifications"}>
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="relative bg-white/20 hover:bg-white/30 text-white hover:text-white p-2"
                >
                  <Bell className="h-5 w-5" />
                  {unreadCount > 0 && (
                    <Badge 
                      variant="destructive" 
                      className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs font-bold"
                    >
                      {unreadCount > 99 ? '99+' : unreadCount}
                    </Badge>
                  )}
                </Button>
              </Link>
            )}

            {/* Authentication buttons */}
            {isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center space-x-2 bg-white/20 hover:bg-white/30 text-white hover:text-white">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-white/30 text-white text-sm">
                        {user?.fullName?.charAt(0) || user?.username?.charAt(0) || "U"}
                      </AvatarFallback>
                    </Avatar>
                    <span className="hidden sm:inline text-sm font-medium">
                      {user?.fullName || user?.username}
                    </span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem disabled>
                    <User className="mr-2 h-4 w-4" />
                    <span>{user?.email}</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/membership">
                      <Crown className="mr-2 h-4 w-4" />
                      <span>Gói thành viên</span>
                    </Link>
                  </DropdownMenuItem>
                  {user?.subscriptionType !== "premium" && (
                    <DropdownMenuItem asChild>
                      <Link href="/pricing">
                        <Crown className="mr-2 h-4 w-4" />
                        <span>Nâng cấp</span>
                      </Link>
                    </DropdownMenuItem>
                  )}
                  {user?.role === "admin" && (
                    <DropdownMenuItem asChild>
                      <Link href="/admin">
                        <Settings className="mr-2 h-4 w-4" />
                        <span>Quản lý Admin</span>
                      </Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem onClick={logout} disabled={isLoggingOut}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>{isLoggingOut ? "Đang đăng xuất..." : "Đăng xuất"}</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="hidden sm:flex items-center space-x-2">
                <Link href="/login">
                  <Button variant="ghost" size="sm" className="bg-white/20 hover:bg-white/30 text-white hover:text-white">
                    <LogIn className="mr-2 h-4 w-4" />
                    Đăng nhập
                  </Button>
                </Link>
                <Link href="/register">
                  <Button variant="ghost" size="sm" className="bg-white/20 hover:bg-white/30 text-white hover:text-white">
                    <UserPlus className="mr-2 h-4 w-4" />
                    Đăng ký
                  </Button>
                </Link>
              </div>
            )}

            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              className="p-2 rounded-lg bg-white/20 hover:bg-white/30 transition-colors duration-200 text-white hover:text-white"
            >
              {theme === "light" ? (
                <Moon className="h-5 w-5" />
              ) : (
                <Sun className="h-5 w-5" />
              )}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg bg-white/20 hover:bg-white/30 transition-colors duration-200 text-white hover:text-white"
            >
              {mobileMenuOpen ? (
                <X className="h-5 w-5" />
              ) : (
                <Menu className="h-5 w-5" />
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white/10 backdrop-blur-sm">
          <div className="px-4 py-4 space-y-2">
            <button
              onClick={() => scrollToSection("tts-tool")}
              className="block w-full text-left py-2 text-white hover:text-yellow-300 transition-colors duration-200"
            >
              Công cụ TTS
            </button>
            <button
              onClick={() => scrollToSection("features")}
              className="block w-full text-left py-2 text-white hover:text-yellow-300 transition-colors duration-200"
            >
              Tính năng
            </button>
            <button
              onClick={() => scrollToSection("file-manager")}
              className="block w-full text-left py-2 text-white hover:text-yellow-300 transition-colors duration-200"
            >
              Quản lý File
            </button>
            <button
              onClick={() => scrollToSection("pricing")}
              className="block w-full text-left py-2 text-white hover:text-yellow-300 transition-colors duration-200"
            >
              Bảng giá
            </button>
            
            {/* Additional mobile links for authenticated users */}
            {isAuthenticated && (
              <>
                <Link href="/features">
                  <button className="block w-full text-left py-2 text-white hover:text-yellow-300 transition-colors duration-200">
                    Chi tiết tính năng
                  </button>
                </Link>
                <Link href="/dashboard">
                  <button className="block w-full text-left py-2 text-white hover:text-yellow-300 transition-colors duration-200">
                    Dashboard
                  </button>
                </Link>
              </>
            )}
            
            {/* Mobile Auth Menu */}
            <div className="border-t border-white/20 pt-2 mt-4">
              {isAuthenticated ? (
                <div className="space-y-2">
                  <div className="text-white/80 text-sm py-2">
                    Xin chào, {user?.fullName || user?.username}
                  </div>
                  <button
                    onClick={logout}
                    disabled={isLoggingOut}
                    className="block w-full text-left py-2 text-white hover:text-yellow-300 transition-colors duration-200"
                  >
                    {isLoggingOut ? "Đang đăng xuất..." : "Đăng xuất"}
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  <Link href="/login">
                    <button 
                      onClick={() => setMobileMenuOpen(false)}
                      className="block w-full text-left py-2 text-white hover:text-yellow-300 transition-colors duration-200"
                    >
                      Đăng nhập
                    </button>
                  </Link>
                  <Link href="/register">
                    <button 
                      onClick={() => setMobileMenuOpen(false)}
                      className="block w-full text-left py-2 text-white hover:text-yellow-300 transition-colors duration-200"
                    >
                      Đăng ký
                    </button>
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
