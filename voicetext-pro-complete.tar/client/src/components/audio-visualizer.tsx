import { useEffect, useState } from "react";

interface AudioVisualizerProps {
  isPlaying: boolean;
  height?: number;
  barCount?: number;
}

export default function AudioVisualizer({ 
  isPlaying, 
  height = 50, 
  barCount = 50 
}: AudioVisualizerProps) {
  const [barHeights, setBarHeights] = useState<number[]>(
    Array.from({ length: barCount }, () => Math.random() * 20 + 8)
  );

  useEffect(() => {
    if (!isPlaying) {
      // Reset to base heights when not playing
      setBarHeights(Array.from({ length: barCount }, () => 8));
      return;
    }

    const interval = setInterval(() => {
      setBarHeights(prev => 
        prev.map(() => Math.random() * (height - 16) + 8)
      );
    }, 150);

    return () => clearInterval(interval);
  }, [isPlaying, height, barCount]);

  return (
    <div 
      className="bg-white dark:bg-gray-800 rounded-lg flex items-end justify-center space-x-1 p-4 overflow-hidden"
      style={{ height }}
    >
      {barHeights.map((barHeight, index) => (
        <div
          key={index}
          className="bg-gradient-to-t from-primary-600 to-primary-400 rounded-t transition-all duration-150 ease-out"
          style={{
            width: '2px',
            height: `${barHeight}px`,
            animationDelay: `${index * 0.02}s`,
          }}
        />
      ))}
    </div>
  );
}
