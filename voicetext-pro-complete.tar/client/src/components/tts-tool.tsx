import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useTTS } from "@/hooks/use-tts";
import { useFileUpload } from "@/hooks/use-file-upload";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import AudioVisualizer from "./audio-visualizer";
import QuotaWarning from "./quota-warning";
import VoicePreview from "./voice-preview";
import TextTemplatesCompact from "./text-templates-compact";
import { 
  CloudUpload, 
  Play, 
  Pause, 
  Download, 
  FileText, 
  Loader2, 
  Volume2, 
  Settings,
  ChevronDown,
  SpellCheck,
  Languages,
  Square,
  Save,
  Sparkles,
  Split,
  FileStack,
  Crown
} from "lucide-react";

export default function TTSTool() {
  const [text, setText] = useState("");
  const [maxCharacters, setMaxCharacters] = useState(500);
  const [voice, setVoice] = useState("vi-VN-HoaiMy");
  const [title, setTitle] = useState("");
  const [format, setFormat] = useState("mp3");
  const [useSSML, setUseSSML] = useState(false);
  const [activeTab, setActiveTab] = useState("create");
  const [speed, setSpeed] = useState([1.0]);
  const [pitch, setPitch] = useState([1.0]);
  const [volume, setVolume] = useState([1.0]);
  const [isAdvancedOpen, setIsAdvancedOpen] = useState(false);

  const { toast } = useToast();
  const { user, isAuthenticated } = useAuth();

  // Fetch app settings including character limit
  const { data: appSettings } = useQuery({
    queryKey: ["/api/app-settings"],
    staleTime: 0, // Always fetch fresh data for immediate updates
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  // Fetch audio files for quota calculation
  const { data: audioFiles = [] } = useQuery({
    queryKey: ["/api/audio-files"],
    enabled: isAuthenticated,
  });

  // Get available voices from API
  const { data: voices = [] } = useQuery({
    queryKey: ["/api/voices"],
    retry: false,
  });

  // Update maxCharacters based on user authentication status and subscription
  useEffect(() => {
    if (appSettings) {
      if (!isAuthenticated) {
        // Guest user gets free tier limits
        setMaxCharacters(appSettings.freeMaxCharacters || 500);
      } else {
        // Authenticated users get limits based on subscription
        const subscriptionType = user?.subscriptionType || 'free';
        if (subscriptionType === 'premium') {
          setMaxCharacters(appSettings.premiumMaxCharacters || 5000);
        } else if (subscriptionType === 'pro') {
          setMaxCharacters(appSettings.proMaxCharacters || 2000);
        } else {
          setMaxCharacters(appSettings.freeMaxCharacters || 500);
        }
      }
    }
  }, [appSettings, isAuthenticated, user?.subscriptionType]);

  // Load saved preferences on component mount
  useEffect(() => {
    const savedPreferences = localStorage.getItem('tts-preferences');
    if (savedPreferences) {
      try {
        const prefs = JSON.parse(savedPreferences);
        if (prefs.voice) setVoice(prefs.voice);
        if (prefs.speed) setSpeed([prefs.speed]);
        if (prefs.pitch) setPitch([prefs.pitch]);
        if (prefs.volume) setVolume([prefs.volume]);
        if (prefs.format) setFormat(prefs.format);
      } catch (error) {
        console.log('Failed to load preferences');
      }
    }
  }, []);

  // Save preferences when they change
  const savePreferences = () => {
    const preferences = {
      voice,
      speed: speed[0],
      pitch: pitch[0],
      volume: volume[0],
      format
    };
    localStorage.setItem('tts-preferences', JSON.stringify(preferences));
    toast({
      title: "Đã lưu cài đặt",
      description: "Cài đặt giọng nói đã được lưu thành công",
    });
  };
  const { 
    generateAudio, 
    playAudio,
    checkIfSameConfig,
    isPlaying, 
    isPaused, 
    isGenerating,
    progress, 
    duration, 
    currentTime,
    pause, 
    resume, 
    stop,
    downloadAudio,
    hasGeneratedAudio
  } = useTTS();

  // Check if generate button should be disabled
  const isGenerateDisabled = checkIfSameConfig(text, {
    voice,
    rate: speed[0],
    pitch: pitch[0],
    volume: volume[0]
  });

  const {
    isUploading,
    uploadFile,
    dragProps
  } = useFileUpload({
    onSuccess: (extractedText, filename) => {
      setText(extractedText);
      toast({
        title: "File uploaded successfully",
        description: `Extracted text from ${filename}`,
      });
    },
    onError: (error) => {
      const errorMessage = typeof error === 'string' ? error : (error?.message || "Không thể xử lý file");
      toast({
        title: "Tải file thất bại",
        description: errorMessage,
        variant: "destructive",
      });
    }
  });

  const handleGenerateAudio = async () => {
    if (!text.trim()) {
      toast({
        title: "Lỗi",
        description: "Vui lòng nhập văn bản cần chuyển đổi",
        variant: "destructive",
      });
      return;
    }

    // Check character limit first
    if (text.length > maxCharacters) {
      toast({
        title: "Vượt quá giới hạn ký tự",
        description: `Văn bản quá dài (${text.length}/${maxCharacters} ký tự). Vui lòng nâng cấp gói để được giới hạn cao hơn.`,
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/membership";
      }, 1500);
      return;
    }

    // Check subscription limits for authenticated users
    if (isAuthenticated) {
      const subscriptionType = user?.subscriptionType || 'free';
      const currentFiles = audioFiles?.length || 0;
      const maxFiles = getMaxFiles(subscriptionType);
      
      if (currentFiles >= maxFiles) {
        toast({
          title: "Đã vượt giới hạn file",
          description: `Gói ${subscriptionType} chỉ cho phép tối đa ${maxFiles} file. Vui lòng nâng cấp tài khoản.`,
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/membership";
        }, 1500);
        return;
      }
    }

    try {
      await generateAudio(text, {
        voice,
        rate: speed[0],
        pitch: pitch[0],
        volume: volume[0]
      });
    } catch (error) {
      toast({
        title: "Lỗi tạo giọng nói",
        description: "Không thể tạo giọng nói. Vui lòng thử lại.",
        variant: "destructive",
      });
    }
  };

  // Helper function to get max files based on subscription
  const getMaxFiles = (subscriptionType: string) => {
    if (subscriptionType === 'premium') return appSettings?.premiumMaxFiles || 1000;
    if (subscriptionType === 'pro') return appSettings?.proMaxFiles || 100;
    return appSettings?.freeMaxFiles || 5;
  };

  const handlePlayAudio = () => {
    if (hasGeneratedAudio) {
      playAudio();
    }
  };

  // Text processing functions
  const normalizeText = () => {
    if (!text.trim()) {
      toast({
        title: "Lỗi",
        description: "Vui lòng nhập văn bản để chuẩn hóa",
        variant: "destructive",
      });
      return;
    }

    let normalized = text
      // Chuẩn hóa dấu cách
      .replace(/\s+/g, ' ')
      .trim()
      // Chuẩn hóa dấu câu
      .replace(/([.!?])\s*([A-ZÁÀẠẢÃÂẦẤẬẨẪĂẰẮẶẲẴÉÈẸẺẼÊỀẾỆỂỄÍÌỊỈĨÓÒỌỎÕÔỒỐỘỔỖƠỜỚỢỞỠÚÙỤỦŨƯỪỨỰỬỮÝỲỴỶỸĐ])/g, '$1 $2')
      // Xóa ký tự đặc biệt không cần thiết
      .replace(/[^\w\s\u00C0-\u024F\u1E00-\u1EFF.,!?;:()""''`-]/g, '')
      // Chuẩn hóa dấu ngoặc kép
      .replace(/[""]/g, '"')
      .replace(/['']/g, "'");
    
    setText(normalized);
    toast({
      title: "Thành công",
      description: "Đã chuẩn hóa văn bản",
    });
  };

  const checkSpelling = () => {
    if (!text.trim()) {
      toast({
        title: "Lỗi",
        description: "Vui lòng nhập văn bản để kiểm tra",
        variant: "destructive",
      });
      return;
    }

    // Sửa lỗi chính tả phổ biến trong tiếng Việt với độ chính xác cao
    let corrected = text;
    let changeCount = 0;
    const changedWords: string[] = [];
    
    // Chỉ sửa những từ viết tắt rất chắc chắn và an toàn
    const corrections = [
      // Từ viết tắt phổ biến nhất - hoàn toàn an toàn
      { from: /\bko\b/gi, to: 'không', desc: 'ko → không' },
      { from: /\bdc\b/gi, to: 'được', desc: 'dc → được' },
      { from: /\bđc\b/gi, to: 'được', desc: 'đc → được' },
      { from: /\bvs\b/gi, to: 'với', desc: 'vs → với' },
      { from: /\bms\b/gi, to: 'mình', desc: 'ms → mình' },
      { from: /\bbn\b/gi, to: 'bạn', desc: 'bn → bạn' },
      { from: /\bmk\b/gi, to: 'mình', desc: 'mk → mình' },
      
      // Từ viết tắt đặc biệt
      { from: /\btk\b/gi, to: 'tài khoản', desc: 'tk → tài khoản' },
      { from: /\bsp\b/gi, to: 'sản phẩm', desc: 'sp → sản phẩm' },
      { from: /\bmn\b/gi, to: 'mọi người', desc: 'mn → mọi người' },
      { from: /\bae\b/gi, to: 'anh em', desc: 'ae → anh em' },
      
      // Từ chat phổ biến
      { from: /\bchx\b/gi, to: 'chưa', desc: 'chx → chưa' },
      { from: /\bcx\b/gi, to: 'cũng', desc: 'cx → cũng' },
      { from: /\bkb\b/gi, to: 'không biết', desc: 'kb → không biết' },
      { from: /\bkbt\b/gi, to: 'không biết', desc: 'kbt → không biết' },
      
      // Từ đơn giản
      { from: /\boke\b/gi, to: 'ok', desc: 'oke → ok' },
      { from: /\bokela\b/gi, to: 'ok', desc: 'okela → ok' },
      
      // Chỉ sửa khi chắc chắn 100%
      { from: /(?<!\w)j(?!\w)/gi, to: 'gì', desc: 'j → gì' },
      { from: /(?<!\w)wa(?!\w)/gi, to: 'quá', desc: 'wa → quá' },
      { from: /(?<!\w)ny(?!\w)/gi, to: 'này', desc: 'ny → này' }
    ];

    // Áp dụng từng rule một cách cẩn thận
    corrections.forEach(correction => {
      const beforeCorrection = corrected;
      corrected = corrected.replace(correction.from, (match) => {
        // Đếm số lần thay thế
        changeCount++;
        changedWords.push(correction.desc);
        return correction.to;
      });
    });
    
    // Kiểm tra xem có thay đổi gì không
    if (corrected !== text) {
      setText(corrected);
      
      // Hiển thị thông báo chi tiết
      const uniqueChanges = [...new Set(changedWords)];
      toast({
        title: "Đã sửa lỗi chính tả",
        description: `Sửa ${changeCount} lỗi: ${uniqueChanges.slice(0, 3).join(', ')}${uniqueChanges.length > 3 ? '...' : ''}`,
      });
    } else {
      toast({
        title: "Hoàn tất kiểm tra",
        description: "Không tìm thấy lỗi chính tả phổ biến cần sửa",
      });
    }
  };

  const highlightDifficultWords = () => {
    if (!text.trim()) {
      toast({
        title: "Lỗi",
        description: "Vui lòng nhập văn bản để phân tích",
        variant: "destructive",
      });
      return;
    }

    // Danh sách từ khó phát âm trong tiếng Việt
    const difficultWords = [
      'nghiêm', 'nghiệp', 'nghiền', 'nghiêng', 'nghiêu',
      'thuở', 'thuần', 'thuật', 'thuộc', 'thuần',
      'phường', 'phượng', 'phương', 'phước', 'phụng',
      'trường', 'trượng', 'trương', 'trước', 'trụng',
      'khuôn', 'khuông', 'khuống', 'khuấy', 'khuất',
      'giường', 'giượng', 'giương', 'giước', 'giụng',
      'nguyên', 'nguyệt', 'nguyện', 'nguyền'
    ];

    let highlighted = text;
    let foundWords = [];

    difficultWords.forEach(word => {
      const regex = new RegExp(`\\b${word}\\b`, 'gi');
      if (regex.test(text)) {
        foundWords.push(word);
        highlighted = highlighted.replace(regex, `**${word}**`);
      }
    });

    if (foundWords.length > 0) {
      setText(highlighted);
      toast({
        title: "Đã đánh dấu từ khó",
        description: `Tìm thấy ${foundWords.length} từ khó phát âm (đánh dấu bằng **)`,
      });
    } else {
      toast({
        title: "Hoàn tất",
        description: "Không tìm thấy từ khó phát âm phổ biến",
      });
    }
  };

  const handlePause = () => {
    if (isPlaying) {
      pause();
    } else if (isPaused) {
      resume();
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <section id="tts-tool" className="py-16 bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Công Cụ Chuyển Đổi Text-to-Speech</h2>
          <p className="text-gray-600 dark:text-gray-400 text-lg">
            Nhập văn bản hoặc tải file lên để chuyển đổi thành giọng nói chất lượng cao
          </p>
          {!isAuthenticated && (
            <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4 max-w-2xl mx-auto mt-6">
              <p className="text-blue-700 dark:text-blue-300 text-sm">
                ✨ Bạn đang sử dụng gói miễn phí (tối đa {maxCharacters} ký tự). 
                <a href="/login" className="ml-1 underline hover:text-blue-600">Đăng nhập</a> để mở khóa thêm tính năng!
              </p>
            </div>
          )}
          
          {/* Warning for guest users */}
          {!isAuthenticated && (
            <Alert className="mt-6 max-w-2xl mx-auto border-amber-200 bg-amber-50 dark:border-amber-800 dark:bg-amber-950">
              <AlertDescription className="text-amber-800 dark:text-amber-200">
                <strong>Lưu ý:</strong> Người dùng chưa đăng nhập chỉ có thể nghe audio tạm thời. 
                File sẽ bị xóa sau 1 giờ. <a href="/register" className="underline font-medium">Đăng ký</a> để lưu trữ vĩnh viễn!
              </AlertDescription>
            </Alert>
          )}
        </div>

        {/* Quota Warning for Free Users */}
        {isAuthenticated && appSettings && (
          <QuotaWarning 
            currentUsage={audioFiles.length} 
            maxUsage={appSettings.freeMaxFiles || 5} 
          />
        )}

        <Card className="shadow-xl">
          <CardContent className="p-6 md:p-8">
            {/* File Upload Area */}
            <div className="mb-8">
              <div
                {...dragProps}
                className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl p-8 text-center hover:border-primary-500 transition-colors duration-200 cursor-pointer"
                onClick={() => document.getElementById('file-input')?.click()}
              >
                <CloudUpload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-lg font-medium mb-2">
                  {isUploading ? "Đang xử lý file..." : "Kéo thả file hoặc nhấn để chọn"}
                </p>
                <p className="text-gray-500 dark:text-gray-400">
                  Hỗ trợ PDF, Word, TXT (tối đa 10MB)
                </p>
                <input
                  id="file-input"
                  type="file"
                  className="hidden"
                  accept=".pdf,.doc,.docx,.txt"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) uploadFile(file);
                  }}
                />
                {isUploading && (
                  <div className="mt-4 flex items-center justify-center">
                    <Loader2 className="h-6 w-6 animate-spin mr-2" />
                    <span>Đang trích xuất văn bản...</span>
                  </div>
                )}
              </div>
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
              {/* Text Editor */}
              <div className="lg:col-span-2 space-y-4">
                <Label className="text-sm font-medium">Nội dung văn bản</Label>
                <div className="relative">
                  <Textarea
                    value={text}
                    onChange={(e) => {
                      if (e.target.value.length <= maxCharacters) {
                        setText(e.target.value);
                      }
                    }}
                    className="min-h-80 resize-none"
                    placeholder="Nhập văn bản cần chuyển đổi thành giọng nói..."
                    maxLength={maxCharacters}
                  />
                  <div className={`absolute bottom-4 right-4 text-sm px-2 py-1 rounded ${
                    text.length > maxCharacters * 0.9 
                      ? 'text-red-500 bg-red-50 dark:bg-red-900/20' 
                      : 'text-gray-500 bg-white dark:bg-gray-800'
                  }`}>
                    {text.length}/{maxCharacters} ký tự
                  </div>
                  {text.length >= maxCharacters && (
                    <div className="absolute bottom-12 right-4 text-xs text-red-500 bg-red-50 dark:bg-red-900/20 px-2 py-1 rounded">
                      Đã đạt giới hạn ký tự
                    </div>
                  )}
                </div>

                {/* Text Statistics */}
                {text.trim() && (
                  <Card className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
                    <CardContent className="p-4">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div className="text-center">
                          <div className="font-semibold text-blue-700 dark:text-blue-300">
                            {text.trim().split(/\s+/).length}
                          </div>
                          <div className="text-blue-600 dark:text-blue-400">Từ</div>
                        </div>
                        <div className="text-center">
                          <div className="font-semibold text-blue-700 dark:text-blue-300">
                            {text.split(/[.!?]+/).filter(s => s.trim()).length}
                          </div>
                          <div className="text-blue-600 dark:text-blue-400">Câu</div>
                        </div>
                        <div className="text-center">
                          <div className="font-semibold text-blue-700 dark:text-blue-300">
                            {Math.ceil(text.trim().split(/\s+/).length / 150 * speed[0])}
                          </div>
                          <div className="text-blue-600 dark:text-blue-400">Phút ước tính</div>
                        </div>
                        <div className="text-center">
                          <div className="font-semibold text-blue-700 dark:text-blue-300">
                            {Math.ceil(text.length / 1000)}MB
                          </div>
                          <div className="text-blue-600 dark:text-blue-400">Kích thước ước tính</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Text Templates - Moved here and compacted */}
                <div className="mt-4">
                  <TextTemplatesCompact onSelectTemplate={(content: string) => setText(content)} />
                </div>

                {/* Text Processing Options */}
                <div className="flex flex-wrap gap-2">
                  <Button variant="outline" size="sm" onClick={normalizeText}>
                    <FileText className="mr-2 h-4 w-4" />
                    Chuẩn hóa văn bản
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={checkSpelling}
                    disabled={!isAuthenticated || user?.subscriptionType === 'free'}
                    className="relative"
                  >
                    <SpellCheck className="mr-2 h-4 w-4" />
                    Kiểm tra chính tả
                    {(!isAuthenticated || user?.subscriptionType === 'free') && (
                      <Badge variant="outline" className="text-xs ml-2">Pro</Badge>
                    )}
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={highlightDifficultWords}
                    disabled={!isAuthenticated || user?.subscriptionType === 'free'}
                    className="relative"
                  >
                    <Languages className="mr-2 h-4 w-4" />
                    Phát âm từ khó
                    {(!isAuthenticated || user?.subscriptionType === 'free') && (
                      <Badge variant="outline" className="text-xs ml-2">Pro</Badge>
                    )}
                  </Button>
                </div>
              </div>

              {/* Controls Panel */}
              <div className="space-y-6">
                <Card className="bg-gray-50 dark:bg-gray-700">
                  <CardContent className="p-6">
                    <h3 className="font-semibold mb-4">Cài đặt giọng đọc</h3>
                    
                    {/* Voice Selection */}
                    <div className="mb-4">
                      <Label className="text-sm font-medium mb-2">Giọng đọc</Label>
                      <Select value={voice} onValueChange={setVoice}>
                        <SelectTrigger>
                          <SelectValue placeholder="Chọn giọng đọc" />
                        </SelectTrigger>
                        <SelectContent>
                          {voices.length > 0 ? (
                            <>
                              {/* FPT AI Voices - Vietnamese (Premium Feature) */}
                              {voices.filter(v => v.provider === "fpt").length > 0 && (
                                <>
                                  <div className="px-2 py-1 text-xs font-semibold text-gray-600 bg-gray-100 rounded flex items-center justify-between">
                                    <span>🇻🇳 FPT AI - Tiếng Việt</span>
                                    {(!isAuthenticated || user?.subscriptionType === 'free') && (
                                      <Badge variant="outline" className="text-xs">Premium</Badge>
                                    )}
                                  </div>
                                  {(!isAuthenticated || user?.subscriptionType === 'free') ? (
                                    <div className="p-3 bg-purple-50 border rounded-lg m-2">
                                      <div className="flex items-center gap-2 mb-2">
                                        <Crown className="h-4 w-4 text-purple-600" />
                                        <span className="text-sm font-medium text-purple-800">Giọng đọc Premium</span>
                                      </div>
                                      <p className="text-xs text-purple-600 mb-2">
                                        Nâng cấp để sử dụng giọng đọc FPT AI chất lượng cao với âm thanh tự nhiên.
                                      </p>
                                      <Button 
                                        size="sm" 
                                        onClick={() => window.location.href = '/membership'}
                                        className="bg-purple-600 hover:bg-purple-700 text-xs h-6"
                                      >
                                        Nâng cấp ngay
                                      </Button>
                                    </div>
                                  ) : (
                                    voices.filter(v => v.provider === "fpt").map(voice => (
                                      <SelectItem key={voice.id} value={voice.id}>
                                        {voice.gender === "female" ? "👩" : "👨"} {voice.name}
                                        {voice.region && ` - ${voice.region === "north" ? "Miền Bắc" : 
                                          voice.region === "south" ? "Miền Nam" : "Miền Trung"}`}
                                        {voice.description && ` (${voice.description})`}
                                      </SelectItem>
                                    ))
                                  )}
                                </>
                              )}
                              
                              {/* OpenAI Voices - English */}
                              {voices.filter(v => v.provider === "openai").length > 0 && (
                                <>
                                  <div className="px-2 py-1 text-xs font-semibold text-gray-600 bg-gray-100 rounded mt-2">
                                    🇺🇸 OpenAI - English
                                  </div>
                                  {voices.filter(v => v.provider === "openai").map(voice => (
                                    <SelectItem key={voice.id} value={voice.id}>
                                      {voice.gender === "female" ? "👩" : voice.gender === "male" ? "👨" : "🤖"} {voice.name}
                                    </SelectItem>
                                  ))}
                                </>
                              )}
                            </>
                          ) : (
                            <>
                              <SelectItem value="banmai">👩 Ban Mai - Giọng nữ miền Bắc</SelectItem>
                              <SelectItem value="leminh">👨 Lê Minh - Giọng nam miền Bắc</SelectItem>
                              <SelectItem value="thuminh">👩 Thu Minh - Giọng nữ miền Nam</SelectItem>
                              <SelectItem value="giahuy">👨 Gia Huy - Giọng nam miền Nam</SelectItem>
                              <SelectItem value="ngoclam">👩 Ngọc Lam - Giọng nữ miền Trung</SelectItem>
                            </>
                          )}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Speed Control */}
                    <div className="mb-4">
                      <Label className="text-sm font-medium mb-2">Tốc độ đọc</Label>
                      <Slider
                        value={speed}
                        onValueChange={setSpeed}
                        min={0.5}
                        max={2}
                        step={0.1}
                        className="w-full"
                      />
                      <div className="flex justify-between text-sm text-gray-500 mt-1">
                        <span>Chậm</span>
                        <span>{speed[0].toFixed(1)}x</span>
                        <span>Nhanh</span>
                      </div>
                    </div>

                    {/* Pitch Control - Pro Feature */}
                    <div className="mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <Label className="text-sm font-medium">Cao độ giọng</Label>
                        {(!isAuthenticated || user?.subscriptionType === 'free') && (
                          <Badge variant="outline" className="text-xs">Pro</Badge>
                        )}
                      </div>
                      <Slider
                        value={pitch}
                        onValueChange={setPitch}
                        min={0.5}
                        max={2}
                        step={0.1}
                        className="w-full"
                        disabled={!isAuthenticated || user?.subscriptionType === 'free'}
                      />
                      <div className="flex justify-between text-sm text-gray-500 mt-1">
                        <span>Thấp</span>
                        <span>{pitch[0].toFixed(1)}</span>
                        <span>Cao</span>
                      </div>
                    </div>

                    {/* Volume Control */}
                    <div className="mb-6">
                      <Label className="text-sm font-medium mb-2">Âm lượng</Label>
                      <Slider
                        value={volume}
                        onValueChange={setVolume}
                        min={0}
                        max={1}
                        step={0.1}
                        className="w-full"
                      />
                      <div className="flex justify-between text-sm text-gray-500 mt-1">
                        <span>0%</span>
                        <span>{Math.round(volume[0] * 100)}%</span>
                        <span>100%</span>
                      </div>
                    </div>

                    {/* Save Settings Button */}
                    <Button
                      onClick={savePreferences}
                      variant="outline"
                      size="sm"
                      className="w-full mb-4"
                    >
                      <Settings className="mr-2 h-4 w-4" />
                      Lưu cài đặt này
                    </Button>

                    {/* Voice Preview */}
                    <div className="mb-6">
                      <VoicePreview 
                        voice={voice}
                        speed={speed[0]}
                        pitch={pitch[0]}
                        volume={volume[0]}
                        previewText={text || "Đây là giọng nói mẫu để bạn nghe thử."}
                      />
                    </div>

                    {/* Advanced Settings - Premium Feature */}
                    <Collapsible open={isAdvancedOpen} onOpenChange={setIsAdvancedOpen}>
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" className="w-full justify-between p-0">
                          <span className="font-medium">Cài đặt nâng cao</span>
                          <div className="flex items-center gap-2">
                            {(!isAuthenticated || user?.subscriptionType === 'free') && (
                              <Badge variant="outline" className="text-xs">Premium</Badge>
                            )}
                            <Settings className="h-4 w-4" />
                          </div>
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="space-y-3 mt-3">
                        {(!isAuthenticated || user?.subscriptionType === 'free') ? (
                          <div className="bg-gradient-to-r from-purple-50 to-blue-50 p-4 rounded-lg border">
                            <div className="flex items-center gap-2 mb-2">
                              <Crown className="h-4 w-4 text-purple-600" />
                              <span className="font-medium text-purple-800">Tính năng Premium</span>
                            </div>
                            <p className="text-sm text-purple-600 mb-3">
                              Nâng cấp để sử dụng các tùy chỉnh nâng cao như nhấn mạnh, SSML và nhiều hơn nữa.
                            </p>
                            <Button 
                              size="sm" 
                              onClick={() => window.location.href = '/membership'}
                              className="bg-purple-600 hover:bg-purple-700"
                            >
                              Nâng cấp ngay
                            </Button>
                          </div>
                        ) : (
                          <>
                            <div>
                              <Label className="text-sm font-medium mb-1">Nhấn mạnh</Label>
                              <Select defaultValue="normal">
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="normal">Bình thường</SelectItem>
                                  <SelectItem value="light">Nhẹ</SelectItem>
                                  <SelectItem value="strong">Mạnh</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <div>
                              <Label className="text-sm font-medium mb-1">Tạm dừng giữa câu</Label>
                              <Slider
                                defaultValue={[0.5]}
                                min={0}
                                max={2}
                                step={0.1}
                                className="w-full"
                              />
                            </div>
                          </>
                        )}
                      </CollapsibleContent>
                    </Collapsible>
                  </CardContent>
                </Card>

                {/* Action Buttons */}
                <div className="space-y-3">
                  {/* Generate Audio Button */}
                  <Button 
                    onClick={handleGenerateAudio}
                    disabled={isGenerating || !text.trim() || isGenerateDisabled}
                    className={`w-full ${isGenerateDisabled ? 'bg-gray-400 text-gray-200 cursor-not-allowed' : 'gradient-primary hover:shadow-lg transform hover:scale-105'} text-white transition-all duration-200`}
                  >
                    {isGenerating ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Đang tạo...
                      </>
                    ) : isGenerateDisabled ? (
                      <>
                        <Play className="mr-2 h-4 w-4" />
                        Đã tạo xong
                      </>
                    ) : (
                      <>
                        <Play className="mr-2 h-4 w-4" />
                        Tạo giọng nói
                      </>
                    )}
                  </Button>

                  {/* Audio Controls */}
                  {hasGeneratedAudio && (
                    <div className="flex gap-2">
                      <Button 
                        onClick={handlePlayAudio}
                        variant="outline"
                        className="flex-1"
                        disabled={isPlaying}
                      >
                        <Play className="mr-1 h-4 w-4" />
                        Nghe thử
                      </Button>
                      
                      <Button 
                        onClick={handlePause}
                        disabled={!isPlaying && !isPaused}
                        variant="outline"
                        className="flex-1"
                      >
                        {isPlaying ? (
                          <>
                            <Pause className="mr-1 h-4 w-4" />
                            Tạm dừng
                          </>
                        ) : (
                          <>
                            <Play className="mr-1 h-4 w-4" />
                            Tiếp tục
                          </>
                        )}
                      </Button>

                      <Button 
                        onClick={stop}
                        variant="outline"
                        className="flex-1"
                        disabled={!isPlaying && !isPaused}
                      >
                        <Square className="mr-1 h-4 w-4" />
                        Dừng
                      </Button>
                    </div>
                  )}

                  <Button 
                    onClick={downloadAudio}
                    disabled={!hasGeneratedAudio}
                    className="w-full bg-green-500 text-white hover:bg-green-600"
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Tải xuống MP3
                  </Button>
                </div>
              </div>
            </div>

            {/* Audio Visualizer */}
            <Card className="mt-8 bg-gray-50 dark:bg-gray-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold">Phân tích âm thanh</h3>
                  <div className="text-sm text-gray-500">
                    {isPlaying ? "Đang phát" : isPaused ? "Tạm dừng" : "Sẵn sàng"}
                  </div>
                </div>
                
                <AudioVisualizer isPlaying={isPlaying} />

                {/* Progress Bar */}
                <div className="mt-4">
                  <div className="flex justify-between text-sm text-gray-500 mb-1">
                    <span>{formatTime(currentTime)}</span>
                    <span>{formatTime(duration)}</span>
                  </div>
                  <Progress value={progress} className="w-full" />
                </div>
              </CardContent>
            </Card>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
