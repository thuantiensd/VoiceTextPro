import { Button } from "@/components/ui/button";
import { Play, Download } from "lucide-react";

export default function Hero() {
  const scrollToTTSTool = () => {
    const element = document.getElementById("tts-tool");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="gradient-primary py-20 relative overflow-hidden">
      <div className="absolute inset-0 bg-black/10"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center text-white">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fadeInUp text-shadow">
            Chuyển Văn Bản Thành<br />
            <span className="text-yellow-300">Giọng Nói Việt</span> Tự Nhiên
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto animate-fadeInUp opacity-90">
            Công nghệ AI tiên tiến với hơn 20 giọng đọc tiếng Việt chân thực.
            Hỗ trợ file PDF, Word, và batch processing.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fadeInUp">
            <Button
              onClick={scrollToTTSTool}
              size="lg"
              className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 rounded-xl font-semibold transition-all duration-200 transform hover:scale-105"
            >
              <Play className="mr-2 h-5 w-5" />
              Dùng thử miễn phí
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="border-2 border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 rounded-xl font-semibold transition-all duration-200 bg-transparent"
            >
              <Download className="mr-2 h-5 w-5" />
              Tải ứng dụng
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
