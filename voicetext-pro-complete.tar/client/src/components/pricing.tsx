import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { Link } from "wouter";
import { Check, X, Crown, ArrowRight, ArrowLeft } from "lucide-react";

const plans = [
  {
    name: "Miễn Phí",
    price: "0₫",
    period: "Mãi mãi",
    description: "Dành cho người dùng cá nhân",
    features: [
      { text: "5 giọng đọc cơ bản", included: true },
      { text: "1000 ký tự/ngày", included: true },
      { text: "Xuất MP3 chất lượng chuẩn", included: true },
      { text: "Lưu trữ file", included: false },
      { text: "Chia sẻ công khai", included: false },
      { text: "Hỗ trợ ưu tiên", included: false },
    ],
    buttonText: "Dùng Miễn Phí",
    buttonVariant: "outline" as const,
  },
  {
    name: "Pro",
    price: "299,000₫",
    period: "Mỗi tháng",
    description: "Cho người dùng chuyên nghiệp",
    popular: true,
    features: [
      { text: "20+ giọng đọc premium", included: true },
      { text: "100,000 ký tự/ngày", included: true },
      { text: "Xuất đa định dạng HD", included: true },
      { text: "Lưu trữ không giới hạn", included: true },
      { text: "Batch processing", included: true },
      { text: "Hỗ trợ ưu tiên", included: true },
    ],
    buttonText: "Chọn Gói Pro",
    buttonVariant: "default" as const,
  },
  {
    name: "Enterprise",
    price: "Liên hệ",
    period: "Tùy chỉnh",
    description: "Cho doanh nghiệp và tổ chức",
    features: [
      { text: "Giọng đọc tùy chỉnh", included: true },
      { text: "Không giới hạn ký tự", included: true },
      { text: "API integration", included: true },
      { text: "White-label solution", included: true },
      { text: "Team collaboration", included: true },
      { text: "Hỗ trợ 24/7", included: true },
    ],
    buttonText: "Liên Hệ Tư Vấn",
    buttonVariant: "outline" as const,
  },
];

export default function Pricing() {
  const { isAuthenticated } = useAuth();

  const handlePlanSelect = (plan: string, billing: string) => {
    if (isAuthenticated) {
      // Nếu đã đăng nhập, vào trang thanh toán
      window.location.href = `/payment?plan=${plan}&billing=${billing}`;
    } else {
      // Nếu chưa đăng nhập, chuyển sang đăng ký
      window.location.href = `/register`;
    }
  };

  return (
    <section id="pricing" className="py-16 bg-white dark:bg-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">

          <h2 className="text-3xl md:text-4xl font-bold mb-4">Bảng Giá Dịch Vụ</h2>
          <p className="text-gray-600 dark:text-gray-400 text-lg">
            Chọn gói phù hợp với nhu cầu của bạn
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <Card 
              key={index} 
              className={`relative ${
                plan.popular 
                  ? "border-2 border-primary shadow-xl scale-105" 
                  : "border border-gray-200 dark:border-gray-600"
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="gradient-primary text-white px-6 py-2 text-sm font-semibold">
                    Phổ biến nhất
                  </Badge>
                </div>
              )}
              
              <CardContent className="p-8">
                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                  <div className="text-4xl font-bold mb-2">{plan.price}</div>
                  <p className="text-gray-500 dark:text-gray-400 mb-2">{plan.period}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{plan.description}</p>
                </div>
                
                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      {feature.included ? (
                        <Check className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                      ) : (
                        <X className="h-5 w-5 text-gray-400 mr-3 flex-shrink-0" />
                      )}
                      <span className={feature.included ? "" : "text-gray-400 dark:text-gray-500"}>
                        {feature.text}
                      </span>
                    </li>
                  ))}
                </ul>
                
                {plan.name === "Miễn Phí" ? (
                  <Link href="/register">
                    <Button variant="outline" size="lg" className="w-full">
                      Bắt đầu miễn phí
                    </Button>
                  </Link>
                ) : plan.name === "Pro" ? (
                  <Button 
                    size="lg" 
                    className="w-full gradient-primary text-white hover:shadow-lg"
                    onClick={() => handlePlanSelect("pro", "monthly")}
                  >
                    <Crown className="mr-2 h-4 w-4" />
                    Chọn Pro
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                ) : (
                  <Button 
                    variant="outline" 
                    size="lg" 
                    className="w-full"
                    onClick={() => handlePlanSelect("premium", "monthly")}
                  >
                    Chọn Premium
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            Tất cả các gói đều bao gồm bảo hành và hỗ trợ kỹ thuật
          </p>
          <p className="text-sm text-gray-500 dark:text-gray-500">
            Giá đã bao gồm VAT. Có thể thay đổi mà không báo trước.
          </p>
        </div>
      </div>
    </section>
  );
}
