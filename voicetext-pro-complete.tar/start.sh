#!/bin/bash
echo "🚀 Starting VoiceText Pro..."
npm install
npm run build
npm run start
